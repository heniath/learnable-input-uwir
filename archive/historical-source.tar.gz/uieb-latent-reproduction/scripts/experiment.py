#!/usr/bin/env python3
"""Headless entry point; no editable install or notebook required."""
# Path bootstrap precedes imports so no installation is required.
# ruff: noqa: E402

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "third_party/upstream/src")]

from reproduction.cli import main

if __name__ == "__main__":
    main()
