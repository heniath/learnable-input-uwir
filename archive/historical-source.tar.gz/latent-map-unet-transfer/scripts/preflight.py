"""Verify inheritance/initialization and a real-batch CUDA resume before launch."""
# ruff: noqa: E402

import copy
import fcntl
import gc
import importlib.metadata
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch

from latent_maps.data import PairedImages, load_manifest
from latent_maps.engine import freeze_experiment, loader
from latent_maps.models import EnhancementModel, parameter_count
from latent_maps.utils import (
    atomic_json,
    canonical_hash,
    digest,
    environment,
    load_config,
    restore_rng,
    rng_state,
    seed_everything,
)


def cpu_copy(value):
    if torch.is_tensor(value):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {k: cpu_copy(v) for k, v in value.items()}
    if isinstance(value, list):
        return [cpu_copy(v) for v in value]
    if isinstance(value, tuple):
        return tuple(cpu_copy(v) for v in value)
    return copy.deepcopy(value)


def exact(a, b):
    if torch.is_tensor(a):
        return torch.equal(a.cpu(), b.cpu())
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(exact(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)):
        return len(a) == len(b) and all(exact(x, y) for x, y in zip(a, b))
    return a == b


def main():
    config = load_config()
    parent = ROOT.parent / "latent-map-enhancement"
    inherited = load_config(parent / "configs/protocol.yaml")
    assert config["training"] == inherited["training"]
    assert config["evaluation"] == inherited["evaluation"]
    assert (
        config["seeds"] == [0, 1, 2] and config["conditions"] == inherited["conditions"]
    )
    for name in ("data.py", "metrics.py"):
        assert digest(ROOT / "src/latent_maps" / name) == digest(
            parent / "src/latent_maps" / name
        )
    provenance = json.loads((ROOT / "third_party/unet/SOURCE.json").read_text())
    assert digest(ROOT / "src/latent_maps/_unet.py") == provenance["source_sha256"]
    manifests = {}
    for name in ("lolv2_real", "lsui"):
        assert digest(ROOT / "manifests" / f"{name}.json") == digest(
            parent / "manifests" / f"{name}.json"
        )
        manifests[name] = load_manifest(
            ROOT / "manifests" / f"{name}.json", config["data_root"]
        )
    assert torch.cuda.is_available()
    output = ROOT / "outputs" / config["experiment_id"]
    output.mkdir(parents=True, exist_ok=True)
    with (ROOT / "outputs/.gpu-operation.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        torch.set_num_threads(config["training"]["cpu_threads"])
        seed_everything(0, True)
        models = {
            c: EnhancementModel(c, seed=0, **config["model"])
            for c in config["conditions"]
        }
        common = models["rgb"].backbone.state_dict()
        for condition, model in models.items():
            for name, tensor in common.items():
                target = model.backbone.state_dict()[name]
                if name == "enc1.net.0.weight":
                    target = target[:, :3]
                assert torch.equal(tensor, target), (condition, name)
        counts = {c: parameter_count(m) for c, m in models.items()}
        budget_error = abs(counts["learned_maps"] - counts["capacity"]) / (
            counts["learned_maps"] - counts["rgb"]
        )
        assert budget_error < 0.02
        x = torch.rand(1, 3, 256, 256)
        for model in models.values():
            model.eval()
        with torch.no_grad():
            assert torch.allclose(
                models["rgb"](x), models["zero_maps"](x), atol=1e-6, rtol=1e-5
            )
            assert torch.equal(models["rgb"](x), models["rgb"].backbone(x))
        del models, common, model, target, tensor, x
        gc.collect()
        dataset = PairedImages(
            manifests["lolv2_real"], config["data_root"], "train", 0, 256
        )
        batch = next(
            iter(loader(dataset, config, torch.device("cuda"), train=True, workers=0))
        )
        x, y = batch[0].cuda(), batch[1].cuda()
        seed_everything(0, True)
        model = EnhancementModel("learned_maps", seed=0, **config["model"]).cuda()
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=config["training"]["learning_rate"],
            weight_decay=0,
            foreach=False,
        )

        def step(model, optimizer, x, y):
            model.train()
            optimizer.zero_grad(set_to_none=True)
            loss = (model(x) - y).abs().mean()
            assert torch.isfinite(loss)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), float("inf"), error_if_nonfinite=True
            )
            optimizer.step()
            torch.cuda.synchronize()

        step(model, optimizer, x, y)
        saved_model, saved_optimizer, saved_rng = (
            cpu_copy(model.state_dict()),
            cpu_copy(optimizer.state_dict()),
            rng_state(),
        )
        step(model, optimizer, x, y)
        uninterrupted, uninterrupted_optimizer = (
            cpu_copy(model.state_dict()),
            cpu_copy(optimizer.state_dict()),
        )
        model.load_state_dict(saved_model)
        optimizer.load_state_dict(saved_optimizer)
        assert exact(model.state_dict(), saved_model) and exact(
            optimizer.state_dict(), saved_optimizer
        )
        restore_rng(saved_rng)
        step(model, optimizer, x, y)
        equal = exact(model.state_dict(), uninterrupted) and exact(
            optimizer.state_dict(), uninterrupted_optimizer
        )
        maximum = max(
            float((model.state_dict()[k].cpu().double() - v.double()).abs().max())
            for k, v in uninterrupted.items()
        )
        assert equal, (
            f"Strict CUDA resume did not reproduce: max tensor difference {maximum}"
        )
        del (
            model,
            optimizer,
            x,
            y,
            saved_model,
            saved_optimizer,
            uninterrupted,
            uninterrupted_optimizer,
        )
        gc.collect()
        torch.cuda.empty_cache()
        frozen_manifests = freeze_experiment(config, output, ROOT / "manifests")
        report = {
            "passed": True,
            "environment": environment(),
            "config_sha256": canonical_hash(config),
            "inherited_training_evaluation_and_manifests": True,
            "pinned_unet_source_verified": True,
            "shared_initialization": True,
            "cpu_rgb_zero_predictions_equal": True,
            "parameters": counts,
            "added_budget_relative_error": budget_error,
            "gpu_real_batch_shape": list(batch[0].shape),
            "gpu_exact_state_restoration": True,
            "gpu_two_step_resume_bitwise_equal": equal,
            "gpu_resume_max_tensor_difference": maximum,
            "manifest_hashes": {
                k: v["content_sha256"] for k, v in frozen_manifests.items()
            },
            "note": "Functionality checks only, not model-quality results.",
        }
        atomic_json(output / "preflight.json", report)
        packages = sorted(
            f"{p.metadata['Name']}=={p.version}"
            for p in importlib.metadata.distributions()
        )
        (output / "requirements-resolved.txt").write_text("\n".join(packages) + "\n")
        print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
