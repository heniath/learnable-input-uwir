# U-Net replication handoff

Experiment: `unet_map_replication_v1`. Eight new U-Net runs, seeds 1 and 2,
conditions rgb/bounded/unbounded/capacity. Original seed 0 is read-only historical
evidence. Test prediction is disabled. No later study launches automatically.

## Status and artifacts

Persistent tmux session: `latent-map-unet-replication`.
Authoritative status: `outputs/unet_map_replication_v1/job_status.json`.
Logs: `training.log`, `preflight.log`, `verification.log`.
Preflight: `implementation_verification.json`, `validation.json`,
`frozen_protocol.json`, `historical_reference.json`.
Runs: `unet/<condition>/seed_<1|2>/history.json`, `best.pt`, `last.pt`,
`run_complete.json`, then `diagnostics.json`.
Reports: `reports/FINDINGS.md`, scores/paired effects/seed summaries/curves CSVs,
`results.json`, then `report_complete.json`. Partial reports are labeled pending.

Paper documents: `research/PAPER_OUTLINE.md`, `PRIOR_PAPER_AUDIT.md`, `NOVELTY.md`,
`TERMINOLOGY.md`; these are provisional, without invented future results.

## Resume after an actual interruption

Inspect tmux, status, processes and GPU first. Do not duplicate an active runner.
With no active runner, restart from this directory:

```bash
tmux new-session -d -s latent-map-unet-replication -c /home/heniath/Experiments/latent-map-unet-replication /home/heniath/miniforge3/envs/uieb-latent-repro/bin/python -u scripts/run_logged.py
```

Completed runs/reports remain preserved. Incomplete runs resume at their last
saved epoch boundary with optimizer/scheduler/scaler/stopping/RNG state.
CUDA continuation can differ numerically; measured drift is recorded by smoke.
Do not edit frozen source/config/environment/images/weights; use a new experiment
for changes. On OOM, retain the failure and do not reduce batch size/resolution.
No continuous supervision is required after successful launch verification.

## Verified launch

Started UTC: 2026-10-14T18:29:39.183337+00:00. All 17 focused tests, lint, preparation and eight GPU smoke/resume checks passed. The runner was verified active, with RGB seed 1 saved through epoch 4. Live source and all 118 snapshot hashes match; historical references were reverified. See launch_verification.json and launch.json. Training results remain pending.
