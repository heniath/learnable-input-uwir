"""Audit the historical partition without regrouping or copying data."""

import hashlib
import json
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
from PIL import Image

from .protocol import (
    ROOT,
    base_dataset,
    canonical,
    config,
    configure_weights,
    digest,
    environment,
    freeze_json,
    git,
    output_root,
    source_hashes,
    split_indices,
)


def scan_pair(task):
    index, left, right, split = task
    root = Path(config()["data_root"])
    row = {"index": index, "filename": Path(left).name, "split": split}
    thumbs = {}
    for role, path in [("input", left), ("reference", right)]:
        with Image.open(path) as im:
            im.load()
            rgb = im.convert("RGB")
            size = list(rgb.size)
            if "size" in row and row["size"] != size:
                raise ValueError(f"Pair dimensions differ: {left}")
            row["size"] = size
            payload = f"RGB:{rgb.size}:".encode() + rgb.tobytes()
            gray = np.asarray(rgb.convert("L").resize((9, 8), Image.Resampling.BILINEAR))
            bits = (gray[:, 1:] > gray[:, :-1]).flatten()
            dhash = sum(int(bit) << i for i, bit in enumerate(bits))
            row[role] = {
                "path": str(Path(path).relative_to(root)),
                "sha256": digest(path),
                "decoded_sha256": hashlib.sha256(payload).hexdigest(),
                "dhash": f"{dhash:016x}",
            }
            thumbs[role] = (
                np.asarray(rgb.resize((16, 16), Image.Resampling.BILINEAR), dtype=np.float32) / 255
            )
    return row, thumbs


def audit_rows(scanned):
    rows = [r for r, _ in scanned]
    exact, near = [], []
    for role in ["input", "reference"]:
        thumbs = [t[role] for _, t in scanned]
        for i, a in enumerate(rows):
            for j in range(i + 1, len(rows)):
                b = rows[j]
                identity = {
                    "a": a["filename"],
                    "b": b["filename"],
                    "role": role,
                    "a_split": a["split"],
                    "b_split": b["split"],
                    "cross_split": a["split"] != b["split"],
                }
                if a[role]["decoded_sha256"] == b[role]["decoded_sha256"]:
                    exact.append(identity)
                distance = (int(a[role]["dhash"], 16) ^ int(b[role]["dhash"], 16)).bit_count()
                if distance <= 3:
                    error = float(np.mean((thumbs[i] - thumbs[j]) ** 2))
                    if error <= 0.000625:
                        near.append(
                            {**identity, "dhash_distance": distance, "thumbnail_mse": error}
                        )
    return {
        "exact_duplicates": exact,
        "near_duplicate_candidates": near,
        "cross_split_exact": [r for r in exact if r["cross_split"]],
        "cross_split_near": [r for r in near if r["cross_split"]],
        "near_rule": "For both input and reference: dHash distance <=3 AND aligned RGB 16x16 thumbnail MSE <=0.000625. Candidates include exact matches; no assertion of scene independence.",
        "decision": "Historical partition retained for reproduction; cross-split overlap limits generalization claims.",
    }


def prepare():
    if git("rev-parse", "HEAD") != config()["upstream_commit"] or git("diff", "HEAD"):
        raise ValueError("Upstream revision mismatch or modified tracked source")
    ds = base_dataset()
    splits = split_indices()
    assignment = {i: name for name, indices in splits.items() for i in indices}
    root = Path(config()["data_root"])
    # Upstream stem matching may silently skip unmatched images; assert all files pair.
    for folder, files in [
        (root / "raw-890", ds.input_files),
        (root / "reference-890", ds.gt_files),
    ]:
        actual = {
            p.name
            for p in folder.iterdir()
            if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".bmp"}
        }
        if actual != {Path(p).name for p in files} or len(actual) != 890:
            raise ValueError(f"Unexpected/unpaired files: {folder}")
    tasks = [(i, a, b, assignment[i]) for i, (a, b) in enumerate(zip(ds.input_files, ds.gt_files))]
    with ThreadPoolExecutor(max_workers=4) as pool:
        scanned = list(pool.map(scan_pair, tasks))
    manifest = {
        "ordering": "Original UIEBDataset lexicographic sorted input filenames",
        "indices": splits,
        "pairs": [r for r, _ in scanned],
        "audit": audit_rows(scanned),
    }
    out = output_root()
    freeze_json(out / "manifest.json", manifest)
    weights = configure_weights()
    frozen = {
        "config": config(),
        "source_hashes": source_hashes(),
        "upstream_git_commit": git("rev-parse", "HEAD"),
        "upstream_tracked_dirty": bool(git("diff", "HEAD")),
        "environment": environment(),
        "manifest_sha256": canonical(manifest),
        "weights": {
            "name": "VGG16_Weights.IMAGENET1K_V1",
            "sha256": digest(weights),
            "url": "https://download.pytorch.org/models/vgg16-397923af.pth",
        },
    }
    historical = Path("/home/heniath/Downloads/notebookf6ac4082c8 (1).ipynb")
    if historical.exists():
        frozen["historical_notebook"] = {"path": str(historical), "sha256": digest(historical)}
    freeze_json(out / "frozen_protocol.json", frozen)
    for rel, expected in frozen["source_hashes"].items():
        dest = out / "source_snapshot" / rel
        if dest.exists():
            if digest(dest) != expected:
                raise ValueError(f"Source snapshot changed: {dest}")
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / rel, dest)
    for name, command in [
        ("requirements-resolved.txt", [sys.executable, "-m", "pip", "freeze", "--all"]),
        (
            "conda-explicit.txt",
            [
                str(Path(sys.executable).parents[3] / "bin/conda"),
                "list",
                "--prefix",
                sys.prefix,
                "--explicit",
            ],
        ),
    ]:
        dest = out / name
        value = subprocess.check_output(command, text=True)
        if not dest.exists():
            dest.write_text(value)
    print(
        json.dumps(
            {
                "counts": {s: len(v) for s, v in splits.items()},
                "cross_split_exact": len(manifest["audit"]["cross_split_exact"]),
                "cross_split_near": len(manifest["audit"]["cross_split_near"]),
                "output": str(out),
            },
            indent=2,
        ),
        flush=True,
    )
