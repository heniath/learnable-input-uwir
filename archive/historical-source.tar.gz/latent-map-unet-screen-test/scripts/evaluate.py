#!/usr/bin/env python3
"""User-authorized test reporting, separate from frozen screening decisions."""

import argparse
import csv
import json
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
SCREEN = ROOT.parent / "latent-map-unet-screen"
TRAINING = SCREEN / "outputs/unet_arch_screen_v1"
PARENT = ROOT.parent / "latent-map-diagnostics"
REPLICATION = ROOT.parent / "latent-map-unet-replication"
INIT = ROOT.parent / "latent-map-init-diagnostics"
sys.path[:0] = [str(SCREEN / "src"), str(REPLICATION / "src"),
                str(REPLICATION / "third_party/upstream/src"),
                str(REPLICATION / "third_party/nafnet")]

import numpy as np
import torch
from PIL import Image, ImageDraw

from diagnostics.diagnose import metric_rows
from diagnostics.models import EnhancementModel
from diagnostics.protocol import (atomic_json, base_dataset, canonical, config, digest,
                                  loader, seed_original, verify_frozen)
from models import ScreenUNet


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_csv(path, rows):
    with path.open("x", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def inventory():
    completion = json.loads((TRAINING / "complete.json").read_text())
    frozen = json.loads((TRAINING / "frozen.json").read_text())
    if completion["frozen_identity"] != canonical(frozen):
        raise ValueError("Training identity changed")
    for rel, expected in frozen["sources"].items():
        if digest(SCREEN / rel) != expected:
            raise ValueError(f"Screening source changed: {rel}")
    items = []
    for marker in sorted((TRAINING / "runs").glob("seed_*/*/complete.json")):
        run = json.loads(marker.read_text())
        identity = run["identity"]
        if identity["frozen_identity"] != canonical(frozen):
            raise ValueError("Screening run identity changed")
        for selection in ("best", "last"):
            checkpoint = marker.parent / f"{selection}.pt"
            if digest(checkpoint) != run[f"{selection}_sha256"]:
                raise ValueError("Completed screening checkpoint changed")
            expected = run["best"] if selection == "best" else run["final"]
            items.append({"label": identity["condition"], "seed": identity["seed"],
                          "family": "screen", "selection": selection, "epoch": expected["epoch"],
                          "checkpoint": str(checkpoint), "sha256": run[f"{selection}_sha256"],
                          "expected_validation": {key: expected[key] for key in ("psnr", "ssim")}})
    if len(items) != completion["runs"] * 2:
        raise ValueError("Training run coverage mismatch")
    archive = PARENT / "outputs/map_diagnostics_v1"
    references = [("original_rgb", "unet", "rgb", archive),
                  ("original_bounded", "unet", "bounded", archive),
                  ("original_capacity", "unet", "capacity", archive),
                  ("nafnet_rgb", "nafnet", "rgb", INIT / "outputs/map_init_diagnostics_v1")]
    for label, backbone, condition, source in references:
        directory = source / backbone / condition / "seed_0"
        diagnostic = json.loads((directory / "diagnostics.json").read_text())
        checkpoint = directory / "best.pt"
        if digest(checkpoint) != diagnostic["checkpoint_sha256"]:
            raise ValueError("Reference checkpoint changed")
        items.append({"label": label, "seed": 0, "family": "reference", "selection": "best",
                      "backbone": backbone, "condition": condition,
                      "epoch": diagnostic["checkpoint_epoch"], "checkpoint": str(checkpoint),
                      "sha256": diagnostic["checkpoint_sha256"],
                      "expected_validation": diagnostic["normal"]})
    return completion, frozen, items


def image_from(tensor):
    array = tensor.detach().float().cpu().permute(1, 2, 0).numpy()
    return Image.fromarray(np.rint(array.clip(0, 1) * 255).astype(np.uint8))


@torch.inference_mode()
def evaluate(item, test, output, log):
    seed_original(item["seed"])
    if item["family"] == "screen":
        model = ScreenUNet(item["label"], item["seed"])
    else:
        model = EnhancementModel(item["backbone"], item["condition"], item["seed"])
    state = torch.load(item["checkpoint"], map_location="cpu", weights_only=False)
    if item["family"] == "screen":
        expected_identity = {"seed": item["seed"], "condition": item["label"],
                             "frozen_identity": canonical(json.loads((TRAINING / "frozen.json").read_text()))}
    else:
        expected_identity = json.loads((Path(item["checkpoint"]).parent / "run.json").read_text())
    if state["identity"] != expected_identity:
        raise ValueError("Loaded checkpoint identity mismatch")
    model.load_state_dict(state["model"], strict=True)
    del state
    model = model.cuda().eval()
    validation = []
    for x, y, names, _ in loader("validation", seed=item["seed"], filenames=True):
        validation.extend(metric_rows(model(x.cuda()), y, names))
    drift = {key: abs(float(np.mean([r[key] for r in validation])) - item["expected_validation"][key])
             for key in ("psnr", "ssim")}
    saved_path = Path(item["checkpoint"]).parent / (
        "per_image_best_validation.csv" if item["family"] == "screen" else "per_image_validation_normal.csv")
    if item["selection"] == "best":
        with saved_path.open() as handle:
            saved = {r["filename"]: r for r in csv.DictReader(handle)}
        if set(saved) != {r["filename"] for r in validation}:
            raise ValueError("Validation filenames changed")
        drift = {key: max(abs(r[key] - float(saved[r["filename"]][key])) for r in validation)
                 for key in ("psnr", "ssim")}
    if drift["psnr"] > 0.001 or drift["ssim"] > 0.00001:
        raise ValueError(f"Validation reproduction failed: {item['label']}, {drift}")
    directory = output / f"seed_{item['seed']}" / item["label"] / item["selection"]
    directory.mkdir(parents=True)
    rows, examples = [], {}
    for x, y, names in test:
        prediction = model(x.cuda())
        rows.extend(metric_rows(prediction, y, names))
        for name, tensor in zip(names, prediction):
            if len(examples) < 4:
                examples[name] = image_from(tensor)
                examples[name].save(directory / f"{Path(name).stem}.png")
    if len(rows) != 90 or len({r["filename"] for r in rows}) != 90:
        raise ValueError("Expected 90 unique test images")
    write_csv(directory / "per_image_test.csv", rows)
    result = {key: item[key] for key in ("label", "seed", "family", "selection", "epoch", "sha256")}
    result.update({"n": len(rows), "validation_psnr": item["expected_validation"]["psnr"],
                   "validation_ssim": item["expected_validation"]["ssim"],
                   "test_psnr": float(np.mean([r["psnr"] for r in rows])),
                   "test_ssim": float(np.mean([r["ssim"] for r in rows])),
                   "max_validation_psnr_drift": drift["psnr"],
                   "max_validation_ssim_drift": drift["ssim"],
                   "parameters": sum(p.numel() for p in model.parameters())})
    if not all(np.isfinite(result[k]) for k in ("test_psnr", "test_ssim")):
        raise FloatingPointError("Non-finite test metrics")
    atomic_json(directory / "result.json", result)
    log(f"seed={item['seed']} {item['label']}/{item['selection']} epoch={item['epoch']} "
        f"test={result['test_psnr']:.4f} dB SSIM={result['test_ssim']:.5f}; validation drift={drift}")
    del model
    torch.cuda.empty_cache()
    return result, rows, examples


def summarize(results, per_image, output):
    paired = []
    for row in results:
        if row["family"] != "screen":
            continue
        key = (row["seed"], row["label"], row["selection"])
        control_key = (row["seed"], "control", row["selection"])
        controls = {r["filename"]: r for r in per_image[control_key]}
        differences = {metric: [r[metric] - controls[r["filename"]][metric] for r in per_image[key]]
                       for metric in ("psnr", "ssim")}
        paired.append({"seed": row["seed"], "label": row["label"], "selection": row["selection"],
                       "delta_test_psnr_vs_control": float(np.mean(differences["psnr"])),
                       "delta_test_ssim_vs_control": float(np.mean(differences["ssim"])),
                       "test_psnr_wins_vs_control": sum(d > 0 for d in differences["psnr"])})
    write_csv(output / "results.csv", results)
    write_csv(output / "paired_test_differences.csv", paired)
    lines = ["# U-Net architecture screen: validation and test overview", "",
             "All checkpoint choices were fixed by validation or the predefined epoch-6 endpoint before test inference.",
             "", "| Seed | Model | Checkpoint | Epoch | Val PSNR | Val SSIM | Test PSNR | Test SSIM |",
             "|---|---|---|---:|---:|---:|---:|---:|"]
    for r in results:
        lines.append(f"| {r['seed']} | {r['label']} | {r['selection']} | {r['epoch']} | {r['validation_psnr']:.4f} | {r['validation_ssim']:.5f} | {r['test_psnr']:.4f} | {r['test_ssim']:.5f} |")
    lines += ["", "## Paired test differences against continuation control", "",
              "| Seed | Model | Checkpoint | Δtest PSNR | Δtest SSIM | PSNR wins / 90 |",
              "|---|---|---|---:|---:|---:|"]
    for r in paired:
        lines.append(f"| {r['seed']} | {r['label']} | {r['selection']} | {r['delta_test_psnr_vs_control']:+.4f} | {r['delta_test_ssim_vs_control']:+.5f} | {r['test_psnr_wins_vs_control']} |")
    lines += ["", "A best checkpoint can be epoch 0: the new identity-initialized extension then retains the original model and does not demonstrate an improvement. Last checkpoints measure the fixed six-epoch adaptation endpoint and are not selected using test scores.",
              "", "The user requested test reporting after the validation-only screening plan was frozen. This separate evaluation does not modify training, promotion or checkpoint-selection rules. Test results are descriptive and must not be used to revise those decisions.",
              "", "Inherited UIEB historical test90; shorter-edge resize 256 then center crop 256; float32; predictions clipped before per-image PSNR/SSIM. These are not native-resolution SOTA benchmark results. Seed-0 external references and any seed-1 confirmation are reported separately. Historical test exposure and scene-independence limits remain.",
              "", "Per-image scores, selected-checkpoint hashes, validation reproduction checks and fixed example PNGs are retained in this directory. Training histories and promotion decision remain in the original screening output."]
    (output / "FINDINGS.md").write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", default="unet_arch_screen_test_v1")
    args = parser.parse_args()
    if Path(args.run_id).name != args.run_id or args.run_id in (".", ".."):
        parser.error("run-id must be a single directory name")
    if not (TRAINING / "complete.json").exists():
        parser.error("Wait for the frozen architecture screen to complete")
    output = ROOT / "outputs" / args.run_id
    output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()

    def log(message):
        line = f"{utc()} {message}"
        print(line, flush=True)
        with (output / "execution.log").open("a") as handle:
            handle.write(line + "\n")

    try:
        _, manifest = verify_frozen()
        completion, frozen, items = inventory()
        if canonical(manifest) != frozen["manifest_sha256"]:
            raise ValueError("Evaluation/training manifests differ")
        atomic_json(output / "protocol.json", {
            "utc": utc(), "run_id": args.run_id, "training_completion": completion,
            "authorization": "User explicitly requested test evaluation after screening was planned",
            "checkpoint_inventory": items, "script_sha256": digest(__file__),
            "manifest_sha256": canonical(manifest), "environment": frozen["environment"],
            "selection": "Frozen validation best and predefined final epoch; no test-based selection",
            "preprocessing": CROP_DESCRIPTION,
        })
        shutil.copyfile(__file__, output / "evaluate.py")
        seed_original(0)
        dataset = torch.utils.data.Subset(base_dataset(augment=False), manifest["indices"]["test"])
        test = [(x, y, list(names)) for x, y, names, _ in torch.utils.data.DataLoader(
            dataset, batch_size=config()["batch_size"], num_workers=config()["workers"],
            shuffle=False, pin_memory=True, drop_last=False)]
        expected = [manifest["pairs"][i]["filename"] for i in manifest["indices"]["test"]]
        if [name for _, _, names in test for name in names] != expected or len(expected) != 90:
            raise ValueError("Historical test90 order/count differs")
        results, per_image = [], {}
        torch.cuda.reset_peak_memory_stats()
        for item in items:
            result, rows, _ = evaluate(item, test, output, log)
            results.append(result)
            per_image[(item["seed"], item["label"], item["selection"])] = rows
        summarize(results, per_image, output)
        for item in items:
            if digest(item["checkpoint"]) != item["sha256"]:
                raise ValueError("Checkpoint changed during evaluation")
        log(f"Complete: {len(items)} checkpoints, {len(items) * 90} test predictions")
        atomic_json(output / "complete.json", {
            "utc": utc(), "elapsed_seconds": time.perf_counter() - started,
            "checkpoints": len(items), "test_predictions": len(items) * 90,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "artifact_hashes": {str(p.relative_to(output)): digest(p)
                                for p in output.rglob("*") if p.is_file()},
        })
    except BaseException as error:
        atomic_json(output / "failure.json", {"utc": utc(), "error": repr(error)})
        raise


CROP_DESCRIPTION = "Inherited shorter-edge resize 256 then center crop 256; RGB [0,1]; float32; clipped float per-image inherited PSNR/SSIM"

if __name__ == "__main__":
    main()
