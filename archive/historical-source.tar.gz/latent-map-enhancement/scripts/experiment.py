"""Run without installing into the shared environment."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from latent_maps.cli import main

if __name__ == "__main__":
    main()
