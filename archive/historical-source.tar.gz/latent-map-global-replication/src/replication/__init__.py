"""Validation-only replication of the frozen global latent dimension screen."""
