# Predicted latent maps for image enhancement

This project tests whether **image-conditioned auxiliary maps** improve supervised RGB restoration beyond comparable extra capacity. It is a fresh implementation, not a reproduction of the historical Latent-UNet. It generates maps from each input and concatenates them with RGB; it does not learn one tensor shared by all images.

The existing notebook, datasets, environment, and UWIR presentation files are preserved. There are no notebooks, custom CUDA extensions, experiment services, or installation requirements for the verified `ml-base` environment.

## Model comparison

All conditions use NAFNet width 32, encoder blocks `[1,1,1,4]`, four middle blocks and decoder blocks `[1,1,1,1]`. The output is a three-channel residual added to the **original RGB input**, including for nine-channel conditions.

| Condition | Input/extra computation |
|---|---|
| `rgb` | RGB-only NAFNet |
| `zero_maps` | RGB plus six zero channels |
| `learned_maps` | RGB plus three spatial maps and three broadcast global channels |
| `capacity` | RGB-only NAFNet plus a `32→19→19→32` residual feature block |

The map head has two `3×3`, 16-channel convolutions with SiLU, then separate linear spatial (`1×1`) and pooled global projections. Both are unconstrained representations. Map heads start with small nonzero weights; extra input weights are nonzero so gradients reach every map parameter immediately. The capacity block uses `1×1`, `3×3`, `1×1` convolutions, SiLU between layers, and a small nonzero final projection. Shared backbone weights and RGB input weights are identical within each seed.

The capacity control matches the **added** parameter budget within 2%; runtime and convolution/linear MACs are measured separately. It cannot rule out every possible architectural explanation of a gain. The zero-map control checks the expanded input interface; auxiliary input weights receiving only zero values do not learn.

The standalone NAFNet code is extracted from upstream revision `2b4af71ebe098a92a75910c233a3965a3e93ede4`. The original files, content hashes and full MIT/BasicSR notices are retained under `third_party/nafnet/`. Imports and unused local-inference code are removed; the deprecated `saved_variables` API is replaced with `saved_tensors`. Reflection padding and the RGB-only residual output are implemented in the experiment wrapper. Source: <https://github.com/megvii-research/NAFNet>.

## Frozen scientific protocol

| Dataset | Training | Validation | Test |
|---|---:|---:|---:|
| LOL-v2 Real | 620 | 69 | 100 (existing official test) |
| UIEB | 720 | 80 | 90 |
| LSUI | 3423 | 428 | 428 |

Input/reference filenames and dimensions must match and every file must decode. Manifests record file and decoded-RGB SHA-256 hashes, dimensions and split identity. The audit found repeated inputs/references, so the simple shuffled split was refined **before training** to hold exact duplicate and conservative near-duplicate groups together while retaining the planned counts. Near-duplicate candidates use dHash distance ≤3 and aligned 16×16 RGB thumbnail MSE ≤0.000625; they are conservatively grouped rather than claimed to be proven duplicates. Any group crossing LOL's official train/test boundary aborts preparation. Inspect `audit` in each manifest and `cross_dataset_audit.json`.

These custom splits do not reproduce the notebook's sorted UIEB T90 partition. Automated image checks do not establish subject/scene independence. Datasets are trained separately; overlap between UIEB and LSUI must not be counted as independent evidence or used for unreviewed cross-dataset transfer.

Training uses paired 256-pixel random crops and synchronized horizontal/vertical flips, no resizing or normalization beyond RGB `[0,1]`. Images smaller than a crop are reflection padded. Crop/flip choices depend only on filename, seed and epoch; shuffle order uses a separate epoch generator. The same samples, order and augmentations are used across conditions within a seed.

Train 100 epochs with float32, batch size 8, L1 loss, AdamW (`lr=2e-4`, default betas/epsilon, zero weight decay, `foreach=False`) and cosine decay to zero. No early stopping, auxiliary loss, pretrained weights, test-time adaptation or augmentation. Select the first checkpoint attaining the highest validation RGB PSNR. Model outputs remain unclipped during training.

Evaluation runs each complete image at native resolution, batch size one, reflection padding to a multiple of 16 and removal of padding afterward. Predictions are clipped to `[0,1]` for metrics. RGB PSNR uses one MSE over all RGB pixels per image, followed by an unweighted image mean. SSIM uses an 11×11 Gaussian window, sigma 1.5, population covariance, valid-window borders, constants `0.01²/0.03²`, and a mean over RGB channels and windows. PSNR error reduction uses float64; Gaussian SSIM uses float32. These definitions are tested against analytical cases and an independent NumPy reference.

Seeds are 0, 1 and 2. CUDA deterministic algorithms are required and TF32 is disabled. Cross-version/hardware replay is not guaranteed. Epoch-boundary resume restores optimizer, cosine scheduler and RNG state. Completed runs and evaluation results are not retrained or overwritten. Source/config/environment/data changes require a new experiment ID. Test evaluation happens after all training runs in a stage complete.

## Headless commands

Run from this directory with `conda activate ml-base`, or use `/home/heniath/miniforge3/envs/ml-base/bin/python` explicitly. No editable installation is needed.

```bash
python scripts/experiment.py prepare
python scripts/experiment.py verify-data
python -m pytest -q
python scripts/experiment.py smoke
python scripts/experiment.py run-stage --stage initial
python scripts/experiment.py run-stage --stage extension
python scripts/experiment.py summarize
```

`run-stage --stage all` runs the initial comparison (LOL-v2 Real and UIEB), evaluates it, then runs and evaluates the LSUI extension, sequentially on one GPU. Resume by repeating the same command; completed work is skipped. Global options precede the subcommand:

```bash
python scripts/experiment.py --data-root /path/to/Datasets --device cuda train --dataset uieb --condition learned_maps --seed 0
python scripts/experiment.py evaluate --dataset uieb --condition learned_maps --seed 0
```

For a distinct scientific condition, copy the YAML config, give it a **new experiment ID**, and pass `--config`. Do not modify the active experiment's source or config while it is running. `verify-data` recomputes all file hashes; normal startup checks frozen identities and hashes any file whose metadata changed. Preserve manifests when relocating data. Changing the configured data root changes run identity and requires a new output experiment.

`scripts/run_logged.py` runs both stages sequentially and retains `training.log` and `job_status.json`. Run it inside tmux to survive SSH disconnects; its file lock prevents two logged runners for the same experiment. The workstation session used for this experiment is `latent-maps-v1`. Monitor with `tmux attach -t latent-maps-v1`, or read the log without attaching. To detach from tmux, press `Ctrl-b`, then `d`. Regenerate the current inventory with `python scripts/experiment.py summarize` while training continues.

## Artifacts and interpretation

Outputs are under `outputs/predicted_maps_v1/`. `frozen_protocol.json`, `source_snapshot/` and copied manifests preserve the protocol and code used. Individual run directories contain `run.json`, `history.json`, `best.pt`, `last.pt`, completion markers, and later `per_image_test.csv`/`test_results.json`. A failure is recorded in `failure.json`; resume uses the last saved epoch. Updating `last.pt` and validation-selected `best.pt` is part of an active run, not replacement of completed historical results.

`reports/FINDINGS.md` and CSV tables track all 36 planned runs, cross-seed means/sample SD, paired seed/image differences against RGB, and the direct learned-map versus capacity-control comparison. These derived reports can be regenerated. `initial_complete.json` and `extension_complete.json` distinguish stages. Smoke resource reports have their own directories and are not benchmark results. Inference timings exclude loading/transfers and metrics, include model forward, and use an untimed first-image warmup; image shapes differ, so compare on the same dataset. Reported memory is peak PyTorch allocation, not total driver VRAM.

Evidence is stronger if learned maps improve consistently over both RGB and the capacity control. Preserve negative and inconsistent outcomes. Three seeds alone do not establish significance. LOL-v1, LOL-v2 Synthetic, physical constraints and cross-dataset transfer remain separate follow-ups.
