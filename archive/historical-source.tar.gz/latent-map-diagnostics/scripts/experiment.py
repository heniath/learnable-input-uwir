#!/usr/bin/env python3
# ruff: noqa: E402
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [
    str(ROOT / "src"),
    str(ROOT / "third_party/upstream/src"),
    str(ROOT / "third_party/nafnet"),
]

from diagnostics.cli import main

if __name__ == "__main__":
    main()
