# Targeted novelty assessment — 2026-10-15

Workflow: nature-academic-search, multi-source-search. Academic MCP tools were
unavailable; public endpoint preflight passed and OpenAlex discovery returned
literature. Primary arXiv/publisher texts and author code were inspected. This is
a targeted comparison, not exhaustive novelty clearance. No published paper
scores are directly compared with local validation scores.

| Primary source | Established capability | Difference and remaining overlap |
|---|---|---|
| [Ucolor, TIP 2021](https://arxiv.org/html/2104.13015v1) | Prior-derived reverse transmission guides decoder features; multi-color-space encoding | Your heads and input injection differ; transmission guidance itself is established |
| [MTUR-Net, 2022](https://arxiv.org/abs/2203.09414), [publisher method](https://www.mdpi.com/2076-3417/12/11/5420) | Predicts a transmission map with map supervision and guides enhancement features | Your heads use restoration supervision only; predicting and using maps is established |
| [GUPDM, ACM MM 2023](https://arxiv.org/abs/2308.05447), [publisher](https://doi.org/10.1145/3581783.3612323) | Atmosphere/transmission-guided dynamic structures generate enhancement parameters | Different injection mechanism; adaptive physical/degradation conditioning is established |
| [Cheng et al., Neurocomputing 2025](https://doi.org/10.1016/j.neucom.2024.129270) | Estimates transmission/background light for enhancement/degradation within CycleGAN, with map-consistency losses | Unpaired physical inversion differs from your paired latent-map concatenation; joint map estimation is established |
| [CPLDP, AAAI 2026](https://ojs.aaai.org/index.php/AAAI/article/view/38176), [author code](https://github.com/yg76cv/CPLDP) | Learns degradation-aware prompts with frozen CLIP encoders, then conditions enhancement | Your method avoids CLIP/degradation labels; generic learned degradation conditioning remains established |
| [PROTEUS, August 2026 preprint](https://arxiv.org/html/2608.08661v1) | Gray-Edge spatial guidance, dynamic feature adaptation and bottleneck latent control of skips | Different source/injection/regularization; broad spatial-guidance and latent-control claims overlap. Preprint status is retained |
| Your prior EIDT paper, supplied PDF | Controlled fixed-prior input ablation on one U-Net; individual/joint maps; UIEB/EUVP and three seeds | Controlled input comparison is already your contribution; the next study must add a demonstrable finding beyond it |

## Current evidence boundary

Completed seed-0 diagnostics show U-Net gains of +1.5713 dB bounded/+1.5239 dB
unbounded over RGB, versus +0.1789 dB for the capacity control. NAFNet loses with
random map-input weights; zero initialization recovers a substantial part of the
loss without beating RGB. These observations support investigating representation
and optimization dependence. They do not establish a new general method or
physical semantics. A different implementation alone is not sufficient novelty.

The most defensible current paper direction is an evidence-grounded study of
when learned conditioning helps and what explains its utility. The immediate
replication can assess repeatability; local/global matched training ablations,
fixed-versus-learned controls, broader backbone/dataset evidence and a demonstrated
mechanism remain prospective. No specific new module is claimed here.

## Conference feasibility

A strong novel finding can matter without winning every metric; [CVPR 2026
reviewer guidance](https://cvpr.thecvf.com/Conferences/2026/ReviewerGuidelines)
weighs knowledge advance and impact alongside performance. This is guidance
from a completed conference cycle, not a current submission deadline or promise
of acceptance. Current single-seed evidence is insufficient for a strong
major-conference claim. Select the venue after the contribution and evidence
are established; verify that target's then-current rules.
