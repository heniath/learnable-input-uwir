# Test evaluation after U-Net architecture screening

The user explicitly requested test evaluation on 2026-10-21 after the original
validation-only screening protocol was frozen. This separate evaluation extends
reporting scope without changing the training, promotion rule or source snapshots.

Run after `latent-map-unet-screen/outputs/unet_arch_screen_v1/complete.json` exists:

```bash
/home/heniath/miniforge3/envs/uieb-latent-repro/bin/python scripts/evaluate.py
```

Evaluate both the validation-selected checkpoint (which can remain at epoch 0)
and the fixed final epoch-6 checkpoint for every completed screening run. Include
the original RGB/bounded/capacity U-Net references and the already selected seed-0
NAFNet RGB checkpoint. All evaluation uses the inherited UIEB test90 and
256-pixel resize/center-crop, float32, clipped per-image PSNR/SSIM. Every checkpoint
must reproduce validation before test inference. Model selection remains based
on validation; final-epoch scores are descriptive and do not choose a model.

The runner refuses incomplete training or output replacement, verifies source,
data/checkpoint identities, freezes all checkpoint choices before inference, and
records per-image metrics, hashes and results separately. Historical test exposure
is retained; these are not native-resolution SOTA benchmark numbers.
