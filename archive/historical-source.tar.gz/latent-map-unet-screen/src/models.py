"""Small identity-initialized extensions of the existing bounded-map U-Net."""

import torch
from torch import nn
from torch.nn import functional as F

from diagnostics.models import EnhancementModel


class ScreenUNet(nn.Module):
    def __init__(self, condition, seed, residual_scale=0.1, skip_gate_scale=0.5):
        super().__init__()
        if condition not in ("control", "residual_refine", "multiscale", "skip_gate"):
            raise ValueError(condition)
        self.condition = condition
        self.base = EnhancementModel("unet", "bounded", seed)
        self.residual_scale = residual_scale
        self.skip_gate_scale = skip_gate_scale
        self.projections = nn.ModuleDict()
        if condition == "residual_refine":
            self.projections["output"] = nn.Conv2d(64, 3, 3, padding=1)
        elif condition == "multiscale":
            for name, channels in (("e2", 128), ("e3", 256), ("e4", 512)):
                self.projections[name] = nn.Conv2d(6, channels, 1)
        elif condition == "skip_gate":
            for name, channels in (("e1", 64), ("e2", 128), ("e3", 256), ("e4", 512)):
                self.projections[name] = nn.Conv2d(6, channels, 1)
        for layer in self.projections.values():
            nn.init.zeros_(layer.weight)
            nn.init.zeros_(layer.bias)

    def forward(self, rgb):
        if rgb.ndim != 4 or rgb.shape[1:] != (3, 256, 256):
            raise ValueError(f"Expected N×3×256×256, got {tuple(rgb.shape)}")
        spatial, global_map = self.base.extract_maps(rgb)
        maps = torch.cat((spatial, global_map), dim=1)
        b = self.base.backbone
        e1 = b.enc1(torch.cat((rgb, maps), dim=1))
        e2 = b.enc2(e1)
        if self.condition == "multiscale":
            e2 = e2 + self.projections["e2"](F.adaptive_avg_pool2d(maps, e2.shape[-2:]))
        e3 = b.enc3(e2)
        if self.condition == "multiscale":
            e3 = e3 + self.projections["e3"](F.adaptive_avg_pool2d(maps, e3.shape[-2:]))
        e4 = b.enc4(e3)
        if self.condition == "multiscale":
            e4 = e4 + self.projections["e4"](F.adaptive_avg_pool2d(maps, e4.shape[-2:]))
        bottleneck = b.bottleneck(e4)
        skips = {"e1": e1, "e2": e2, "e3": e3, "e4": e4}
        if self.condition == "skip_gate":
            skips = {
                name: features * (1 + self.skip_gate_scale * torch.tanh(
                    self.projections[name](F.adaptive_avg_pool2d(maps, features.shape[-2:]))))
                for name, features in skips.items()
            }
        d4 = b.dec4(bottleneck, skips["e4"])
        d3 = b.dec3(d4, skips["e3"])
        d2 = b.dec2(d3, skips["e2"])
        d1 = b.dec1(d2, skips["e1"])
        prediction = b.head(d1)
        if self.condition == "residual_refine":
            prediction = prediction + self.residual_scale * torch.tanh(self.projections["output"](d1))
        return prediction
