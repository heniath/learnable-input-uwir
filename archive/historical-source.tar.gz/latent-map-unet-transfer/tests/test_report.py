import csv

from latent_maps.report import summarize
from latent_maps.utils import atomic_json, load_config


def test_report_compares_matched_seeds_and_capacity(tmp_path):
    config = load_config()
    config["seeds"] = [0, 1]
    config["conditions"] = ["rgb", "learned_maps", "capacity"]
    config["stages"] = {"initial": ["synthetic_fixture"]}
    for seed in config["seeds"]:
        for condition, delta in (("rgb", 0), ("learned_maps", 2), ("capacity", 1)):
            directory = (
                tmp_path / "runs" / "synthetic_fixture" / condition / f"seed_{seed}"
            )
            directory.mkdir(parents=True)
            # Synthetic metric fixtures only; never benchmark artifacts.
            score = 20 + seed + delta
            atomic_json(
                directory / "test_results.json",
                {
                    "test": {"psnr": score, "ssim": 0.8, "inference_ms": 1},
                    "checkpoint_epoch": 1,
                },
            )
            (directory / "per_image_test.csv").write_text(
                f"id,psnr,ssim\nfixture,{score},0.8\n"
            )
    inventory = summarize(config, tmp_path)
    assert len(inventory) == 6 and all(r["status"] == "evaluated" for r in inventory)
    with (tmp_path / "reports/paired_seed_differences.csv").open() as f:
        differences = list(csv.DictReader(f))
    direct = [r for r in differences if r["reference_condition"] == "capacity"]
    assert len(direct) == 2
    assert all(float(r["psnr_delta"]) == 1 for r in direct)
    with (tmp_path / "reports/cross_seed_summary.csv").open() as f:
        summaries = list(csv.DictReader(f))
    assert all(r["complete"] == "True" for r in summaries)


def test_partial_validation_keeps_available_seeds_and_defers_decision(tmp_path):
    import json

    config = load_config()
    config["stages"] = {"initial": ["synthetic_fixture"]}
    for condition, delta in (("rgb", 0), ("learned_maps", 2), ("capacity", 1)):
        directory = tmp_path / "runs" / "synthetic_fixture" / condition / "seed_0"
        directory.mkdir(parents=True)
        # Synthetic fixtures only: absent seeds must never count as zeros or evidence.
        atomic_json(
            directory / "validation_results.json",
            {
                "validation": {"psnr": 20 + delta, "ssim": 0.8 + delta * 0.01},
                "checkpoint_epoch": 3,
            },
        )
    summarize(config, tmp_path)
    with (tmp_path / "reports/validation_summary.csv").open() as stream:
        summary = list(csv.DictReader(stream))
    assert len(summary) == 3
    assert all(r["n_seeds"] == "1" and r["seeds"] == "[0]" for r in summary)
    assert all(
        r["psnr_sample_sd"] == "" and r["complete_seeds"] == "False" for r in summary
    )
    screen = json.loads((tmp_path / "reports/screening.json").read_text())
    assert screen["passes_all_datasets_and_seeds"] is None
    assert not screen["all_training_complete"] and not screen["checks"]
    with (tmp_path / "reports/paired_validation_seed_differences.csv").open() as stream:
        paired = list(csv.DictReader(stream))
    direct = [r for r in paired if r["baseline"] == "capacity"]
    assert len(direct) == 1 and float(direct[0]["psnr_delta"]) == 1
