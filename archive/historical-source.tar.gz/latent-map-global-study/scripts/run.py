#!/usr/bin/env python3
"""Explicit follow-up operations; the logged runner owns the finite job queue."""

import argparse
import fcntl

import bootstrap

from global_study import protocol


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("prepare", "smoke", "report"):
        sub.add_parser(name)
    diagnostic = sub.add_parser("diagnose")
    diagnostic.add_argument("--phase", choices=("H1", "dimension"), required=True)
    diagnostic.add_argument("--condition", required=True)
    diagnostic.add_argument("--seed", type=int, required=True)
    training = sub.add_parser("train-dimension")
    training.add_argument("--dimension", type=int, choices=(1, 3, 6, 12), required=True)
    training.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    with (protocol.TRAINING / ".execution.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.command == "prepare":
            protocol.prepare()
        else:
            frozen = protocol.verify()
            if args.command == "smoke":
                from global_study.training import smoke
                smoke(frozen)
            elif args.command == "train-dimension":
                from global_study.training import train
                train(args.dimension, args.seed, frozen)
            elif args.command == "diagnose":
                from global_study.diagnostic import diagnose
                diagnose(args.phase, args.condition, args.seed, frozen)
            else:
                from global_study.report import report
                report(frozen)


if __name__ == "__main__":
    main()
