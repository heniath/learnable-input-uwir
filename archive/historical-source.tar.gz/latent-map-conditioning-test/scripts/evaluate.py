#!/usr/bin/env python3
"""Evaluate frozen H1/H2 validation-selected checkpoints on historical UIEB test90."""

import argparse
import csv
import fcntl
import json
import math
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
TRAINING = ROOT.parent / "latent-map-conditioning"
PARENT = ROOT.parent / "latent-map-diagnostics"
sys.path[:0] = [str(TRAINING / "src"), str(PARENT / "src"),
                str(PARENT / "third_party/upstream/src"), str(PARENT / "third_party/nafnet")]

import numpy as np
import torch
from PIL import Image, ImageDraw

from conditioning.models import ConditionedUNet
from conditioning.protocol import read_config, validate_manifest, verify
from diagnostics.diagnose import metric_rows
from diagnostics.protocol import atomic_json, base_dataset, canonical, digest, seed_original

STUDIES = {"H1": "h1_pilot_v2.json", "H2": "h2_pilot_v2.json"}
BASELINES = {"H1": "A0_rgb", "H2": "B0_input"}
TOLERANCES = {"psnr": 0.001, "ssim": 0.00001}


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_csv(path, rows):
    with path.open("x", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def indexed(rows, expected_names):
    result = {row["filename"]: row for row in rows}
    if len(result) != len(rows) or list(result) != expected_names:
        raise ValueError("Metric filenames/order/count differ from the frozen manifest")
    if not all(math.isfinite(float(row[key])) for row in rows for key in ("psnr", "ssim")):
        raise FloatingPointError("Non-finite per-image metrics")
    return result


def inventory():
    items, studies, shared_manifest = [], {}, None
    for phase, name in STUDIES.items():
        config_path, config = read_config(TRAINING / "configs" / name)
        frozen = verify(config_path, config)
        archive = TRAINING / "outputs" / config["experiment_id"]
        manifest = json.loads((archive / "manifest.json").read_text())
        validate_manifest(manifest)
        if shared_manifest is not None and manifest != shared_manifest:
            raise ValueError("H1/H2 dataset manifests differ")
        shared_manifest = manifest
        if config["phase"] != phase or config["seeds"] != [0] or len(config["conditions"]) != 4:
            raise ValueError("Expected the four completed seed-0 pilot conditions per phase")
        if config["budget"] != {"epochs": 30, "scheduler_epochs": 100,
                                 "early_stopping": False, "initialization": "from_scratch"}:
            raise ValueError("Pilot training budget changed")
        studies[phase] = {"experiment_id": config["experiment_id"], "frozen_identity": canonical(frozen),
                          "environment": frozen["environment"], "frozen_sha256": digest(archive / "frozen.json")}
        for condition in config["conditions"]:
            directory = archive / "runs/seed_0" / condition
            complete = json.loads((directory / "complete.json").read_text())
            run = json.loads((directory / "run.json").read_text())
            identity = {"condition": condition, "seed": 0, "frozen_identity": canonical(frozen)}
            if complete["identity"] != identity or any(run[key] != value for key, value in identity.items()):
                raise ValueError(f"Run identity mismatch: {directory}")
            if run["config"] != config or complete["final_epoch"] != 30:
                raise ValueError(f"Incomplete or changed training run: {directory}")
            if digest(directory / "best.pt") != complete["best_sha256"]:
                raise ValueError(f"Checkpoint hash mismatch: {directory}")
            if digest(directory / "metrics_per_image.csv") != complete["per_image_sha256"]:
                raise ValueError(f"Validation artifact hash mismatch: {directory}")
            names = [manifest["pairs"][i]["filename"] for i in manifest["indices"]["validation"]]
            with (directory / "metrics_per_image.csv").open() as handle:
                saved = list(csv.DictReader(handle))
            indexed(saved, names)
            for key in ("psnr", "ssim"):
                if abs(np.mean([float(row[key]) for row in saved]) - complete["best"][key]) > 1e-5:
                    raise ValueError("Saved validation means do not reproduce checkpoint selection")
            items.append({"phase": phase, "condition": condition, "seed": 0,
                          "identity": identity, "checkpoint": str(directory / "best.pt"),
                          "checkpoint_sha256": complete["best_sha256"],
                          "validation_csv": str(directory / "metrics_per_image.csv"),
                          "validation_csv_sha256": complete["per_image_sha256"],
                          "complete_sha256": digest(directory / "complete.json"),
                          "selected": complete["best"], "parameters": complete["parameters"]})
    if set(shared_manifest["indices"]["test"]) != set(range(800, 890)):
        raise ValueError("Historical test90 partition changed")
    return items, studies, shared_manifest


def batches_for(dataset, manifest, split):
    indices = manifest["indices"][split]
    if any(manifest["pairs"][i]["split"] != split for i in indices):
        raise ValueError("Manifest split membership mismatch")
    c = json.loads((PARENT / "configs/protocol.json").read_text())
    batches = [(x, y, list(names)) for x, y, names, _ in torch.utils.data.DataLoader(
        torch.utils.data.Subset(dataset, indices), batch_size=c["batch_size"],
        num_workers=c["workers"], shuffle=False, pin_memory=True, drop_last=False)]
    names = [manifest["pairs"][i]["filename"] for i in indices]
    if [name for _, _, batch_names in batches for name in batch_names] != names:
        raise ValueError(f"Dataset order mismatch: {split}")
    if len(names) != {"validation": 80, "test": 90}[split]:
        raise ValueError(f"Unexpected split count: {split}")
    return batches


def load_model(item):
    if digest(item["checkpoint"]) != item["checkpoint_sha256"]:
        raise ValueError("Checkpoint changed after inventory")
    seed_original(item["seed"])
    model = ConditionedUNet(item["condition"], item["seed"])
    state = torch.load(item["checkpoint"], map_location="cpu", weights_only=False)
    if state["identity"] != item["identity"] or state["best"] != item["selected"]:
        raise ValueError("Loaded checkpoint identity/selection mismatch")
    model.load_state_dict(state["model"], strict=True)
    if model.parameter_counts() != item["parameters"]:
        raise ValueError("Loaded model parameter counts differ from training")
    return model.cuda().eval()


def image_from(tensor):
    array = tensor.detach().float().cpu().permute(1, 2, 0).numpy()
    return Image.fromarray(np.rint(array.clip(0, 1) * 255).astype(np.uint8))


@torch.inference_mode()
def validation_anchor(item, batches, expected_names, directory):
    model = load_model(item)
    rows = []
    for x, y, names in batches:
        rows.extend(metric_rows(model(x.cuda()), y, names))
    indexed(rows, expected_names)
    with Path(item["validation_csv"]).open() as handle:
        saved = indexed(list(csv.DictReader(handle)), expected_names)
    drift = {key: max(abs(row[key] - float(saved[row["filename"]][key])) for row in rows)
             for key in ("psnr", "ssim")}
    if any(drift[key] > TOLERANCES[key] for key in TOLERANCES):
        raise ValueError(f"Validation reproduction failed: {item['condition']}, {drift}")
    write_csv(directory / "per_image_validation.csv", rows)
    atomic_json(directory / "validation_anchor.json", {"max_per_image_drift": drift,
                                                       "n": len(rows), "checkpoint_sha256": item["checkpoint_sha256"]})
    del model
    torch.cuda.empty_cache()
    return drift


@torch.inference_mode()
def evaluate(item, batches, expected_names, directory, drift):
    model = load_model(item)
    images = directory / "predictions"
    images.mkdir()
    rows, examples = [], {}
    example_names = set(expected_names[:6])
    for x, y, names in batches:
        prediction = model(x.cuda())
        if prediction.shape != y.shape or prediction.dtype != torch.float32:
            raise ValueError("Prediction shape/precision mismatch")
        rows.extend(metric_rows(prediction, y, names))
        for name, tensor in zip(names, prediction):
            image = image_from(tensor)
            # Retain the entire original name to avoid stem collisions.
            image.save(images / f"{name}.png")
            if name in example_names:
                examples[name] = image
    indexed(rows, expected_names)
    if len(list(images.glob("*.png"))) != 90:
        raise ValueError("Expected 90 saved predictions")
    write_csv(directory / "per_image_test.csv", rows)
    result = {"phase": item["phase"], "condition": item["condition"], "seed": item["seed"],
              "selected_epoch": item["selected"]["epoch"], "n_test": len(rows),
              "validation_psnr": item["selected"]["psnr"], "validation_ssim": item["selected"]["ssim"],
              "test_psnr": float(np.mean([row["psnr"] for row in rows])),
              "test_ssim": float(np.mean([row["ssim"] for row in rows])),
              "max_validation_psnr_drift": drift["psnr"], "max_validation_ssim_drift": drift["ssim"],
              "checkpoint_sha256": item["checkpoint_sha256"]}
    atomic_json(directory / "result.json", result)
    del model
    torch.cuda.empty_cache()
    return result, rows, examples


def summarize(results, per_image, output, expected_names):
    paired, details = [], []
    for result in results:
        phase, condition = result["phase"], result["condition"]
        baseline = BASELINES[phase]
        if condition == baseline:
            continue
        base = indexed(per_image[(phase, baseline)], expected_names)
        rows = indexed(per_image[(phase, condition)], expected_names)
        differences = [{"phase": phase, "condition": condition, "baseline": baseline, "filename": name,
                        "delta_psnr": rows[name]["psnr"] - base[name]["psnr"],
                        "delta_ssim": rows[name]["ssim"] - base[name]["ssim"]} for name in expected_names]
        details.extend(differences)
        delta = [row["delta_psnr"] for row in differences]
        paired.append({"phase": phase, "condition": condition, "baseline": baseline, "seed": 0, "n": len(delta),
                       "delta_test_psnr": float(np.mean(delta)),
                       "delta_test_ssim": float(np.mean([row["delta_ssim"] for row in differences])),
                       "median_delta_test_psnr": float(np.median(delta)), "test_psnr_wins": sum(x > 0 for x in delta)})
    write_csv(output / "results.csv", results)
    write_csv(output / "paired_test_differences.csv", paired)
    write_csv(output / "paired_per_image.csv", details)
    atomic_json(output / "results.json", {"results": results, "paired_differences": paired,
                                          "n_seeds": 1, "seed_sample_sd": None})
    lines = ["# H1/H2 pilot: validation-selected UIEB test90 inference", "",
             "Eight fixed best.pt checkpoints; seed 0, 30 training epochs per condition.",
             "All validation reproduction checks passed before any test inference.", ""]
    for phase in STUDIES:
        lines += [f"## {phase}", "", f"Test differences use {BASELINES[phase]} as the within-study baseline.", "",
                  "| Condition | Selected epoch | Val PSNR | Val SSIM | Test PSNR | Test SSIM | Delta test PSNR |",
                  "|---|---:|---:|---:|---:|---:|---:|"]
        baseline = next(row for row in results if row["phase"] == phase and row["condition"] == BASELINES[phase])
        for row in results:
            if row["phase"] == phase:
                delta = row["test_psnr"] - baseline["test_psnr"]
                lines.append(f"| {row['condition']} | {row['selected_epoch']} | {row['validation_psnr']:.5f} | "
                             f"{row['validation_ssim']:.6f} | {row['test_psnr']:.5f} | {row['test_ssim']:.6f} | {delta:+.5f} |")
        lines.append("")
    lines += ["## Paired test differences", "", "| Phase | Condition | Baseline | Delta PSNR | Delta SSIM | PSNR wins / 90 |",
              "|---|---|---|---:|---:|---:|"]
    for row in paired:
        lines.append(f"| {row['phase']} | {row['condition']} | {row['baseline']} | {row['delta_test_psnr']:+.5f} | "
                     f"{row['delta_test_ssim']:+.6f} | {row['test_psnr_wins']} |")
    lines += ["", "## Protocol and interpretation limits", "",
              "Historical UIEB test90 (sorted indices 800:890), inherited shorter-edge resize 256 and aligned center crop 256; "
              "RGB [0,1], batch size 4, float32 inference, no AMP/TTA/ensemble. Predictions are clipped for the original "
              "per-image PSNR/SSIM implementations and metrics are arithmetic means over the same 90 images.", "",
              "Checkpoint identities were frozen before evaluation. Maximum per-image validation reproduction tolerance: "
              "0.001 dB PSNR and 0.00001 SSIM. No test result changes model selection or training.", "",
              "All 90 predictions per checkpoint are saved as PNG; metrics use float predictions before quantization. "
              "H1/H2 contact sheets show the first six frozen test filenames, chosen before inference.", "",
              "One seed per condition: no cross-seed uncertainty or statistical significance is established. H1 and H2 use "
              "their own baselines; H1 A3_both and H2 B0_input remain separate training realizations. Active parameter/compute "
              "budgets differ. Pilot training does not establish convergence. Historical test exposure and unresolved scene "
              "independence remain; these are not previously unseen native-resolution benchmark results.", "",
              "Training source, configs, checkpoints and reports remain unchanged. See protocol.json, validation_anchor.json "
              "files, execution.log and complete.json for provenance, verification, runtime and artifact hashes."]
    (output / "FINDINGS.md").write_text("\n".join(lines) + "\n")


def contact_sheet(phase, batches, examples, conditions, output):
    samples = [(name, image_from(x[i]), image_from(y[i]))
               for x, y, names in batches for i, name in enumerate(names)][:6]
    width, height = 256, 286
    sheet = Image.new("RGB", ((2 + len(conditions)) * width, len(samples) * height), "white")
    draw = ImageDraw.Draw(sheet)
    for row, (name, raw, reference) in enumerate(samples):
        columns = [("Input", raw), ("Reference", reference)]
        columns += [(condition, examples[(phase, condition)][name]) for condition in conditions]
        for col, (label, image) in enumerate(columns):
            left, top = col * width, row * height
            draw.text((left + 4, top + 2), label, fill="black")
            draw.text((left + 4, top + 14), name, fill="black")
            sheet.paste(image, (left, top + 28))
    sheet.save(output / f"comparison_{phase}_seed0.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", default="conditioning_pilots_test90_v1")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", args.run_id):
        parser.error("run-id must be a single safe directory name")
    output = ROOT / "outputs" / args.run_id
    output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()

    def log(message):
        line = f"{utc()} {message}"
        print(line, flush=True)
        with (output / "execution.log").open("a") as handle:
            handle.write(line + "\n")

    def status(stage, **kwargs):
        atomic_json(output / "job_status.json", {"stage": stage, "updated_utc": utc(), **kwargs})

    try:
        # Hold the existing training command lock for the entire evaluation.
        with (TRAINING / ".execution.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            status("preflight")
            gpu = subprocess.check_output(["nvidia-smi"], text=True)
            (output / "nvidia-smi.txt").write_text(gpu)
            processes = subprocess.check_output(
                ["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader"], text=True)
            active = [row for row in csv.reader(processes.splitlines()) if row and row[1].strip()
                      != "/usr/libexec/gnome-remote-desktop-daemon"]
            if active:
                raise RuntimeError(f"Other GPU compute processes are active: {active}")
            if not torch.cuda.is_available():
                raise RuntimeError("PyTorch CUDA unavailable")
            log("Verifying both frozen studies, all completed checkpoints and dataset hashes")
            items, studies, manifest = inventory()
            test_names = [manifest["pairs"][i]["filename"] for i in manifest["indices"]["test"]]
            validation_names = [manifest["pairs"][i]["filename"] for i in manifest["indices"]["validation"]]
            atomic_json(output / "protocol.json", {
                "run_id": args.run_id, "utc": utc(), "studies": studies, "checkpoints": items,
                "manifest_sha256": canonical(manifest), "script_sha256": digest(__file__),
                "authorization": "User explicitly requested inference test of both H1 and H2",
                "selection": "Existing validation-selected best.pt; no test-based selection",
                "dataset": "Historical UIEB test90", "test_names": test_names,
                "precision": "float32", "preprocessing": "Inherited shorter-edge resize 256 then aligned center crop 256",
                "metrics": "Original uwir per-image PSNR/SSIM on clipped float predictions; arithmetic image mean",
                "validation_max_per_image_tolerance": TOLERANCES,
                "examples": test_names[:6], "saved_predictions_per_checkpoint": 90,
                "limits": "One seed; prior test exposure; unresolved scene independence; pilot training; no native-resolution claim",
            })
            shutil.copyfile(__file__, output / "evaluate.py")
            shutil.copyfile(ROOT / "README.md", output / "README.md")
            seed_original(0)
            dataset = base_dataset(augment=False)
            validation = batches_for(dataset, manifest, "validation")
            drifts = {}
            for item in items:
                key = (item["phase"], item["condition"])
                directory = output / item["phase"] / "seed_0" / item["condition"]
                directory.mkdir(parents=True)
                status("validation", phase=key[0], condition=key[1])
                drifts[key] = validation_anchor(item, validation, validation_names, directory)
                log(f"{key}: validation passed, max per-image drift={drifts[key]}")
            log("All eight validation anchors passed; starting fixed test inference")
            test = batches_for(dataset, manifest, "test")
            torch.cuda.reset_peak_memory_stats()
            results, per_image, examples = [], {}, {}
            for item in items:
                key = (item["phase"], item["condition"])
                status("test", phase=key[0], condition=key[1])
                directory = output / item["phase"] / "seed_0" / item["condition"]
                result, per_image[key], examples[key] = evaluate(item, test, test_names, directory, drifts[key])
                results.append(result)
                log(f"{key}: test PSNR={result['test_psnr']:.5f}, SSIM={result['test_ssim']:.6f}; 90 PNGs saved")
            summarize(results, per_image, output, test_names)
            for phase in STUDIES:
                conditions = [item["condition"] for item in items if item["phase"] == phase]
                contact_sheet(phase, test, examples, conditions, output)
            for item in items:
                directory = Path(item["checkpoint"]).parent
                if (digest(item["checkpoint"]) != item["checkpoint_sha256"]
                        or digest(item["validation_csv"]) != item["validation_csv_sha256"]
                        or digest(directory / "complete.json") != item["complete_sha256"]):
                    raise ValueError("Training artifacts changed during evaluation")
            status("complete", checkpoints=8, test_predictions=720)
            log("Complete: 8 checkpoints, 720 test predictions; training artifacts unchanged")
            atomic_json(output / "complete.json", {
                "utc": utc(), "elapsed_seconds": time.perf_counter() - started,
                "checkpoints": len(results), "test_predictions": len(results) * 90,
                "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                "resource_scope": "Peak CUDA allocated memory during model loading and test evaluation; not a latency benchmark",
                "artifact_hashes": {str(path.relative_to(output)): digest(path)
                                    for path in output.rglob("*") if path.is_file()},
            })
    except BaseException as error:
        status("failed", error=repr(error))
        atomic_json(output / "failure.json", {"utc": utc(), "error": repr(error)})
        raise


if __name__ == "__main__":
    main()
