import math

import pytest
import torch

from latent_maps._nafnet import LayerNorm2d
from latent_maps.metrics import rgb_metrics
from latent_maps.models import EnhancementModel, parameter_count


@pytest.fixture(autouse=True)
def limited_threads():
    torch.set_num_threads(2)


def small(condition):
    return EnhancementModel(
        condition,
        seed=7,
        width=8,
    )


def test_shared_initialization_and_zero_channels_preserve_rgb_predictions():
    baseline = small("rgb")
    zero = small("zero_maps")
    learned = small("learned_maps")
    capacity = small("capacity")
    for name, p in baseline.backbone.state_dict().items():
        for model in (zero, learned, capacity):
            target = model.backbone.state_dict()[name]
            if name == "enc1.net.0.weight":
                target = target[:, :3]
            assert torch.equal(p, target), name
    x = torch.rand(1, 3, 31, 35)
    with torch.no_grad():
        torch.testing.assert_close(baseline(x), zero(x), atol=1e-6, rtol=1e-5)
        # For divisible sizes, the RGB adaptation agrees with the original architecture.
        x = torch.rand(1, 3, 32, 48)
        torch.testing.assert_close(baseline(x), baseline.backbone(x))


@pytest.mark.parametrize("condition", ("rgb", "zero_maps", "learned_maps", "capacity"))
def test_odd_size_outputs_and_backward(condition):
    model = small(condition)
    x = torch.rand(2, 3, 27, 35)
    output, maps = model(x, return_maps=True)
    assert output.shape == x.shape
    assert torch.isfinite(output).all()
    (output - torch.rand_like(output)).abs().mean().backward()
    if model.map_predictor is not None:
        assert maps.shape == (2, 6, 27, 35)
        for name, p in model.map_predictor.named_parameters():
            assert (
                p.grad is not None
                and torch.isfinite(p.grad).all()
                and p.grad.abs().sum() > 0
            ), name
        assert torch.equal(maps[:, 3:, :1, :1].expand_as(maps[:, 3:]), maps[:, 3:])


def test_added_parameter_budget_matches():
    counts = {
        c: parameter_count(EnhancementModel(c))
        for c in ("rgb", "learned_maps", "capacity")
    }
    assert (
        abs(counts["learned_maps"] - counts["capacity"])
        / (counts["learned_maps"] - counts["rgb"])
        < 0.02
    )


def test_layernorm_gradcheck():
    layer = LayerNorm2d(4).double()
    x = torch.randn(1, 4, 3, 3, dtype=torch.float64, requires_grad=True)
    assert torch.autograd.gradcheck(layer, (x,), eps=1e-6, atol=1e-5)


def test_metrics_identity_and_analytical_constants():
    x = torch.rand(1, 3, 21, 19)
    result = rgb_metrics(x, x)
    assert math.isinf(result["psnr"])
    assert result["ssim"] == pytest.approx(1, abs=1e-6)
    zeros, ones = torch.zeros_like(x), torch.ones_like(x)
    result = rgb_metrics(zeros, ones)
    assert result["psnr"] == pytest.approx(0)
    assert result["ssim"] == pytest.approx(0.0001 / 1.0001, abs=1e-6)
    result = rgb_metrics(ones * 2, zeros)
    assert result["psnr"] == pytest.approx(
        0
    )  # Prediction clipping is part of evaluation.


def test_ssim_matches_independent_numpy_gaussian_reference():
    import numpy as np
    from numpy.lib.stride_tricks import sliding_window_view

    generator = np.random.default_rng(1)
    x, y = generator.random((3, 23, 25)), generator.random((3, 23, 25))
    coords = np.arange(11) - 5
    g = np.exp(-(coords**2) / (2 * 1.5**2))
    g /= g.sum()
    kernel = g[:, None] * g[None, :]

    def blur(a):
        return (sliding_window_view(a, (11, 11), axis=(-2, -1)) * kernel).sum((-2, -1))

    ux, uy = blur(x), blur(y)
    vx, vy, cov = blur(x * x) - ux * ux, blur(y * y) - uy * uy, blur(x * y) - ux * uy
    expected = (
        ((2 * ux * uy + 0.01**2) * (2 * cov + 0.03**2))
        / ((ux * ux + uy * uy + 0.01**2) * (vx + vy + 0.03**2))
    ).mean()
    result = rgb_metrics(torch.tensor(x[None]), torch.tensor(y[None]))
    assert result["ssim"] == pytest.approx(float(expected), abs=2e-6)


def test_nonfinite_inputs_rejected():
    x = torch.zeros(1, 3, 16, 16)
    x[0, 0, 0, 0] = float("nan")
    with pytest.raises(FloatingPointError):
        rgb_metrics(x, torch.zeros_like(x))
