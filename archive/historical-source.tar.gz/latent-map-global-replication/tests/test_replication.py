import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import bootstrap
import torch

from conditioning.models import ConditionedUNet
from diagnostics.protocol import PairedEpochDataset
from global_study.models import GlobalLatentUNet
from global_study.protocol import sources as old_sources
from global_study.training import make_objects as original_builder
from replication.experiment import make_objects
from replication.protocol import GLOBAL, config, diagnostic_directory, is_new, paired_history, require_new, run_directory
from replication.report import paired_effect, repeatability, summarize_seed_effects
from replication.report import report

torch.set_num_threads(2)


class ReplicationTests(unittest.TestCase):
    def test_exact_scope_budget_and_frozen_dependencies(self):
        c = config()
        self.assertEqual(c["new_runs"], [[6, 1], [12, 1], [6, 2], [12, 2]])
        frozen = json.loads((GLOBAL / "outputs/global_branch_followup_v1/frozen.json").read_text())
        self.assertEqual(c["budget"], frozen["config"]["budget"])
        self.assertEqual(old_sources(), frozen["sources"])
        self.assertIs(make_objects, original_builder)
        for d, s in ((3, 1), (6, 0), (1, 1), (6, 3)):
            with self.assertRaises(ValueError):
                require_new(d, s)
        with self.assertRaisesRegex(ValueError, "Test image prediction"):
            PairedEpochDataset("test")

    def test_reference_paths_reuse_existing_artifacts(self):
        for s in (0, 1, 2):
            self.assertFalse(is_new(3, s))
            self.assertTrue((run_directory(3, s) / "complete.json").exists())
            self.assertTrue((diagnostic_directory(3, s) / "complete.json").exists())
        for d in (6, 12):
            self.assertTrue((run_directory(d, 0) / "complete.json").exists())
            self.assertTrue((diagnostic_directory(d, 0) / "complete.json").exists())

    def test_seed12_model_initialization_matches_original_design(self):
        for seed in (1, 2):
            baseline = ConditionedUNet("A2_global", seed)
            for dimension in (6, 12):
                model = GlobalLatentUNet(dimension, seed)
                self.assertFalse(hasattr(model.base, "transmission_extractor"))
                torch.testing.assert_close(model.base.backbone.enc1.net[0].weight[:, :9],
                                           baseline.base.backbone.enc1.net[0].weight, rtol=0, atol=0)
                torch.testing.assert_close(model.base.background_extractor.net[-2].weight[:3],
                                           baseline.base.background_extractor.net[-2].weight, rtol=0, atol=0)
                self.assertEqual(model.parameter_counts()["dormant_input_weights"], 1728)

    def test_repeatability_pending_and_metric_tradeoff(self):
        a = dict(dimension=6, baseline_dimension=3, seed=1, delta_psnr=0.4, delta_ssim=0.01)
        b = dict(a, seed=2, delta_psnr=0.1, delta_ssim=0)
        self.assertIsNone(repeatability([a], 6)["passed"])
        self.assertTrue(repeatability([a, b], 6)["passed"])
        self.assertFalse(repeatability([a, dict(b, delta_psnr=-0.01)], 6)["passed"])
        self.assertFalse(repeatability([a, dict(b, delta_ssim=-0.00001)], 6)["passed"])
        self.assertFalse(repeatability([a, dict(b, delta_psnr=0)], 6)["passed"])

    def test_paired_seed_sd_and_filename_alignment(self):
        contrasts = [dict(dimension=6, baseline_dimension=3, seed=s, delta_psnr=p, delta_ssim=p/100)
                     for s, p in enumerate((1, 2, 3))]
        summary = summarize_seed_effects(contrasts)[0]
        self.assertEqual(summary["delta_psnr_mean"], 2)
        self.assertEqual(summary["delta_psnr_sample_sd"], 1)
        a = [dict(filename="b", psnr=21, ssim=0.9), dict(filename="a", psnr=23, ssim=0.95)]
        b = [dict(filename="a", psnr=22, ssim=0.94), dict(filename="b", psnr=19, ssim=0.8)]
        effect, _ = paired_effect(a, b)
        self.assertEqual(effect["delta_psnr"], 1.5)
        with self.assertRaises(ValueError):
            paired_effect(a, b[:1])

    def test_history_guard_rejects_schedule_and_input_mismatch(self):
        a = [dict(epoch=i, batch_hashes=[str(i)], lr=.001) for i in range(1, 31)]
        paired_history(a, a)
        b = [dict(r) for r in a]
        b[4]["lr"] = .002
        with self.assertRaises(ValueError):
            paired_history(a, b)
        b = [dict(r) for r in a]
        b[4]["batch_hashes"] = ["different augmentation"]
        with self.assertRaises(ValueError):
            paired_history(a, b)

    def test_partial_report_reuses_five_cells_without_false_confirmation(self):
        parent = json.loads((GLOBAL / "outputs/global_branch_followup_v1/frozen.json").read_text())
        from diagnostics.protocol import canonical
        frozen = {"parent_frozen_identity": canonical(parent), "references": {}}
        for dimension, seed in ((3, 0), (3, 1), (3, 2), (6, 0), (12, 0)):
            saved = json.loads((run_directory(dimension, seed) / "complete.json").read_text())
            frozen["references"][f"d{dimension}_seed{seed}"] = {"identity": saved["identity"]}
        with tempfile.TemporaryDirectory(prefix="global-replication-report-") as temporary:
            output = Path(temporary)
            with patch("replication.report.output_root", return_value=output):
                report(frozen)
            result = json.loads((output / "reports/results.json").read_text())
            self.assertEqual(len(result["cells"]), 5)
            self.assertEqual(len(result["diagnostics"]), 5)
            self.assertEqual(len(result["missing"]), 8)
            self.assertTrue(all(r["passed"] is None for r in result["repeatability"]))
            self.assertFalse((output / "complete.json").exists())


if __name__ == "__main__":
    unittest.main()
