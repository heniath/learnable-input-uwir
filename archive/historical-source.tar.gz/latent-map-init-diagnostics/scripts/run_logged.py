#!/usr/bin/env python3
"""Run the frozen five-condition initialization study, diagnose, and report."""

import fcntl
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "configs/protocol.json").read_text())
OUT = ROOT / "outputs" / CONFIG["experiment_id"]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / ".runner.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (OUT / "reports/report_complete.json").exists():
            print("Study complete; preserving all results", flush=True)
            return
        started = datetime.now(timezone.utc).isoformat()

        def status(value):
            temporary = OUT / "job_status.json.tmp"
            temporary.write_text(
                json.dumps(
                    {
                        "started_utc": started,
                        "utc": datetime.now(timezone.utc).isoformat(),
                        **value,
                    },
                    indent=2,
                )
                + "\n"
            )
            os.replace(temporary, OUT / "job_status.json")
            (ROOT / "HANDOFF.md").write_text(
                "# Map-input initialization study handoff\n\n"
                f"Status: **{value['status']}**. Runner invocation started UTC: {started}.\n\n"
                f"Current/final stage: `{value.get('stage', 'all stages complete')}`.\n\n"
                "Five fresh NAFNet runs: rgb, bounded, bounded_zero_init, unbounded, "
                "unbounded_zero_init; seed 0. Original early stopping retained.\n\n"
                "Outputs: `outputs/map_init_diagnostics_v1/`. Check `job_status.json`, "
                "`training.log`, and each condition's `seed_0/history.json`.\n\n"
                "Final deliverables: `reports/FINDINGS.md`, `results.json`, `results.csv`, "
                "`paired_validation_differences.csv`, `convergence.csv`, "
                "`common_horizon_scores.csv`, then `reports/report_complete.json`.\n\n"
                "Persistent tmux session: `latent-map-init-diagnostics`. Do not supervise "
                "continuously; check when returning. Do not start a duplicate runner.\n\n"
                "After an actual interruption, inspect status, tmux, processes and GPU first. "
                "With no active runner, restart from this directory:\n\n```bash\n"
                f"tmux new-session -d -s latent-map-init-diagnostics -c {ROOT} "
                f"{sys.executable} -u scripts/run_logged.py\n```\n\n"
                "Completed artifacts are preserved. Incomplete training resumes from saved "
                "epoch boundaries with full optimizer/scheduler/scaler/stopping/RNG state. "
                "Exact numerical CUDA continuation is not guaranteed.\n\n"
                "Do not edit frozen code, config, dependencies, images or weights while running. "
                "On OOM, stop and report; do not reduce resolution/batch size. "
                "No new seeds, stopping-policy changes or test predictions are authorized. "
                "Original study and artifacts remain preserved.\n"
            )

        stages = [
            ["train", "--backbone", b, "--condition", c, "--model-seed", str(s)]
            for b in CONFIG["backbones"]
            for s in CONFIG["model_seeds"]
            for c in CONFIG["conditions"]
        ]
        stages += [["diagnose"], ["report"]]
        with (OUT / "training.log").open("a", buffering=1) as log:
            for args in stages:
                status({"status": "running", "stage": args, "runner_pid": os.getpid()})
                result = subprocess.run(
                    [sys.executable, "-u", str(ROOT / "scripts/experiment.py"), *args],
                    cwd=ROOT,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    check=False,
                )
                if result.returncode:
                    status(
                        {
                            "status": "failed",
                            "stage": args,
                            "returncode": result.returncode,
                        }
                    )
                    subprocess.run(
                        [sys.executable, str(ROOT / "scripts/experiment.py"), "report"],
                        cwd=ROOT,
                        stdout=log,
                        stderr=subprocess.STDOUT,
                        check=False,
                    )
                    raise SystemExit(result.returncode)
            status({"status": "complete"})


if __name__ == "__main__":
    main()
