"""Five-condition contrasts and descriptive validation screening."""

import csv
import json
import re
import statistics

from .engine import run_dir
from .protocol import ROOT, atomic_json, config, digest, freeze_json, output_root


def comparisons():
    return [("bounded_zero_init", "bounded"), ("unbounded_zero_init", "unbounded")] + [
        (c, "rgb") for c in config()["conditions"] if c != "rgb"]


def screening(metrics):
    checks = {}
    threshold = config()["screening"]["gain_db"]
    for kind in ("bounded", "unbounded"):
        condition = kind + "_zero_init"
        gains = {b: {k: metrics[condition][k] - metrics[b][k] for k in ("psnr", "ssim")}
                 for b in (kind, "rgb")}
        passes = {b: v["psnr"] >= threshold and v["ssim"] >= 0 for b, v in gains.items()}
        checks[condition] = {"deltas": gains, "initialization_benefit": passes[kind],
                             "candidate_improvement": all(passes.values())}
    return {"checks": checks, "threshold_db": threshold,
            "eligible": [c for c, v in checks.items() if v["candidate_improvement"]],
            "interpretation": "Single-seed validation engineering screen; not significance or repeatability."}


def write_csv(path, records):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def paired_differences(directory):
    images = {}
    for condition in config()["conditions"]:
        with (run_dir("nafnet", condition, 0) / "per_image_validation_normal.csv").open() as stream:
            values = list(csv.DictReader(stream))
        images[condition] = {r["filename"]: r for r in values}
        if len(values) != 80 or len(images[condition]) != 80:
            raise ValueError("Expected 80 unique validation filenames")
    names = sorted(images["rgb"])
    if not all(sorted(values) == names for values in images.values()):
        raise ValueError("Paired validation filenames differ")
    records, summaries = [], {}
    for condition, baseline in comparisons():
        differences = []
        for name in names:
            record = {"backbone": "nafnet", "seed": 0, "condition": condition,
                      "baseline": baseline, "filename": name}
            for metric in ("psnr", "ssim"):
                record[metric + "_difference"] = (float(images[condition][name][metric])
                                                  - float(images[baseline][name][metric]))
            differences.append(record)
        records.extend(differences)
        summary = {metric: {
            "mean": statistics.mean(r[metric + "_difference"] for r in differences),
            "median": statistics.median(r[metric + "_difference"] for r in differences),
            "wins": sum(r[metric + "_difference"] > 0 for r in differences),
            "ties": sum(r[metric + "_difference"] == 0 for r in differences), "count": 80}
            for metric in ("psnr", "ssim")}
        summary["worst5_psnr"] = sorted(differences, key=lambda r: r["psnr_difference"])[:5]
        summaries[f"{condition}_vs_{baseline}"] = summary
    write_csv(directory / "paired_validation_differences.csv", records)
    return summaries


def overflow_counts():
    counts = {c: 0 for c in config()["conditions"]}
    path = output_root() / "training.log"
    current = None
    for line in path.read_text().splitlines() if path.exists() else []:
        match = re.match(r"nafnet/([a-z_]+): seed", line)
        if match:
            current = match.group(1)
        if "[AMP] skipped batch" in line and current in counts:
            counts[current] += 1
    return counts


def convergence_tables(directory, histories):
    common = min(len(h) for h in histories.values())
    shared, curves = [], []
    for condition, history in histories.items():
        for row in history:
            curves.append({"condition": condition, "epoch": row["epoch"],
                           "train_loss": row["train_loss"], "val_loss": row["val_loss"],
                           "psnr": row["validation"]["psnr"],
                           "ssim": row["validation"]["ssim"], "lr": row["lr"]})
        for horizon in range(1, common + 1):
            best = max(history[:horizon], key=lambda r: (r["validation"]["psnr"], r["validation"]["ssim"]))
            shared.append({"condition": condition, "horizon_epoch": horizon,
                           "best_psnr": best["validation"]["psnr"],
                           "best_ssim": best["validation"]["ssim"],
                           "selected_epoch_so_far": best["epoch"]})
    write_csv(directory / "convergence.csv", curves)
    write_csv(directory / "common_horizon_scores.csv", shared)
    return common


def historical_context(metrics):
    parent = (ROOT / config()["parent_directory"] / "outputs/map_diagnostics_v1/reports").resolve()
    marker = json.loads((parent / "report_complete.json").read_text())
    identity = digest(parent / "results.json")
    if identity != marker["artifact_hashes"]["results.json"]:
        raise ValueError("Historical context results changed")
    differences = {}
    if metrics:
        for old in json.loads((parent / "results.json").read_text())["runs"]:
            if old["backbone"] == "nafnet" and old["condition"] in ("rgb", "bounded", "unbounded"):
                differences[old["condition"]] = {
                    k: metrics[old["condition"]][k] - old["val_" + k] for k in ("psnr", "ssim")}
    return {"results_sha256": identity, "control_differences": differences}


def report():
    directory = output_root() / "reports"
    directory.mkdir(parents=True, exist_ok=True)
    marker = directory / "report_complete.json"
    if marker.exists():
        for name, expected in json.loads(marker.read_text())["artifact_hashes"].items():
            if digest(directory / name) != expected:
                raise ValueError(f"Completed report changed: {name}")
        print(f"Completed report preserved: {directory / 'FINDINGS.md'}", flush=True)
        return
    rows, metrics, histories, interventions = [], {}, {}, {}
    skipped = overflow_counts()
    for condition in config()["conditions"]:
        run = run_dir("nafnet", condition, 0)
        row = {"backbone": "nafnet", "condition": condition, "seed": 0,
               "status": "pending", "epochs": None, "selected_epoch": None,
               "val_psnr": None, "val_ssim": None, "epoch_hours": None,
               "peak_allocated_gib": None, "parameters": None, "conv_gmacs": None,
               "inference_median_ms": None, "amp_skipped_updates": skipped[condition],
               "attempted_updates": None, "successful_updates_estimate": None}
        if (run / "history.json").exists():
            history = json.loads((run / "history.json").read_text())
            histories[condition] = history
            row.update(status="running", epochs=history[-1]["epoch"],
                       attempted_updates=len(history) * 180)
            row["successful_updates_estimate"] = row["attempted_updates"] - skipped[condition]
        if (run / "run_complete.json").exists():
            state = json.loads((run / "run_complete.json").read_text())
            row.update(status="trained", selected_epoch=state["best"]["epoch"],
                       val_psnr=state["best"]["psnr"], val_ssim=state["best"]["ssim"],
                       epoch_hours=state["training_seconds"] / 3600,
                       peak_allocated_gib=state["peak_allocated_bytes"] / 2**30)
        if (run / "diagnostics.json").exists():
            d = json.loads((run / "diagnostics.json").read_text())
            row.update(status="diagnosed", val_psnr=d["normal"]["psnr"],
                       val_ssim=d["normal"]["ssim"], parameters=d["resources"]["parameters"],
                       conv_gmacs=d["resources"]["convolution_macs"] / 1e9,
                       inference_median_ms=d["resources"]["latency"]["median_ms"])
            metrics[condition] = d["normal"]
            if condition.removesuffix("_zero_init") == "bounded":
                interventions[condition] = {name: {k: value[k] - d["normal"][k] for k in ("psnr", "ssim")}
                                           for name, value in d["interventions"].items() if name != "normal"}
        rows.append(row)
    finished = all(r["status"] == "diagnosed" for r in rows)
    decision = screening(metrics) if finished else None
    paired = paired_differences(directory) if finished else None
    common = convergence_tables(directory, histories) if finished else None
    result = {"complete": finished, "runs": rows, "screening": decision,
              "paired_summaries": paired, "common_horizon_epoch": common,
              "bounded_intervention_deltas": interventions,
              "historical_context": historical_context(metrics if finished else {}),
              "test_evaluated": False}
    atomic_json(directory / "results.json", result)
    write_csv(directory / "results.csv", rows)
    text = ["# NAFNet map-input initialization study", "",
            "Five fresh seed-0 validation runs; inherited 720/80/90 split. Original early stopping and 100-epoch cosine schedule retained.", "",
            "| Condition | Status | Epochs | Selected | PSNR | SSIM | AMP skips |",
            "|---|---|---:|---:|---:|---:|---:|"]
    for row in rows:
        values = [row[k] for k in ("condition", "status", "epochs", "selected_epoch", "val_psnr", "val_ssim", "amp_skipped_updates")]
        text.append("| " + " | ".join(f"{v:.5f}" if isinstance(v, float) else str(v) for v in values) + " |")
    if finished:
        text += ["", "Initialization benefit requires >=0.2 dB over matching random initialization with nonnegative SSIM. A candidate must also satisfy those gains over fresh RGB. These are descriptive screens.", ""]
        for condition, check in decision["checks"].items():
            text.append(f"- {condition}: initialization benefit={check['initialization_benefit']}; candidate improvement={check['candidate_improvement']}.")
            for baseline, delta in check["deltas"].items():
                text.append(f"  - vs {baseline}: PSNR {delta['psnr']:+.5f} dB; SSIM {delta['ssim']:+.6f}.")
        text += ["", "| Paired comparison | Mean PSNR delta | Median | PSNR wins / 80 |", "|---|---:|---:|---:|"]
        for name, value in paired.items():
            v = value["psnr"]
            text.append(f"| {name} | {v['mean']:+.5f} | {v['median']:+.5f} | {v['wins']} |")
        text += ["", f"All-condition common observed horizon: {common} epochs. See common_horizon_scores.csv for best-so-far scores and convergence.csv for complete curves.", "",
                 "Worst five regressions per contrast and historical-control differences are in results.json. Historical scores are context rather than substitutes for fresh controls.", ""]
        if decision["eligible"]:
            text.append("The screen identifies " + ", ".join(decision["eligible"]) + ". Repeatability remains untested; review before authorizing new seeds.")
        else:
            text.append("No zero-initialized variant passes the candidate screen. Improvement over random while below RGB is partial recovery rather than a demonstrated advantage from maps.")
    text += ["", "Limits: one seed; validation-selected checkpoints; unverified scene independence; prior exposure to historical test results. No held-out test predictions. Interventions do not establish physical semantics. Stopping can interact with initialization; a stopping-policy study would be separate.", "",
             "Epoch time excludes checkpoint writes/setup. VRAM is PyTorch allocation. Latency is GPU-only batch-1 float32 forward at 256x256. AMP skips are counted from durable logs, including interrupted attempts; successful-update estimates may be inaccurate after interruption. Exact state restoration does not guarantee bitwise CUDA continuation.", ""]
    (directory / "FINDINGS.md").write_text("\n".join(text))
    if finished:
        names = ("FINDINGS.md", "results.json", "results.csv", "paired_validation_differences.csv",
                 "convergence.csv", "common_horizon_scores.csv")
        freeze_json(marker, {"complete": True, "artifact_hashes": {name: digest(directory / name) for name in names}})
    print(directory / "FINDINGS.md", flush=True)
