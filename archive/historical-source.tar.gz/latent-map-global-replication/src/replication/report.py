"""Paired validation effects, seed SD and the prespecified descriptive gate."""

import json
import statistics

from conditioning.protocol import write_csv
from conditioning.report import paired_rows
from diagnostics.protocol import atomic_json, canonical, digest
from global_study.protocol import verify_diagnostic

from .protocol import config, diagnostic_directory, expected_identity, is_new, output_root, paired_history, run_directory, verify_run


def paired_effect(candidate, baseline):
    differences = paired_rows(candidate, baseline)
    return {"delta_psnr": statistics.mean(r["delta_psnr"] for r in differences),
            "delta_ssim": statistics.mean(r["delta_ssim"] for r in differences),
            "median_delta_psnr": statistics.median(r["delta_psnr"] for r in differences),
            "psnr_wins": sum(r["delta_psnr"] > 0 for r in differences), "n_images": len(differences)}, differences


def repeatability(contrasts, dimension):
    selected = [r for r in contrasts if r["dimension"] == dimension and r["baseline_dimension"] == 3 and r["seed"] in (1, 2)]
    if {r["seed"] for r in selected} != {1, 2}:
        return {"dimension": dimension, "status": "pending", "passed": None}
    passed = all(r["delta_psnr"] > 0 and r["delta_ssim"] >= 0 for r in selected)
    return {"dimension": dimension, "status": "confirmed_in_pilot" if passed else "not_confirmed_in_pilot", "passed": passed}


def summarize_seed_effects(contrasts):
    result = []
    for dimension, baseline in ((6, 3), (12, 3), (12, 6)):
        values = [r for r in contrasts if r["dimension"] == dimension and r["baseline_dimension"] == baseline]
        if values:
            row = {"dimension": dimension, "baseline_dimension": baseline, "seeds": [r["seed"] for r in values], "n_seeds": len(values)}
            for key in ("delta_psnr", "delta_ssim"):
                row[key + "_mean"] = statistics.mean(r[key] for r in values)
                row[key + "_sample_sd"] = statistics.stdev(r[key] for r in values) if len(values) > 1 else None
            result.append(row)
    return result


def report(frozen):
    out = output_root()
    target = out / "reports"
    target.mkdir(exist_ok=True)
    available, cells, missing = {}, [], []
    for seed in config()["seeds"]:
        for dimension in config()["dimensions"]:
            directory = run_directory(dimension, seed)
            if not (directory / "complete.json").exists():
                missing.append({"stage": "training", "dimension": dimension, "seed": seed})
                continue
            saved, rows, history = verify_run(directory, expected_identity(dimension, seed, frozen))
            available[(dimension, seed)] = (saved, rows, history)
            cells.append({"dimension": dimension, "seed": seed, "reused": not is_new(dimension, seed), **saved["best"],
                          "optimizer_steps": saved["optimizer_steps"], "amp_skipped_updates": saved["amp_skipped_updates"],
                          "training_epoch_seconds": saved["training_epoch_seconds"], "peak_allocated_bytes": saved["peak_allocated_bytes"],
                          "conv_linear_macs": saved["conv_linear_macs"], **saved["parameters"], "checkpoint_sha256": saved["best_sha256"]})
    contrasts, per_image = [], []
    for seed in config()["seeds"]:
        for dimension, baseline in ((6, 3), (12, 3), (12, 6)):
            if (dimension, seed) not in available or (baseline, seed) not in available:
                continue
            paired_history(available[(dimension, seed)][2], available[(baseline, seed)][2])
            effect, details = paired_effect(available[(dimension, seed)][1], available[(baseline, seed)][1])
            contrasts.append({"dimension": dimension, "baseline_dimension": baseline, "seed": seed, **effect})
            per_image.extend({"dimension": dimension, "baseline_dimension": baseline, "seed": seed, **r} for r in details)
    summaries = []
    for dimension in config()["dimensions"]:
        selected = [r for r in cells if r["dimension"] == dimension]
        row = {"dimension": dimension, "seeds": [r["seed"] for r in selected], "n_seeds": len(selected)}
        for key in ("psnr", "ssim"):
            row[key + "_mean"] = statistics.mean(r[key] for r in selected)
            row[key + "_sample_sd"] = statistics.stdev(r[key] for r in selected) if len(selected) > 1 else None
        summaries.append(row)
    diagnostics = []
    for seed in config()["seeds"]:
        for dimension in config()["dimensions"]:
            directory = diagnostic_directory(dimension, seed)
            if not (directory / "complete.json").exists():
                missing.append({"stage": "diagnostic", "dimension": dimension, "seed": seed})
                continue
            value = json.loads((directory / "results.json").read_text())
            verify_diagnostic(directory, value["identity"])
            if (dimension, seed) not in available or value["identity"]["checkpoint_sha256"] != available[(dimension, seed)][0]["best_sha256"]:
                raise ValueError("Diagnostic and selected checkpoint differ")
            expected_frozen = canonical(frozen) if is_new(dimension, seed) else frozen["parent_frozen_identity"]
            if value["identity"]["frozen_identity"] != expected_frozen:
                raise ValueError("Diagnostic frozen identity differs")
            diagnostics.append({"dimension": dimension, "seed": seed, "reused": not is_new(dimension, seed),
                                "training_sd": value["training_statistics"]["population_sd"],
                                "training_effective_rank": value["training_statistics"]["effective_rank"],
                                "normal_psnr": value["normal_validation"]["psnr"],
                                "training_mean_psnr": value["training_mean_validation"]["psnr"],
                                "delta_psnr_mean_minus_normal": value["delta_mean_minus_normal"]["psnr"],
                                "delta_ssim_mean_minus_normal": value["delta_mean_minus_normal"]["ssim"]})
    aggregate = summarize_seed_effects(contrasts)
    gates = [repeatability(contrasts, dimension) for dimension in (6, 12)]
    result = {"frozen_identity": canonical(frozen), "cells": cells, "seed_summary": summaries,
              "paired_contrasts": contrasts, "paired_summary": aggregate, "diagnostics": diagnostics,
              "repeatability": gates, "missing": missing,
              "limits": "Validation-selected 30-epoch pilot; no significance test, test inference or automatic architecture decision"}
    for name, rows in (("validation_cells.csv", cells), ("seed_summary.csv", summaries), ("paired_seed_contrasts.csv", contrasts),
                       ("paired_summary.csv", aggregate), ("paired_per_image.csv", per_image), ("global_diagnostics.csv", diagnostics)):
        if rows:
            write_csv(target / name, rows)
    atomic_json(target / "results.json", result)
    lines = ["# Global dimension replication — validation only", "", f"Validation cells {len(cells)}/9; diagnostics {len(diagnostics)}/9; missing entries {len(missing)}.", "",
             "Five reference cells are reused in place; exactly four new training runs were authorized.", "",
             "| Seed | d | Reused | Selected epoch | PSNR | SSIM |", "|---:|---:|---|---:|---:|---:|"]
    lines += [f"| {r['seed']} | {r['dimension']} | {r['reused']} | {r['epoch']} | {r['psnr']:.5f} | {r['ssim']:.6f} |" for r in cells]
    lines += ["", "| Seed | d | Baseline d | Delta PSNR | Delta SSIM | PSNR wins / 80 |", "|---:|---:|---:|---:|---:|---:|"]
    lines += [f"| {r['seed']} | {r['dimension']} | {r['baseline_dimension']} | {r['delta_psnr']:+.5f} | {r['delta_ssim']:+.6f} | {r['psnr_wins']} |" for r in contrasts]
    lines += ["", "## Across-seed effects", "", "Mean and sample SD use paired training-seed effects, not pooled image replicates. Available seed lists remain explicit.", "",
              "| d | Baseline d | Seeds | Delta PSNR mean | Sample SD |", "|---:|---:|---|---:|---:|"]
    lines += [f"| {r['dimension']} | {r['baseline_dimension']} | {r['seeds']} | {r['delta_psnr_mean']:+.5f} | {r['delta_psnr_sample_sd']} |" for r in aggregate]
    lines += ["", "## Prespecified descriptive repeatability", "",
              "Both new seeds must improve validation PSNR and have nonnegative validation SSIM gain versus same-seed d=3. Missing evidence is pending. This is not a statistical significance test.", ""]
    lines += [f"- d={r['dimension']}: {r['status']}" for r in gates]
    lines += ["", "## Global-vector diagnostics", "", "| Seed | d | Effective rank | Normal val PSNR | Training-mean G val PSNR | Mean minus normal |",
              "|---:|---:|---:|---:|---:|---:|"]
    lines += [f"| {r['seed']} | {r['dimension']} | {r['training_effective_rank']:.4f} | {r['normal_psnr']:.5f} | {r['training_mean_psnr']:.5f} | {r['delta_psnr_mean_minus_normal']:+.5f} |" for r in diagnostics]
    lines += ["", "Each mean uses only the 720 training images in eval mode with augmentation disabled. Normal validation must reproduce the selected checkpoint before interpretation. Full vector statistics, saturation and per-image intervention results are retained per diagnostic.", "",
              "## Limits and next decision", "", "All runs use the inherited 30-epoch pilot, first 30 epochs of the 100-epoch schedule, no early stopping and validation PSNR/SSIM selection. Parameter/MAC differences are recorded; capacity is not matched. CUDA replay need not be bitwise identical.", "",
              "Inherited scene independence remains unresolved and historical test exposure remains. This study performs no new test inference, test-based choice, automatic 100-epoch training or spatial removal. Reports support later evidence review; they do not automatically promote an architecture."]
    (target / "FINDINGS.md").write_text("\n".join(lines) + "\n")
    if not missing:
        complete = {"frozen_identity": canonical(frozen), "validation_cells": 9, "new_runs": 4, "reused_cells": 5,
                    "diagnostics": 9, "report_hashes": {p.name: digest(p) for p in target.iterdir() if p.is_file()}}
        marker = out / "complete.json"
        if marker.exists() and json.loads(marker.read_text()) != complete:
            raise ValueError("Completed report identity/content changed")
        atomic_json(marker, complete)
    print(f"Report: cells {len(cells)}/9, diagnostics {len(diagnostics)}/9, missing {len(missing)}", flush=True)
