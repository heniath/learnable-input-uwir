"""Training-only global means and held-fixed validation interventions."""

import json

import numpy as np
import torch

from conditioning.models import ConditionedUNet
from conditioning.protocol import write_csv
from diagnostics.diagnose import metric_rows
from diagnostics.protocol import atomic_json, base_dataset, canonical, digest, loader, seed_original

from .models import GlobalLatentUNet
from .protocol import config, h1_directory, output_root, verify_diagnostic, verify_run


def vector_statistics(values):
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 2 or not np.isfinite(values).all() or len(values) < 2:
        raise ValueError("Expected finite image x coordinate matrix")
    sd = values.std(axis=0)
    centered = values - values.mean(axis=0)
    singular = np.linalg.svd(centered, compute_uv=False)
    eigenvalues = singular**2 / (len(values) - 1)
    tolerance = np.finfo(np.float64).eps * max(values.shape) * max(1.0, float(np.linalg.norm(values)))
    energy = np.where(singular > tolerance, singular**2, 0.0)
    weights = energy / energy.sum() if energy.sum() > 0 else np.zeros_like(energy)
    positive = weights[weights > 0]
    thresholds = config()["diagnostic_std_thresholds"]
    return {"n_images": len(values), "dimension": values.shape[1], "mean": values.mean(axis=0).tolist(),
            "population_sd": sd.tolist(), "minimum": values.min(axis=0).tolist(), "maximum": values.max(axis=0).tolist(),
            "p01": np.quantile(values, 0.01, axis=0).tolist(), "p99": np.quantile(values, 0.99, axis=0).tolist(),
            "fraction_below_0_01": (values < 0.01).mean(axis=0).tolist(),
            "fraction_above_0_99": (values > 0.99).mean(axis=0).tolist(),
            "numerically_constant_coordinates": (sd <= thresholds["numerically_constant"]).tolist(),
            "near_constant_coordinates_descriptive": (sd <= thresholds["near_constant_descriptive"]).tolist(),
            "centered_singular_values": singular.tolist(), "covariance_eigenvalues": eigenvalues.tolist(),
            "numerical_rank": int(np.linalg.matrix_rank(centered, tol=tolerance)),
            "effective_rank": float(np.exp(-np.sum(positive * np.log(positive)))) if positive.size else 0.0}


def training_batches(manifest):
    dataset = base_dataset(augment=False)
    expected = [manifest["pairs"][i]["filename"] for i in manifest["indices"]["train"]]
    from diagnostics.protocol import config as training_config
    recipe = training_config()
    batches = torch.utils.data.DataLoader(torch.utils.data.Subset(dataset, manifest["indices"]["train"]),
                                         batch_size=recipe["batch_size"], shuffle=False, num_workers=recipe["workers"],
                                         pin_memory=True, drop_last=False)
    return batches, expected


def reference(phase, condition, seed, frozen):
    if phase == "H1":
        if condition not in ("A2_global", "A3_both") or seed not in (0, 1, 2):
            raise ValueError("Diagnostics target H1 global-only and joint maps")
        directory = h1_directory(seed, condition)
        model = ConditionedUNet(condition, seed)
        scope = "h1_seed0_config" if seed == 0 else "h1_seeds12_config"
        expected_identity = {"condition": condition, "seed": seed, "frozen_identity": frozen["parent_identities"][scope]}
    elif phase == "dimension":
        dimension = int(condition.removeprefix("d_"))
        if dimension not in config()["dimensions"] or seed not in config()["dimension_seeds"]:
            raise ValueError("Dimension/seed outside frozen screen")
        directory = h1_directory(seed, "A2_global") if dimension == 3 else output_root() / "runs" / f"seed_{seed}" / condition
        model = GlobalLatentUNet(dimension, seed)
        if dimension == 3:
            scope = "h1_seed0_config" if seed == 0 else "h1_seeds12_config"
            expected_identity = {"condition": "A2_global", "seed": seed, "frozen_identity": frozen["parent_identities"][scope]}
        else:
            expected_identity = {"condition": condition, "seed": seed, "frozen_identity": canonical(frozen)}
    else:
        raise ValueError("Unknown diagnostic phase")
    saved, rows = verify_run(directory, expected_identity)
    state = torch.load(directory / "best.pt", map_location="cpu", weights_only=False)
    if state["identity"] != saved["identity"] or state["best"] != saved["best"]:
        raise ValueError("Diagnostic checkpoint identity/selection mismatch")
    model.load_state_dict(state["model"], strict=True)
    return directory, saved, rows, model.cuda().eval()


@torch.inference_mode()
def diagnose(phase, condition, seed, frozen):
    seed_original(seed)
    source, saved, expected_rows, model = reference(phase, condition, seed, frozen)
    identity = {"phase": phase, "condition": condition, "seed": seed,
                "frozen_identity": canonical(frozen), "checkpoint_sha256": saved["best_sha256"]}
    target = output_root() / "diagnostics" / phase / f"seed_{seed}" / condition
    if verify_diagnostic(target, identity):
        print(f"Preserving completed diagnostic: {phase}/{condition}/seed_{seed}", flush=True)
        return
    if target.exists():
        raise ValueError("Partial diagnostic exists; preserve it and inspect before rerunning")
    target.mkdir(parents=True)
    manifest = json.loads((output_root() / "manifest.json").read_text())
    batches, expected_names = training_batches(manifest)
    train_values, names = [], []
    for x, _, batch_names, _ in batches:
        values = model.base.background_extractor(x.cuda()).flatten(1).cpu().numpy()
        train_values.extend(values.astype(np.float64))
        names.extend(batch_names)
    train_values = np.asarray(train_values)
    if names != expected_names or len(names) != 720 or not np.isfinite(train_values).all():
        raise ValueError("Training-only G coverage/values invalid")
    mean = train_values.mean(axis=0)
    mean_tensor = torch.tensor(mean, dtype=torch.float32, device="cuda").reshape(1, -1, 1, 1)
    vector_rows = [{"filename": name, **{f"g_{i}": float(v) for i, v in enumerate(values)}}
                   for name, values in zip(names, train_values)]
    write_csv(target / "g_training.csv", vector_rows)
    normal, constant, val_values, val_names = [], [], [], []
    for x, y, batch_names, _ in loader("validation", seed=seed, filenames=True):
        x = x.cuda()
        prediction, maps = model(x, return_maps=True)
        spatial, values = maps
        normal.extend(metric_rows(prediction, y, batch_names))
        replacement = mean_tensor.expand(x.shape[0], -1, -1, -1)
        constant.extend(metric_rows(model(x, maps_override=(spatial, replacement)), y, batch_names))
        val_values.extend(values.flatten(1).cpu().numpy().astype(np.float64))
        val_names.extend(batch_names)
    expected = [manifest["pairs"][i]["filename"] for i in manifest["indices"]["validation"]]
    if val_names != expected or [r["filename"] for r in expected_rows] != expected:
        raise ValueError("Validation intervention filenames/order changed")
    original = {r["filename"]: r for r in expected_rows}
    drift = {key: max(abs(row[key] - float(original[row["filename"]][key])) for row in normal)
             for key in ("psnr", "ssim")}
    if drift["psnr"] > 0.001 or drift["ssim"] > 0.00001:
        raise ValueError(f"Normal validation reproduction failed: {drift}")
    differences = [{"filename": a["filename"], "delta_psnr_mean_minus_normal": b["psnr"] - a["psnr"],
                    "delta_ssim_mean_minus_normal": b["ssim"] - a["ssim"]} for a, b in zip(normal, constant)]
    write_csv(target / "g_validation.csv", [{"filename": name, **{f"g_{i}": float(v) for i, v in enumerate(values)}}
                                            for name, values in zip(val_names, val_values)])
    write_csv(target / "normal_validation.csv", normal)
    write_csv(target / "training_mean_validation.csv", constant)
    write_csv(target / "paired_intervention.csv", differences)
    normal_means = {key: float(np.mean([r[key] for r in normal])) for key in ("psnr", "ssim")}
    constant_means = {key: float(np.mean([r[key] for r in constant])) for key in ("psnr", "ssim")}
    result = {"identity": identity, "source": str(source), "selected_epoch": saved["best"]["epoch"],
              "training_mean_g": mean.tolist(), "training_statistics": vector_statistics(train_values),
              "validation_statistics": vector_statistics(val_values), "normal_validation": normal_means,
              "training_mean_validation": constant_means,
              "delta_mean_minus_normal": {key: constant_means[key] - normal_means[key] for key in normal_means},
              "normal_max_per_image_drift": drift,
              "mean_definition": "All 720 training images; eval mode; augmentation disabled; inherited resize/center crop; no validation/test contribution",
              "interpretation": "Descriptive variation and intervention sensitivity; no physical semantics or unconditional collapse claim"}
    atomic_json(target / "results.json", result)
    if digest(source / "best.pt") != saved["best_sha256"]:
        raise ValueError("Diagnostic source checkpoint changed")
    atomic_json(target / "complete.json", {"identity": identity,
                                           "artifact_hashes": {p.name: digest(p) for p in target.iterdir() if p.is_file()}})
    print(f"{phase}/{condition}/seed_{seed}: G train SD={result['training_statistics']['population_sd']}; "
          f"mean intervention delta PSNR={result['delta_mean_minus_normal']['psnr']:+.5f}", flush=True)
