#!/usr/bin/env python3
"""Finite sequential queue: existing diagnostics, H1 seeds 1/2, then dimension screen."""

import fcntl
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import bootstrap

ROOT = bootstrap.ROOT
TRAINING = bootstrap.TRAINING
CONFIG = json.loads((ROOT / "configs/study.json").read_text())
OUT = ROOT / "outputs" / CONFIG["experiment_id"]


def utc():
    return datetime.now(timezone.utc).isoformat()


def status(state, **details):
    target = OUT / "job_status.json"
    temporary = target.with_suffix(".json.tmp")
    temporary.write_text(json.dumps({"status": state, "utc": utc(), **details}, indent=2) + "\n")
    temporary.replace(target)


def command(label, script, *args):
    status("running", stage=label, command=list(args))
    print(f"{utc()} Starting {label}", flush=True)
    with (OUT / "logs" / f"{label}.log").open("a") as log:
        argv = [sys.executable, "-B", str(script), *args]
        log.write(f"\n{utc()} {json.dumps(argv)}\n")
        log.flush()
        subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)


def own(label, *args):
    command(label, ROOT / "scripts/run.py", *args)


def h1(label, *args):
    command(label, TRAINING / "scripts/run.py", "--config", str(TRAINING / "configs" / CONFIG["h1_seeds12_config"]), *args)


def refresh():
    own("report", "report")


def wait_for_gpu():
    """Wait without touching existing GPU processes; sharing requires user policy."""
    while True:
        processes = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader"], text=True)
        active = [line for line in processes.splitlines() if line.strip() and
                  line.split(",")[1].strip() != "/usr/libexec/gnome-remote-desktop-daemon"]
        policy_path = OUT / "gpu_policy.json"
        policy = json.loads(policy_path.read_text()) if policy_path.exists() else {}
        if not active or policy.get("allow_shared_gpu") is True:
            with (OUT / "logs/preflight.log").open("a") as log:
                log.write(f"{utc()} GPU queue released; active={active}; policy={json.dumps(policy)}\n")
            return
        status("waiting_for_gpu", stage="waiting_for_gpu", active_processes=active,
               polling_seconds=30, policy="Wait for other GPU compute processes to exit")
        print(f"{utc()} Waiting for GPU: {active}", flush=True)
        time.sleep(30)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "logs").mkdir(exist_ok=True)
    with (ROOT / ".runner.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            with (OUT / "logs/preflight.log").open("a") as log:
                subprocess.run(["nvidia-smi"], stdout=log, stderr=subprocess.STDOUT, check=True)
                subprocess.run([sys.executable, "-B", "-c", "import torch; print(torch.__version__, torch.version.cuda, flush=True); assert torch.cuda.is_available(); print(torch.cuda.get_device_name(0), flush=True)"],
                               stdout=log, stderr=subprocess.STDOUT, check=True)
            own("prepare", "prepare")
            wait_for_gpu()
            h1("h1_smoke", "smoke")
            own("dimension_smoke", "smoke")
            for condition in ("A2_global", "A3_both"):
                own(f"diagnostic_H1_{condition}_seed0", "diagnose", "--phase", "H1", "--condition", condition, "--seed", "0")
            refresh()
            # Prioritize the requested global/joint confirmation with paired RGB controls.
            for seed in (1, 2):
                for condition in ("A0_rgb", "A2_global", "A3_both"):
                    h1(f"H1_{condition}_seed{seed}", "train", "--condition", condition, "--seed", str(seed))
                    h1("h1_report", "report")
                    if condition != "A0_rgb":
                        own(f"diagnostic_H1_{condition}_seed{seed}", "diagnose", "--phase", "H1", "--condition", condition, "--seed", str(seed))
                    refresh()
            for seed in (1, 2):
                h1(f"H1_A1_spatial_seed{seed}", "train", "--condition", "A1_spatial", "--seed", str(seed))
                h1("h1_report", "report")
                refresh()
            for seed in CONFIG["dimension_seeds"]:
                for dimension in CONFIG["dimensions"]:
                    own(f"dimension_d{dimension}_seed{seed}", "train-dimension", "--dimension", str(dimension), "--seed", str(seed))
                    if dimension != 3:
                        own(f"diagnostic_d{dimension}_seed{seed}", "diagnose", "--phase", "dimension", "--condition", f"d_{dimension}", "--seed", str(seed))
                    refresh()
            if not (OUT / "complete.json").exists():
                raise RuntimeError("Queue finished without a complete verified report")
            status("complete", report=str(OUT / "reports/FINDINGS.md"), spatial_decision="Deferred for evidence review")
        except BaseException as exc:
            status("failed", error=repr(exc))
            raise


if __name__ == "__main__":
    main()
