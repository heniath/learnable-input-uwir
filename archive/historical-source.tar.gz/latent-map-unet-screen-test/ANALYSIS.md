# Screening decision — 2026-10-21

Completed four seed-0 warm-start trials, six full-data epochs each. No candidate passed the frozen validation screen, so no seed-1 confirmation or module combinations ran.

All identity-initialized variants reproduced the original validation scores exactly before training. Across 24 epochs, all 4320 optimizer updates succeeded without AMP skips. Checkpoint selection included epoch 0; all four validation-best checkpoints remained at that original model.

## Validation and test overview

The four adaptation rows below are the fixed epoch-6 endpoints, not newly selected models. External references retain their existing validation-selected checkpoints.

| Model | Checkpoint | Val PSNR | Test PSNR | Test SSIM | Δtest PSNR vs epoch-6 control |
|---|---|---:|---:|---:|---:|
| original_rgb | original best | 20.9287 | 20.7229 | 0.88639 | — |
| original_bounded | original best | 22.5000 | 22.4815 | 0.90526 | — |
| control | epoch 6 | 22.2340 | 22.4844 | 0.90274 | +0.0000 |
| residual_refine | epoch 6 | 22.2495 | 22.4920 | 0.90211 | +0.0077 |
| multiscale | epoch 6 | 22.2282 | 22.4882 | 0.90275 | +0.0038 |
| skip_gate | epoch 6 | 22.2278 | 22.4892 | 0.90276 | +0.0049 |
| nafnet_rgb | original best | 24.1176 | 23.2638 | 0.90034 | — |

## Interpretation and decision

- Residual refinement gives the largest endpoint PSNR difference, but it is only +0.0154 dB on validation and +0.0077 dB on test versus continuation control; test SSIM falls. This does not satisfy the predefined improvement rule.
- Multi-scale injection and skip gating track the control closely. Their endpoint test differences are below 0.005 dB, while validation endpoints are slightly lower than control.
- All endpoint validation scores fall below the 22.5000 dB starting checkpoint. Test PSNR changes little, and all endpoint test SSIM scores fall below the original bounded model. Keep the existing bounded U-Net checkpoint.
- The shared continuation regression makes fine-tuning dynamics a useful next hypothesis. The LR restart, common backbone/module LR, and perceptual/pixel objective balance are candidates for separate experiments; these runs do not identify the cause.
- These short warm-start trials do not rule out the architecture changes under longer or from-scratch training. The residual trial tests refinement after the sigmoid, not replacing it with an RGB-residual head.

## Scope and verification

Test evaluation was explicitly requested after the training protocol was frozen and was implemented separately. All checkpoint choices were fixed before test inference. Twelve checkpoints / 1080 test predictions reproduce their validation anchors with zero drift. Per-image metric means and output hashes were independently verified. No test result changed promotion or checkpoint selection.

One seed; inherited historical UIEB test90; resize/center-crop 256; original metrics. No claim of native-resolution SOTA, significance, generalization, physical-map semantics, or converged architecture ranking.

Training: ../latent-map-unet-screen/outputs/unet_arch_screen_v1/FINDINGS.md
Test: outputs/unet_arch_screen_test_v1/FINDINGS.md
