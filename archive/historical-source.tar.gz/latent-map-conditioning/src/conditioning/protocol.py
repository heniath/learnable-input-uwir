"""Resolve the parent recipe read-only and freeze each new study independently."""

import csv
import json
import re
import shutil
import subprocess
from dataclasses import asdict
from pathlib import Path

import torch

from diagnostics.protocol import atomic_json, canonical, digest, environment, loader

from .models import SPECS

ROOT = Path(__file__).resolve().parents[2]
PARENT = ROOT.parent / "latent-map-diagnostics"
ARCHIVE = PARENT / "outputs/map_diagnostics_v1"


def read_config(path):
    path = Path(path).resolve()
    requested = json.loads(path.read_text())
    if requested["phase"] not in ("H1", "H2"):
        raise ValueError("Only H1/H2 are enabled")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", requested["experiment_id"]):
        raise ValueError("experiment_id must be a single safe directory name")
    conditions, seeds = requested["conditions"], requested["seeds"]
    if not conditions or len(set(conditions)) != len(conditions) or set(conditions) - SPECS.keys():
        raise ValueError("Unknown, duplicate or empty conditions")
    if not seeds or len(set(seeds)) != len(seeds) or any(type(s) is not int or s < 0 for s in seeds):
        raise ValueError("Seeds must be distinct nonnegative integers")
    parent = json.loads((PARENT / "configs/protocol.json").read_text())
    budget = requested["budget"]
    if budget["initialization"] != "from_scratch":
        raise ValueError("This study only supports paired from-scratch training")
    if type(budget["early_stopping"]) is not bool:
        raise ValueError("early_stopping must be boolean")
    if not 1 <= budget["epochs"] <= budget["scheduler_epochs"] == parent["epochs"]:
        raise ValueError("Use a prefix of the original 100-epoch schedule")
    resolved = {**requested, "training": parent, "model_specs": {name: asdict(SPECS[name]) for name in conditions},
                "validation_only": True, "selection": "Maximum validation (PSNR, SSIM) tuple; earliest exact tie",
                "test_policy": "No test loader, prediction or selection; independent evaluation remains a separate frozen protocol"}
    return path, json.loads(json.dumps(resolved))


def output_root(config):
    return ROOT / "outputs" / config["experiment_id"]


def write_csv(path, rows):
    if not rows:
        raise ValueError("Refusing to write an empty CSV")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def local_sources(config_path):
    paths = [ROOT / "README.md", config_path]
    for folder in ("src", "scripts", "tests"):
        paths.extend((ROOT / folder).rglob("*.py"))
    return {str(p.relative_to(ROOT)): digest(p) for p in sorted(set(paths))}


def validate_manifest(manifest):
    indices = manifest["indices"]
    if [len(indices[s]) for s in ("train", "validation", "test")] != [720, 80, 90]:
        raise ValueError("Expected the original 720/80/90 split")
    flat = [i for split in ("train", "validation", "test") for i in indices[split]]
    if len(set(flat)) != 890 or sorted(flat) != list(range(890)):
        raise ValueError("Duplicate, overlapping or invalid dataset indices")


def provenance(config_path, config, *, check_data=True):
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; do not silently switch the training protocol to CPU")
    parent_frozen = json.loads((ARCHIVE / "frozen_protocol.json").read_text())
    if parent_frozen["config"] != config["training"]:
        raise ValueError("Parent recipe differs from its saved frozen protocol")
    for relative, expected in parent_frozen["source_hashes"].items():
        if digest(PARENT / relative) != expected:
            raise ValueError(f"Parent source changed: {relative}")
    manifest = json.loads((ARCHIVE / "manifest.json").read_text())
    validate_manifest(manifest)
    if canonical(manifest) != parent_frozen["manifest_sha256"]:
        raise ValueError("Parent split manifest changed")
    weights = PARENT / "artifacts/weights/vgg16-397923af.pth"
    if digest(weights) != parent_frozen["weights"]["sha256"]:
        raise ValueError("Parent VGG weights changed")
    if check_data:
        from diagnostics.protocol import base_dataset

        ds = base_dataset()
        if [Path(p).name for p in ds.input_files] != [p["filename"] for p in manifest["pairs"]]:
            raise ValueError("Dataset order differs from the frozen manifest")
        for pair in manifest["pairs"]:
            for role in ("input", "reference"):
                if digest(Path(config["training"]["data_root"]) / pair[role]["path"]) != pair[role]["sha256"]:
                    raise ValueError(f"Dataset changed: {pair['filename']} {role}")
    upstream = PARENT / "third_party/upstream"
    commit = subprocess.check_output(["git", "-C", str(upstream), "rev-parse", "HEAD"], text=True).strip()
    dirty = subprocess.check_output(["git", "-C", str(upstream), "status", "--porcelain"], text=True).strip()
    if commit != config["training"]["upstream_commit"] or dirty:
        raise ValueError("Pinned upstream checkout changed")
    return {"config": config, "source_hashes": local_sources(config_path),
            "parent_frozen_sha256": digest(ARCHIVE / "frozen_protocol.json"),
            "manifest_sha256": canonical(manifest), "weights_sha256": digest(weights),
            "environment": environment(), "upstream_commit": commit, "upstream_dirty": False,
            "git": "New project has no Git repository; source hashes and snapshot record the working source"}, manifest


def prepare(config_path, config):
    frozen, manifest = provenance(config_path, config)
    out = output_root(config)
    target = out / "frozen.json"
    if target.exists():
        if json.loads(target.read_text()) != frozen:
            raise ValueError("Study is already frozen with different inputs; use a new experiment_id")
        return frozen
    out.mkdir(parents=True, exist_ok=True)
    for relative in frozen["source_hashes"]:
        dest = out / "source_snapshot" / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / relative, dest)
    atomic_json(out / "manifest.json", manifest)
    atomic_json(out / "config.json", config)
    atomic_json(target, frozen)
    return frozen


def verify(config_path, config, *, check_data=True):
    expected = json.loads((output_root(config) / "frozen.json").read_text())
    actual, manifest = provenance(config_path, config, check_data=check_data)
    if actual != expected:
        raise ValueError("Frozen source/config/environment changed; use a new experiment_id")
    if json.loads((output_root(config) / "manifest.json").read_text()) != manifest:
        raise ValueError("Study manifest copy changed")
    return expected


def validation_loader(seed=0, limit=None):
    return loader("validation", seed=seed, limit=limit, filenames=True)
