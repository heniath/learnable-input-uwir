# NAFNet latent-map component ablation

Validation status: complete. See [interpretation](RESEARCH.md) and the
[validation results](outputs/map_components_v1/FINDINGS.md).
UIEB test90 status: complete. See [test interpretation](TEST_RESEARCH.md) and
[test results](outputs/map_components_uieb_test_v1/FINDINGS.md).

Saved-checkpoint interventions, with no training or new checkpoint selection.
The original run evaluated validation80. A separate UIEB test90 run was added
at the user's explicit request, retaining the pre-existing checkpoints and
intervention definitions. The primary checkpoint is `unbounded_zero_init`; `bounded_zero_init`
checks whether the findings depend on map bounds. Both come from the completed
`../latent-map-init-diagnostics` study, seed 0. The original RGB checkpoint is
re-evaluated as context. Existing studies are read only.

Conditions: intact maps, spatial map zeroed, global map zeroed, both zeroed,
spatial map replaced with its per-image channel means, spatial-only donor swap,
and global-only donor swap. Donors use sorted filenames within the evaluated
split rotated by one position, matching the parent diagnostic donor rule.

The exact parent 80-image validation or historical sorted 90-image test split,
256-pixel resize/center-crop,
batch size 4, float32 inference, clipping and PSNR/SSIM implementations are
retained. Parent source/config/environment/data identities and checkpoint hashes
are checked before inference. Intact per-image metrics must reproduce the saved
diagnostics within 0.001 dB PSNR and 0.00001 SSIM. For test evaluation, validation
reproduction is checked separately before each checkpoint's test inference.
The split option cannot select training data. Split membership, disjointness,
filenames, order and counts are checked. No tuning uses the test results.

Run from this directory in the existing environment:

```bash
/home/heniath/miniforge3/envs/uieb-latent-repro/bin/python scripts/ablate.py
/home/heniath/miniforge3/envs/uieb-latent-repro/bin/python scripts/ablate.py --split test
```

Validation results go to `outputs/map_components_v1/`; test results go to
`outputs/map_components_uieb_test_v1/`. Each includes the frozen protocol,
script snapshot, per-image scores, paired summaries, execution metadata and
`FINDINGS.md`. A completed output is never overwritten. Failure records and
partial results are preserved; use a distinct `--run-id` after any failure.

These interventions measure dependence of jointly trained models on map inputs.
Zeroing/swapping can be out of distribution. They do not estimate separately
trained spatial-only/global-only performance, establish physical semantics, or
prove overlap with SCA. One seed and validation-selected checkpoints limit
generalization. A dedicated training experiment is needed to test SCA redundancy.
Historical test exposure already existed in the inherited study. Test results
are therefore not claimed to come from a previously unseen benchmark.
