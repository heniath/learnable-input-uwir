"""Scientific invariants independent of full GPU training."""
# Path bootstrap precedes imports so tests run without an editable install.
# ruff: noqa: E402

import sys
from pathlib import Path

import numpy as np
import pytest
import torch
from PIL import Image
from torchvision.transforms import functional as TF

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "third_party/upstream/src")]

from uwir.cli.train import EarlyStopping
from uwir.data.datasets import _paired_augment, _paired_resize_crop
from uwir.metrics import compute_psnr, compute_ssim
from uwir.training.schedulers import CosineAnnealingRestartLR

from reproduction.audit import audit_rows
from reproduction.protocol import freeze_json, split_indices
from reproduction.validation import compare_state


def test_original_sorted_split_and_no_global_rng_consumption():
    state = torch.get_rng_state().clone()
    splits = split_indices()
    assert torch.equal(state, torch.get_rng_state())
    expected = torch.randperm(800, generator=torch.Generator().manual_seed(0)).tolist()
    assert splits["validation"] == sorted(expected[:80])
    assert splits["train"] == sorted(expected[80:])
    assert splits["test"] == list(range(800, 890))
    assert set(splits["train"]).isdisjoint(splits["validation"])


def test_paired_geometry_and_center_crop():
    image = Image.fromarray(
        np.random.default_rng(5).integers(0, 256, (300, 480, 3), dtype=np.uint8)
    )
    resized = TF.resize(image, 256, antialias=True)
    expected = TF.crop(resized, 0, (resized.width - 256) // 2, 256, 256)
    a, b = _paired_resize_crop(image, image.copy(), 256, False)
    np.testing.assert_array_equal(a, expected)
    np.testing.assert_array_equal(a, b)
    a, b = _paired_resize_crop(image, image.copy(), 256, True)
    a, b = _paired_augment(a, b)
    np.testing.assert_array_equal(a, b)
    assert a.size == (256, 256)


def test_historical_audit_discloses_overlap_without_reassigning():
    rows = []
    for i, split in enumerate(["train", "test"]):
        rows.append(
            (
                {
                    "filename": str(i),
                    "split": split,
                    "input": {"decoded_sha256": "same", "dhash": "0"},
                    "reference": {"decoded_sha256": "same", "dhash": "0"},
                },
                {"input": np.zeros((16, 16, 3)), "reference": np.zeros((16, 16, 3))},
            )
        )
    audit = audit_rows(rows)
    assert len(audit["cross_split_exact"]) == 2
    assert len(audit["cross_split_near"]) == 2
    assert [r[0]["split"] for r in rows] == ["train", "test"]


def test_frozen_identity_refuses_overwrite(tmp_path):
    path = tmp_path / "identity.json"
    freeze_json(path, {"seed": 0})
    freeze_json(path, {"seed": 0})
    with pytest.raises(ValueError):
        freeze_json(path, {"seed": 1})


def test_resume_comparison_detects_state_drift():
    stats = {"bitwise_equal": True, "max_absolute_tensor_difference": 0.0}
    with pytest.raises(AssertionError):
        compare_state({"optimizer": torch.tensor([1.0])}, {"optimizer": torch.tensor([1.1])}, stats)


def test_cosine_and_early_stopping_original_rules():
    p = torch.nn.Parameter(torch.tensor(1.0))
    opt = torch.optim.AdamW([p], lr=2e-4)
    sched = CosineAnnealingRestartLR(opt, [100], [1.0], eta_min=1e-6)
    assert opt.param_groups[0]["lr"] == pytest.approx(2e-4)
    for _ in range(100):
        opt.step()
        sched.step()
    assert opt.param_groups[0]["lr"] == pytest.approx(1e-6)
    early = EarlyStopping(patience=20, min_delta=1e-4, mode="max")
    assert not early(20.0)
    for _ in range(19):
        assert not early(20.00001)
    assert early(20.00001)


def test_upstream_rgb_metric_definitions():
    target = np.full((32, 32, 3), 0.5, dtype=np.float32)
    pred = target + 0.1
    assert compute_psnr(pred, target) == pytest.approx(20.0, abs=1e-5)
    assert compute_ssim(target, target) == pytest.approx(1.0)
