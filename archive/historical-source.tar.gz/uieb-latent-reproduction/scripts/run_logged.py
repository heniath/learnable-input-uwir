#!/usr/bin/env python3
"""Run RGB then latent, evaluate both once, report; survive SSH via tmux."""

import fcntl
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
config = json.loads((ROOT / "configs/protocol.json").read_text())
OUT = ROOT / "outputs" / config["experiment_id"]


def status(value):
    temporary = OUT / "job_status.json.tmp"
    temporary.write_text(
        json.dumps({"utc": datetime.now(timezone.utc).isoformat(), **value}, indent=2) + "\n"
    )
    os.replace(temporary, OUT / "job_status.json")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / ".runner.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        stages = [
            ["train", "--condition", "rgb"],
            ["train", "--condition", "latent"],
            ["evaluate"],
            ["report"],
        ]
        with (OUT / "training.log").open("a", buffering=1) as log:
            for args in stages:
                status({"status": "running", "stage": args, "runner_pid": os.getpid()})
                command = [sys.executable, "-u", str(ROOT / "scripts/experiment.py"), *args]
                result = subprocess.run(
                    command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=False
                )
                if result.returncode:
                    status({"status": "failed", "stage": args, "returncode": result.returncode})
                    subprocess.run(
                        [sys.executable, str(ROOT / "scripts/experiment.py"), "report"],
                        cwd=ROOT,
                        stdout=log,
                        stderr=subprocess.STDOUT,
                        check=False,
                    )
                    raise SystemExit(result.returncode)
            status({"status": "complete"})


if __name__ == "__main__":
    main()
