"""New study identity with immutable in-place references to completed parents."""

import json
import shutil
from pathlib import Path

from conditioning.protocol import validate_manifest
from diagnostics.protocol import atomic_json, canonical, digest
from global_study import protocol as parent

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "configs/study.json"
TRAINING = parent.TRAINING
GLOBAL = parent.ROOT


def config():
    value = json.loads(CONFIG.read_text())
    if value["experiment_id"] != "global_dimension_replication_v1" or value["new_runs"] != [[6, 1], [12, 1], [6, 2], [12, 2]]:
        raise ValueError("Unexpected experiment identity or run queue")
    if value["dimensions"] != [3, 6, 12] or value["seeds"] != [0, 1, 2]:
        raise ValueError("Unexpected comparison grid")
    return value


def output_root():
    return ROOT / "outputs" / config()["experiment_id"]


def sources():
    files = [ROOT / "README.md", CONFIG]
    for folder in ("src", "scripts", "tests"):
        files.extend((ROOT / folder).rglob("*.py"))
    return {str(p.relative_to(ROOT)): digest(p) for p in sorted(files)}


def is_new(dimension, seed):
    return [dimension, seed] in config()["new_runs"]


def run_directory(dimension, seed):
    if dimension not in config()["dimensions"] or seed not in config()["seeds"]:
        raise ValueError("Dimension/seed outside comparison grid")
    if dimension == 3:
        return parent.h1_directory(seed, "A2_global")
    if seed == 0:
        return parent.output_root() / "runs/seed_0" / f"d_{dimension}"
    return output_root() / "runs" / f"seed_{seed}" / f"d_{dimension}"


def diagnostic_directory(dimension, seed):
    if dimension == 3:
        return parent.output_root() / "diagnostics/H1" / f"seed_{seed}/A2_global"
    if seed == 0:
        return parent.output_root() / "diagnostics/dimension/seed_0" / f"d_{dimension}"
    return output_root() / "diagnostics" / f"seed_{seed}" / f"d_{dimension}"


def expected_identity(dimension, seed, frozen):
    if is_new(dimension, seed):
        return {"condition": f"d_{dimension}", "seed": seed, "frozen_identity": canonical(frozen)}
    return frozen["references"][f"d{dimension}_seed{seed}"]["identity"]


def verify_run(directory, identity=None):
    saved, rows = parent.verify_run(directory, identity)
    run = json.loads((directory / "run.json").read_text())
    if run["config"]["budget"] != config()["budget"]:
        raise ValueError("Run budget differs from the frozen pilot")
    history = json.loads((directory / "history.json").read_text())
    if [r["epoch"] for r in history] != list(range(1, 31)):
        raise ValueError("History must contain epochs 1–30")
    if any(len(r["batch_hashes"]) != 180 or r["validation_count"] != 80 for r in history):
        raise ValueError("Unexpected training/validation coverage")
    best = max(history, key=lambda r: (r["validation"]["psnr"], r["validation"]["ssim"]))
    if best["epoch"] != saved["best"]["epoch"]:
        raise ValueError("Selected epoch violates the frozen selection rule")
    if sum(180 - r["amp_skipped_updates_epoch"] for r in history) != saved["optimizer_steps"]:
        raise ValueError("Actual update counts do not reconcile")
    return saved, rows, history


def provenance(check_data=True):
    old = parent.verify(check_data)
    if config()["budget"] != old["config"]["budget"]:
        raise ValueError("Replication budget differs from the parent dimension screen")
    archive = parent.output_root()
    complete = json.loads((archive / "complete.json").read_text())
    if complete["frozen_identity"] != canonical(old) or (complete["h1_cells"], complete["dimension_cells"], complete["diagnostics"]) != (12, 4, 9):
        raise ValueError("Parent study is incomplete")
    for name, expected in complete["report_hashes"].items():
        if digest(archive / "reports" / name) != expected:
            raise ValueError("Parent report changed")
    references = {}
    for dimension, seed in ((3, 0), (3, 1), (3, 2), (6, 0), (12, 0)):
        directory = run_directory(dimension, seed)
        scope = "h1_seed0_config" if seed == 0 else "h1_seeds12_config"
        identity = {"condition": "A2_global" if dimension == 3 else f"d_{dimension}", "seed": seed,
                    "frozen_identity": old["parent_identities"][scope] if dimension == 3 else canonical(old)}
        saved, _, _ = verify_run(directory, identity)
        diagnostic = diagnostic_directory(dimension, seed)
        marker = json.loads((diagnostic / "complete.json").read_text())
        if marker["identity"]["checkpoint_sha256"] != saved["best_sha256"] or marker["identity"]["frozen_identity"] != canonical(old):
            raise ValueError("Reference diagnostic identity mismatch")
        parent.verify_diagnostic(diagnostic, marker["identity"])
        references[f"d{dimension}_seed{seed}"] = {
            "directory": str(directory), "identity": identity, "checkpoint_sha256": saved["best_sha256"],
            "artifact_hashes": {name: digest(directory / name) for name in ("complete.json", "run.json", "history.json", "metrics_per_image.csv")},
            "diagnostic_directory": str(diagnostic), "diagnostic_complete_sha256": digest(diagnostic / "complete.json")}
    return {"config": config(), "sources": sources(), "parent_frozen_identity": canonical(old),
            "parent_complete_sha256": digest(archive / "complete.json"), "manifest_sha256": old["manifest_sha256"],
            "environment": old["environment"], "references": references,
            "git": "No Git repository; source hashes/snapshot and pinned parent provenance record code state"}


def prepare():
    frozen = provenance()
    out = output_root()
    path = out / "frozen.json"
    if path.exists():
        if json.loads(path.read_text()) != frozen:
            raise ValueError("Already frozen with different inputs; use a new experiment identity")
        return frozen
    out.mkdir(parents=True, exist_ok=True)
    for relative in frozen["sources"]:
        target = out / "source_snapshot" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / relative, target)
    manifest = json.loads((parent.output_root() / "manifest.json").read_text())
    validate_manifest(manifest)
    atomic_json(out / "manifest.json", manifest)
    atomic_json(out / "frozen.json", frozen)
    return frozen


def verify(check_data=True):
    frozen = json.loads((output_root() / "frozen.json").read_text())
    if provenance(check_data) != frozen:
        raise ValueError("Frozen replication source/config/environment/reference changed")
    manifest = json.loads((output_root() / "manifest.json").read_text())
    validate_manifest(manifest)
    if canonical(manifest) != frozen["manifest_sha256"]:
        raise ValueError("Replication manifest changed")
    return frozen


def require_new(dimension, seed):
    if not is_new(dimension, seed):
        raise ValueError("Only the four authorized new runs can be trained or diagnosed here")


def paired_history(candidate, baseline):
    if len(candidate) != 30 or len(baseline) != 30 or any(
            a["epoch"] != b["epoch"] or a["batch_hashes"] != b["batch_hashes"] or a["lr"] != b["lr"]
            for a, b in zip(candidate, baseline)):
        raise ValueError("Paired sample/augmentation/scheduler history mismatch")
