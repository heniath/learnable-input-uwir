# Diagnostic study handoff

Implementation and verification completed; eight-run training started in tmux
session `latent-map-diagnostics` at 2026-10-13 17:16:53 UTC (2026-10-14 00:16:53
Asia/Phnom_Penh). First U-Net/RGB epoch completed and saved successfully. The job
automatically continues through all four U-Net conditions, all four NAFNet
conditions, validation diagnostics, and reporting. Do not supervise continuously;
the user prefers to leave persistent training running and check when returning.

## Where to check

- Output: `outputs/map_diagnostics_v1/`
- Status: `job_status.json`; durable logs: `training.log`, `preflight.log`
- Current run: `<backbone>/<condition>/seed_0/history.json`
- Completion: each run's `run_complete.json`, then `diagnostics.json`, then
  `reports/report_complete.json` and final `job_status.json` status `complete`
- Final findings: `reports/FINDINGS.md`, `results.json`, `results.csv`, and
  `paired_validation_differences.csv`

Eight focused tests, compile checks and isolated Ruff E4/E7/E9/F/I passed;
records are in `implementation_verification.json`. GPU smoke/resume checks passed
for all eight conditions; exact restored state and matching augmented batches
were verified. Capacity added-parameter mismatch is 0.353% on U-Net and 0.738%
on NAFNet. Peak PyTorch smoke allocation was 1.958 GiB. Smoke estimates about
8.11 hours for eight 100-epoch runs; this is approximate and excludes setup and
checkpoint writing, and early stopping may shorten training.

Frozen data has 720/80/90 pairs, with detected exact/near-duplicate groups kept
within partitions. Historical final90 remains reserved; its results were already
inspected during reproduction. This phase does no test prediction. One seed,
validation selection and uncertain scene independence constrain interpretation.

## Restart after an actual interruption

Inspect status, logs, tmux and GPU processes first. Do not start a second runner
while one exists. With no active runner, restart the same command in tmux from
this directory:

```bash
tmux new-session -d -s latent-map-diagnostics -c /home/heniath/Experiments/latent-map-diagnostics /home/heniath/miniforge3/envs/uieb-latent-repro/bin/python -u scripts/run_logged.py
```

It preserves completed runs and resumes incomplete runs at the saved epoch
boundary. Full model/optimizer/scheduler/scaler/early-stopping/RNG states are
saved. Exact numerical continuation is not guaranteed; measured small U-Net
drift is retained in `validation.json`.

Do not edit frozen code, config, dependencies, images or weights while running.
Protocol changes require a new experiment ID and preflight. Do not reduce batch
size or resolution on OOM; stop and report. No additional seeds, datasets or
architectures are authorized as part of this stage before evidence review.

The original reproduction checkpoint hashes/test results and pristine upstream
Git state were reverified after this job launched. Earlier projects and artifacts
remain preserved. Full-text novelty comparison is `research/NOVELTY.md`;
conditioning and map interventions alone are not new contributions.
