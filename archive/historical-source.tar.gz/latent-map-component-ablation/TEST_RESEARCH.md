# UIEB test90 component ablation

Run: `map_components_uieb_test_v1`, completed 2026-10-16 at the user's explicit
request to evaluate UIEB test results. This is a separate evaluation from
validation80; the historical validation report remains preserved.

The three seed-0 checkpoints, seven intervention definitions, and cyclic donor
rule were fixed before test inference. The exact historical sorted indices
800:890 from the frozen parent manifest identify the 90 test images. Split
disjointness, dataset hashes, source/config/environment identities, checkpoint
hashes and parent diagnostic artifacts were checked. No training, tuning,
checkpoint selection or early stopping used test results. Each checkpoint
reproduced its original 80 validation-image PSNR and SSIM with zero drift before
its test predictions.

Protocol: original 256-pixel resize/center-crop, float32, batch size 4 with the
final partial batch retained, clipped predictions and original PSNR/SSIM
implementations. These are not native-resolution benchmark numbers. Historical
test exposure already existed in the inherited research.

## Intact checkpoints

| Checkpoint | Test PSNR | Test SSIM | PSNR delta vs RGB |
|---|---:|---:|---:|
| RGB | 23.2638 | 0.90034 | — |
| Unbounded maps, zero initialization | 23.3223 | 0.90479 | +0.0586 |
| Bounded maps, zero initialization | 23.3027 | 0.90237 | +0.0389 |

Both intact map models have small positive mean test differences. This differs
from their negative validation differences. It does not establish a repeatable
advantage: only one training seed is available, and test results must not drive
checkpoint selection or repeated tuning.

## Component dependence

For unbounded maps, zeroing spatial maps costs 0.9708 dB versus 0.1477 dB for
global maps. Replacing spatial channels by their own image means costs 0.9569
dB. Swapping spatial maps between test images costs 2.0164 dB, versus 0.5209 dB
for global-map swaps. These show dependence on spatial structure and on correct
image/map pairing under the specified interventions.

The bounded checkpoint also has a larger spatial-swap loss (1.2994 dB) than
global-swap loss (0.1974 dB). Its zero-spatial loss is 4.6266 dB; zero is outside
the bounded spatial head's [0.1, 1] range, so this large drop is especially
vulnerable to a distribution-shift explanation.

Results support greater sensitivity to spatial-map interventions in these
checkpoints. They do not establish SCA redundancy, physical map semantics,
or separately trained spatial-only/global-only model performance. Zero-both
remains the jointly trained map checkpoint, not a fresh RGB model. Effects can
interact and should not be added to infer independent component contributions.

Full per-image scores and paired summaries are in
`outputs/map_components_uieb_test_v1/`. Runtime was 27.88 seconds, including
verification and validation anchors; peak PyTorch allocation was 362,641,920
bytes. These describe the whole evaluation, not isolated model latency.
