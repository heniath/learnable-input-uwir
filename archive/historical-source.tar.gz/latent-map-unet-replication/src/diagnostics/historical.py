"""Read-only provenance for the original seed-0 U-Net runs."""

import json

from .protocol import ROOT, canonical, config, digest, environment, output_root


def parent_root():
    return (ROOT / config()["parent_directory"]).resolve()


def capture_reference():
    parent = parent_root()
    archive = parent / "outputs/map_diagnostics_v1"
    frozen_path = archive / "frozen_protocol.json"
    if digest(frozen_path) != config()["parent_frozen_sha256"]:
        raise ValueError("Parent frozen protocol changed")
    frozen = json.loads(frozen_path.read_text())
    allowed = {"experiment_id", "model_seeds", "backbones", "screening"}
    for key, expected in frozen["config"].items():
        if key not in allowed and config()[key] != expected:
            raise ValueError(f"Unexpected parent protocol change: {key}")
    if config()["backbones"] != ["unet"] or config()["model_seeds"] != [1, 2]:
        raise ValueError("This study requires U-Net seeds 1 and 2")
    if environment() != frozen["environment"]:
        raise ValueError("Environment differs from the parent study")
    for rel, expected in frozen["source_hashes"].items():
        if digest(parent / rel) != expected:
            raise ValueError(f"Historical source changed: {rel}")
    for name in ("models.py", "engine.py", "validation.py"):
        rel = f"src/diagnostics/{name}"
        if digest(ROOT / rel) != frozen["source_hashes"][rel]:
            raise ValueError(f"Replication training implementation changed: {name}")
    if (
        canonical(json.loads((archive / "manifest.json").read_text()))
        != config()["parent_manifest_sha256"]
    ):
        raise ValueError("Parent manifest changed")
    files = {str(frozen_path.relative_to(parent)): digest(frozen_path)}
    files["outputs/map_diagnostics_v1/manifest.json"] = digest(
        archive / "manifest.json"
    )
    runs = []
    for condition in config()["conditions"]:
        run = archive / "unet" / condition / "seed_0"
        diagnostic = json.loads((run / "diagnostics.json").read_text())
        identity = {
            "backbone": "unet",
            "condition": condition,
            "seed": 0,
            "frozen_identity": canonical(frozen),
        }
        if diagnostic["identity"] != identity:
            raise ValueError(f"Historical run identity mismatch: {condition}")
        if digest(run / "best.pt") != diagnostic["checkpoint_sha256"]:
            raise ValueError(f"Historical best checkpoint changed: {condition}")
        names = set(diagnostic["artifact_hashes"]) | {
            "best.pt",
            "diagnostics.json",
            "history.json",
            "run.json",
            "run_complete.json",
        }
        for name in names:
            path = run / name
            actual = digest(path)
            if (
                name in diagnostic["artifact_hashes"]
                and actual != diagnostic["artifact_hashes"][name]
            ):
                raise ValueError(f"Historical diagnostic changed: {condition}/{name}")
            files[str(path.relative_to(parent))] = actual
        runs.append({**identity, "directory": str(run.relative_to(parent))})
    return {
        "experiment_id": "map_diagnostics_v1",
        "origin": "historical",
        "parent_directory": config()["parent_directory"],
        "runs": runs,
        "source_hashes": frozen["source_hashes"],
        "artifact_hashes": files,
    }


def verify_reference(frozen=None):
    path = output_root() / "historical_reference.json"
    if frozen is None:
        frozen = json.loads((output_root() / "frozen_protocol.json").read_text())
    if digest(path) != frozen["historical_reference_sha256"]:
        raise ValueError("Historical reference record changed")
    reference = json.loads(path.read_text())
    if reference["parent_directory"] != config()["parent_directory"]:
        raise ValueError("Historical reference points to a different parent")
    parent = parent_root()
    for group in ("source_hashes", "artifact_hashes"):
        for rel, expected in reference[group].items():
            if digest(parent / rel) != expected:
                raise ValueError(f"Historical input changed: {rel}")
    return reference
