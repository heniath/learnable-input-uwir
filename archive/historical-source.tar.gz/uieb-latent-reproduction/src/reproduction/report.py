"""Report real measured results and the historical comparability boundaries."""

import csv
import json

from .engine import run_dir
from .protocol import atomic_json, config, output_root


def report():
    out = output_root()
    rows = []
    for condition in config()["conditions"]:
        directory = run_dir(condition)
        completion = (
            json.loads((directory / "run_complete.json").read_text())
            if (directory / "run_complete.json").exists()
            else {}
        )
        test = (
            json.loads((directory / "test_results.json").read_text())
            if (directory / "test_results.json").exists()
            else {}
        )
        history = (
            json.loads((directory / "history.json").read_text())
            if (directory / "history.json").exists()
            else []
        )
        best = completion.get("best", {})
        if not best and history:
            r = max(history, key=lambda r: (r["validation"]["psnr"], r["validation"]["ssim"]))
            best = {"epoch": r["epoch"], **r["validation"]}
        rows.append(
            {
                "condition": condition,
                "status": "evaluated"
                if test
                else "trained"
                if completion
                else "in_progress"
                if history
                else "pending",
                "epochs": completion.get("epoch", len(history)),
                "best_epoch": best.get("epoch"),
                "validation_psnr": best.get("psnr"),
                "validation_ssim": best.get("ssim"),
                "test_psnr": test.get("test", {}).get("psnr"),
                "test_ssim": test.get("test", {}).get("ssim"),
                "runtime_hours": completion.get(
                    "training_seconds", sum(r["epoch_seconds"] for r in history)
                )
                / 3600,
                "peak_allocated_gib": completion.get("peak_allocated_bytes", 0) / 2**30
                if completion
                else None,
                "stop_reason": completion.get("reason"),
            }
        )
    delta = {}
    if all(r["test_psnr"] is not None for r in rows):
        delta = {
            k: rows[1][k] - rows[0][k]
            for k in ["validation_psnr", "validation_ssim", "test_psnr", "test_ssim"]
        }
    manifest = json.loads((out / "manifest.json").read_text())
    exact = manifest["audit"]["cross_split_exact"]
    near = manifest["audit"]["cross_split_near"]
    frozen = json.loads((out / "frozen_protocol.json").read_text())
    validation = (
        json.loads((out / "validation.json").read_text())
        if (out / "validation.json").exists()
        else {}
    )
    reports = out / "reports"
    reports.mkdir(exist_ok=True)
    with (reports / "results.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    atomic_json(reports / "results.json", {"runs": rows, "latent_minus_rgb": delta})
    lines = [
        "# Original UIEB latent-map reproduction",
        "",
        "Seed 0, pinned original code, historical 720/80/90 split.",
        "",
        "| Condition | Status | Epochs | Selected epoch | Val PSNR | Val SSIM | Test PSNR | Test SSIM | Hours | Peak allocated GiB |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    keys = [
        "condition",
        "status",
        "epochs",
        "best_epoch",
        "validation_psnr",
        "validation_ssim",
        "test_psnr",
        "test_ssim",
        "runtime_hours",
        "peak_allocated_gib",
    ]
    for row in rows:
        lines.append(
            "| "
            + " | ".join(
                "—"
                if row[k] is None
                else f"{row[k]:.4f}"
                if isinstance(row[k], float)
                else str(row[k])
                for k in keys
            )
            + " |"
        )
    lines += [
        "",
        "Runtime is the sum of recorded epoch wall times, including validation and metrics; setup and checkpoint writes are excluded. VRAM is peak PyTorch allocation, not total driver usage.",
        "",
    ]
    if delta:
        lines += [
            f"Latent minus RGB: validation PSNR {delta['validation_psnr']:+.3f} dB, SSIM {delta['validation_ssim']:+.4f}; held-out test PSNR {delta['test_psnr']:+.3f} dB, SSIM {delta['test_ssim']:+.4f}.",
            "",
            "The local seed-0 test PSNR gain "
            + (
                "has the same positive direction as"
                if delta["test_psnr"] > 0
                else "does not reproduce the positive direction of"
            )
            + " the notebook gain. This is a descriptive single-seed comparison.",
            "",
        ]
    else:
        lines += [
            "Both selected checkpoints have not yet been evaluated. No conclusion about model quality is available.",
            "",
        ]
    historical = config()["notebook_seed0_test_psnr"]
    lines += [
        f"Historical Downloads notebook: RGB {historical['rgb']:.3f} dB; latent {historical['latent']:.3f} dB; difference {historical['latent'] - historical['rgb']:+.3f} dB. Historical source/environment identity is unverified; exact agreement is not required.",
        "",
        f"Audit: {len(exact)} exact duplicate role-pairs and {len(near)} near-duplicate candidate role-pairs cross partitions. Near candidates include exact matches and do not prove scene identity. The historical split is retained; overlap limits claims of independent held-out generalization. Full names and split roles are in `manifest.json`.",
        "",
        f"Pinned revision: `{frozen['upstream_git_commit']}`. GPU: {frozen['environment']['gpu']}; PyTorch {frozen['environment']['torch']}; CUDA runtime {frozen['environment']['cuda_runtime']}.",
        "",
        "Models, dataset transforms, loss computations, training/validation inner loops, cosine scheduler, early-stopping class, and metrics are called from the unmodified upstream checkout. Checkpointing additionally retains scheduler, scaler, early stopping and Python/NumPy/CPU/CUDA RNG states. Test prediction uses float32 inference with upstream clipped RGB PSNR and scikit-image SSIM, with an unweighted image mean.",
        "",
        "Seeding matches the original notebook. cuDNN deterministic=True and benchmark=False are retained; strict deterministic algorithms and TF32 changes are not imposed. Cross-version/hardware bitwise replay cannot be guaranteed. The smoke replay checks sample/augmentation hashes, model, optimizer, scheduler, scaler, early stopping, and RNG state.",
        "",
    ]
    for condition, result in validation.get("conditions", {}).items():
        lines.append(
            f"- {condition} epoch-boundary resume: restoration bitwise equal={result['resume_check']['exact_restoration']['bitwise_equal']}; continuation bitwise equal={result['resume_check']['bitwise_equal']}; maximum tensor difference={result['resume_check']['max_absolute_tensor_difference']:.3g}; validation drift={result['resume_check']['validation_metric_deltas']}; batch-size-4 GPU smoke passed."
        )
    lines += [
        "",
        "The initial v1 preflight required strict continuation equality and failed. Its checkpoints, failure and diagnostics remain preserved in outputs/original_uieb_seed0_v1/. Diagnostics verified exact restoration and numerical variation in a fresh uninterrupted repetition too. The revised v2 preflight requires exact restoration, matching augmentation/order hashes and continued RNG/scheduler/scaler state, finite training and small validation drift (<0.01 dB PSNR, <0.0001 SSIM). It measures rather than promises bitwise continuation. No scientific protocol factor changed.",
        "",
        "CUDA interpolation may have nondeterministic gradients, and float16 interpolation gradients may be inaccurate; this is a possible explanation rather than a proven attribution of the observed variation. See [PyTorch 2.11 interpolation documentation](https://docs.pytorch.org/docs/2.11/generated/torch.nn.functional.interpolate.html). Full runs are intended to execute uninterrupted in tmux; restarting cannot promise an identical numerical trajectory.",
        "",
        "The cloned environment inherits four pip-check conflicts in the unrelated mambavision package (mamba-ssm, Pillow, requests and transformers). The same conflicts were verified in ml-base; they were not introduced or modified for this reproduction. Kornia 0.7.3 emits an upstream AMP deprecation warning under the local PyTorch version.",
        "",
        "Two conditions and one seed do not separate a representation benefit from the latent model's added capacity or establish seed robustness. NAFNet, other datasets, additional seeds and reconstruction variants remain deferred.",
        "",
    ]
    (reports / "FINDINGS.md").write_text("\n".join(lines))
    print(str(reports / "FINDINGS.md"), flush=True)
    return rows
