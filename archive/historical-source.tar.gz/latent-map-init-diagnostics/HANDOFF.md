# Map-input initialization study handoff

Status: **complete**. Runner invocation started UTC: 2026-10-14T14:08:31.704871+00:00.

Current/final stage: `all stages complete`.

Five fresh NAFNet runs: rgb, bounded, bounded_zero_init, unbounded, unbounded_zero_init; seed 0. Original early stopping retained.

Outputs: `outputs/map_init_diagnostics_v1/`. Check `job_status.json`, `training.log`, and each condition's `seed_0/history.json`.

Final deliverables: `reports/FINDINGS.md`, `results.json`, `results.csv`, `paired_validation_differences.csv`, `convergence.csv`, `common_horizon_scores.csv`, then `reports/report_complete.json`.

Persistent tmux session: `latent-map-init-diagnostics`. Do not supervise continuously; check when returning. Do not start a duplicate runner.

After an actual interruption, inspect status, tmux, processes and GPU first. With no active runner, restart from this directory:

```bash
tmux new-session -d -s latent-map-init-diagnostics -c /home/heniath/Experiments/latent-map-init-diagnostics /home/heniath/miniforge3/envs/uieb-latent-repro/bin/python -u scripts/run_logged.py
```

Completed artifacts are preserved. Incomplete training resumes from saved epoch boundaries with full optimizer/scheduler/scaler/stopping/RNG state. Exact numerical CUDA continuation is not guaranteed.

Do not edit frozen code, config, dependencies, images or weights while running. On OOM, stop and report; do not reduce resolution/batch size. No new seeds, stopping-policy changes or test predictions are authorized. Original study and artifacts remain preserved.
