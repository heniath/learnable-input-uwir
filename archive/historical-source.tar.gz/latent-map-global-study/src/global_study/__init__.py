"""Global-vector replication and diagnostics with frozen parent dependencies."""
