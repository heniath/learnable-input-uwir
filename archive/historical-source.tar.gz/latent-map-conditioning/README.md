# Spatial/global conditioning on a fixed U-Net

New study, with read-only dependencies on `../latent-map-diagnostics`. Existing
source, checkpoints, data, reports and environments are preserved. No packages
are installed. Use the existing Conda environment `uieb-latent-repro`.

H1 isolates training with spatial-only, global-only and both bounded maps.
H2 implements static conditioning. No dynamic gates, output-head changes,
backbone changes, automatic candidate promotion or test predictions are included.

## Frozen protocol

The complete training recipe is resolved from the parent's frozen config,
including AdamW, learning rate, weight decay, AMP, gradient clipping, original
L1+VGG loss, paired initialization, augmentation and manifest. Files, split,
weights and parent sources are hashed and verified. New source/config/environment
identities and a source snapshot are stored under a unique experiment ID.
This directory is not a Git repository; no commit is fabricated. The pinned
upstream commit, clean checkout and local source hashes are recorded instead.

Use the `*_v2.json` configs below. V1 implementation-check artifacts are retained
unchanged; v2 corrects metadata to count actual AdamW updates when AMP skips a
step. This changes bookkeeping, not the prescribed training recipe.

- H1 pilot trains **from scratch**, seed 0, 30 epochs, the prefix of the original
  100-epoch cosine schedule, no early stopping. All four cells get this budget.
- H1 full uses seeds 0/1/2, maximum 100 epochs, the original patience 20 and
  min-delta 0.0001. Realized training steps can differ due to early stopping.
- H2 pilot also starts from scratch, with an equally budgeted input-only baseline.
  Its config is prepared for later use; completing H1 does not launch it.
- Selection maximizes the validation `(PSNR, SSIM)` tuple, retaining the earliest
  exact tie. PSNR/SSIM use original per-image metrics on clipped float32 outputs.
- The 720/80/90 duplicate-grouped manifest and image order are inherited exactly.
  Loaders support only train and validation. Historical test exposure and
  unresolved scene independence remain limitations.
- LPIPS/external evaluation are not silently substituted or added. Select the
  paired external dataset and freeze that separate protocol before evaluation.

Pilot and full are separate conditions; pilot findings do not establish full
convergence. New runs reset training RNG after construction consistently across
conditions. This is explicitly recorded source behavior; old checkpoints are not
silently pooled into the new factorial comparison.

## Architecture

All models retain the original 64/128/256/512/1024 U-Net and direct sigmoid head.
Input remains RGB + three S slots + three G slots. A disabled branch is removed,
not computed, and its slots are zeros. Shared first-convolution weights and
active head weights are identical within seed. Parameter reports distinguish
registered parameters from structurally active parameters and dormant input
columns. This is not a compute-matched factorial design.

E1/E2 modulation changes **skip copies passed to the decoder only**. The next
encoder block receives the original feature. Spatial gates use randomly
initialized 3-to-C projections, tanh and scalar alpha initialized to zero.
Global FiLM uses the B×3 global vector before broadcast, an MLP with hidden64
and zero final linear layer. Bottleneck modulation is after its feature block,
before upsampling. Decoder BN remains in place.

`models.SPECS` additionally provides swapped-placement, constant-condition
adapter controls and no-input-concat controls. They are not in the default
screen and require a separately frozen config if promoted. Constant controls
keep normal maps at input and feed ones to the same adapters, matching adapter
parameters but not conditioned input information. Their effective capacity and
computation are not claimed to be equivalent. No-concat controls retain dormant
zero input slots for first-convolution shape consistency.

## Commands

From this directory, with that environment's Python:

```bash
python -m unittest discover -s tests -v
python scripts/run.py --config configs/h1_pilot_v2.json prepare
python scripts/run.py --config configs/h1_pilot_v2.json smoke
python scripts/run.py --config configs/h1_pilot_v2.json train --condition A0_rgb --seed 0
python scripts/run.py --config configs/h1_pilot_v2.json train --condition A1_spatial --seed 0
python scripts/run.py --config configs/h1_pilot_v2.json train --condition A2_global --seed 0
python scripts/run.py --config configs/h1_pilot_v2.json train --condition A3_both --seed 0
python scripts/run.py --config configs/h1_pilot_v2.json report
python scripts/run.py --config configs/h1_pilot_v2.json profile --condition A3_both --seed 0
```

Preparation verifies dataset hashes without predicting test images. Smoke uses
two real batches per condition, checks gradients and exact full-state checkpoint
restoration. Its tiny validation subset is a functionality check, not a result.
The runner requires CUDA; CPU unit tests remain available. In restricted shells,
GPU access may need execution outside the sandbox.

Run each long training command in an existing tmux/session manager with stdout
and stderr redirected to a persistent log. A process lock prevents concurrent
commands in this project. No long training is launched by `prepare` or `smoke`.
Completed runs are preserved; interrupted runs resume from `last.pt`, restoring
optimizer/scheduler/scaler/early-stopping/RNG. CUDA trajectories need not replay
bit for bit. A crash before the first last checkpoint requires explicit inspection.

Each run stores its resolved config/identity, best and last checkpoints,
per-epoch history/CSV, actual optimizer update and AMP-skip counts, batch hashes, per-image best validation PSNR/SSIM,
parameter counts, Conv/Linear MACs, training epoch time and peak allocated VRAM.
MACs omit interpolation, BN, activations, pooling and elementwise gates.
The explicit `profile` command measures a completed selected checkpoint using
the original batch1 float32 CUDA-event protocol (10 warmups/50 measurements),
saving median/mean/p95 latency and inference peak allocated VRAM separately from
training. It excludes preprocessing, transfers and metrics.

Reports compare only completed runs with matching identity and filenames. They
compute paired per-image differences, seed-wise gains and sample SD, and the
H1 interaction `P_SG - P_S - P_G + P_RGB` only when all four cells exist for a
seed. No confidence interval treating duplicated scenes as independent is added.
An interaction on the dB scale is descriptive, not evidence of physical semantics.

Do not edit frozen study files to extend a completed experiment. Use a new
experiment ID/config; changing shared source also requires re-preparation and
smoke for any subsequent study.
