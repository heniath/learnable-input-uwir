"""Paired validation contrasts; missing seeds are explicit and never imputed."""

import csv
import json
import math
import statistics

from diagnostics.protocol import atomic_json, canonical, digest

from .protocol import local_sources, output_root, validate_manifest, write_csv


def mean_sd(values):
    return {"mean": statistics.mean(values), "sample_sd": statistics.stdev(values) if len(values) > 1 else None, "n_seeds": len(values)}


def paired_rows(candidate, baseline):
    def indexed(rows):
        result = {r["filename"]: r for r in rows}
        if len(result) != len(rows):
            raise ValueError("Duplicate filename in per-image metrics")
        return result

    a, b = indexed(candidate), indexed(baseline)
    if a.keys() != b.keys():
        raise ValueError("Candidate and baseline filename sets differ")
    return [{"filename": name, "delta_psnr": float(a[name]["psnr"]) - float(b[name]["psnr"]),
             "delta_ssim": float(a[name]["ssim"]) - float(b[name]["ssim"])} for name in sorted(a)]


def factorial(scores):
    required = ("A0_rgb", "A1_spatial", "A2_global", "A3_both")
    if any(name not in scores for name in required):
        raise ValueError("All four trained H1 conditions are required for interaction")
    p0, ps, pg, psg = (scores[name] for name in required)
    return {"spatial_vs_rgb_db": ps - p0, "global_vs_rgb_db": pg - p0,
            "both_vs_rgb_db": psg - p0, "interaction_db": psg - ps - pg + p0}


def report(config_path, config):
    out = output_root(config)
    frozen = json.loads((out / "frozen.json").read_text())
    if frozen["config"] != config or frozen["source_hashes"] != local_sources(config_path):
        raise ValueError("Report source/config differs from the frozen study")
    manifest = json.loads((out / "manifest.json").read_text())
    validate_manifest(manifest)
    if canonical(manifest) != frozen["manifest_sha256"]:
        raise ValueError("Report manifest identity mismatch")
    expected_names = {manifest["pairs"][i]["filename"] for i in manifest["indices"]["validation"]}
    summary, missing, completed = [], [], {}
    for seed in config["seeds"]:
        for condition in config["conditions"]:
            directory = out / "runs" / f"seed_{seed}" / condition
            marker = directory / "complete.json"
            if not marker.exists():
                missing.append({"seed": seed, "condition": condition})
                continue
            saved = json.loads(marker.read_text())
            identity = {"condition": condition, "seed": seed, "frozen_identity": canonical(frozen)}
            if saved["identity"] != identity or digest(directory / "best.pt") != saved["best_sha256"] or digest(directory / "metrics_per_image.csv") != saved["per_image_sha256"]:
                raise ValueError(f"Completed run identity/artifact mismatch: {condition} seed {seed}")
            with (directory / "metrics_per_image.csv").open() as handle:
                rows = list(csv.DictReader(handle))
            if len(rows) != 80 or {r["filename"] for r in rows} != expected_names:
                raise ValueError("Metrics must cover exactly the frozen validation images")
            for metric in ("psnr", "ssim"):
                values = [float(r[metric]) for r in rows]
                if not all(math.isfinite(v) for v in values) or abs(statistics.mean(values) - saved["best"][metric]) > 1e-5:
                    raise ValueError("Per-image metrics do not reproduce the selected checkpoint score")
            completed[(seed, condition)] = (saved, rows)
            summary.append({"seed": seed, "condition": condition, **saved["best"], "final_epoch": saved["final_epoch"],
                            "optimizer_steps": saved["optimizer_steps"], "amp_skipped_updates": saved["amp_skipped_updates"],
                            **saved["parameters"], "conv_linear_macs": saved["conv_linear_macs"],
                            "peak_allocated_bytes": saved["peak_allocated_bytes"]})
    target = out / "reports"
    target.mkdir(exist_ok=True)
    if summary:
        write_csv(target / "validation_summary.csv", summary)
    baseline = "A0_rgb" if config["phase"] == "H1" else "B0_input"
    per_image, comparisons, interactions = [], [], []
    for seed in config["seeds"]:
        for condition in config["conditions"]:
            if condition == baseline or (seed, condition) not in completed or (seed, baseline) not in completed:
                continue
            rows = paired_rows(completed[(seed, condition)][1], completed[(seed, baseline)][1])
            per_image.extend({"seed": seed, "condition": condition, "baseline": baseline, **r} for r in rows)
            comparisons.append({"seed": seed, "condition": condition, "baseline": baseline,
                                "delta_psnr": statistics.mean(r["delta_psnr"] for r in rows),
                                "delta_ssim": statistics.mean(r["delta_ssim"] for r in rows),
                                "psnr_win_fraction": sum(r["delta_psnr"] > 0 for r in rows) / len(rows)})
        if config["phase"] == "H1" and all((seed, c) in completed for c in ("A0_rgb", "A1_spatial", "A2_global", "A3_both")):
            scores = {c: completed[(seed, c)][0]["best"]["psnr"] for c in config["conditions"] if (seed, c) in completed}
            interactions.append({"seed": seed, **factorial(scores)})
    if comparisons:
        write_csv(target / "paired_by_seed.csv", comparisons)
        write_csv(target / "paired_per_image.csv", per_image)
    if interactions:
        write_csv(target / "factorial_by_seed.csv", interactions)
    aggregates = {}
    for condition in config["conditions"]:
        rows = [r for r in comparisons if r["condition"] == condition]
        if rows:
            aggregates[condition] = {key: mean_sd([r[key] for r in rows]) for key in ("delta_psnr", "delta_ssim")}
    results = {"frozen_identity": canonical(frozen), "completed_runs": len(summary), "missing_runs": missing,
               "paired_differences": aggregates, "factorial_by_seed": interactions,
               "interaction_summary": mean_sd([r["interaction_db"] for r in interactions]) if interactions else None,
               "limits": ["Validation-selected results, not independent confirmation", "Pilot is a screening condition, not a converged quality claim", "Interaction is descriptive on the dB scale; not physical or semantic complementarity", "No image-level confidence interval without reliable scene groups", "Seeds are not pooled with images as independent replicates"]}
    atomic_json(target / "results.json", results)
    lines = ["# Validation-only conditioning study", "", f"Completed runs: {len(summary)} / {len(config['conditions']) * len(config['seeds'])}.",
             "", "| Seed | Condition | Epoch | PSNR | SSIM |", "|---|---|---|---|---|"]
    lines.extend(f"| {r['seed']} | {r['condition']} | {r['epoch']} | {r['psnr']:.5f} | {r['ssim']:.6f} |" for r in summary)
    lines.extend(["", "Missing runs are listed in results.json. Factorial interaction requires all four conditions for the same seed.",
                  "Conv/Linear MACs omit interpolation, normalization, pooling, activation and elementwise operations.",
                  "No test inference, model promotion or generalization claim is made by this report.", ""])
    (target / "FINDINGS.md").write_text("\n".join(lines))
    print(f"Report written: {target}; completed={len(summary)}, missing={len(missing)}", flush=True)
