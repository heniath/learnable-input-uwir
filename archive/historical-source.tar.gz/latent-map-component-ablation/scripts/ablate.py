#!/usr/bin/env python3
"""Read-only parent checkpoints; separate durable component intervention results."""

import argparse
import csv
import fcntl
import json
import os
from pathlib import Path
import shutil
import sys
import time
from datetime import datetime, timezone

os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT.parent / "latent-map-init-diagnostics"
sys.path[:0] = [str(PARENT / "src"), str(PARENT / "third_party/upstream/src"),
                str(PARENT / "third_party/nafnet")]

import numpy as np
import torch
from diagnostics.diagnose import metric_rows
from diagnostics.models import EnhancementModel
from diagnostics.protocol import (atomic_json, base_dataset, canonical, config, digest, loader,
                                  seed_original, verify_frozen)

CONDITIONS = ("rgb", "unbounded_zero_init", "bounded_zero_init")
INTERVENTIONS = ("normal", "zero_spatial", "zero_global", "zero_both",
                 "spatial_mean", "swap_spatial", "swap_global")


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_csv(path, rows):
    with path.open("x", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def override_maps(maps, name, donor_maps):
    spatial, global_map = maps
    if name == "normal":
        return maps
    if name == "zero_spatial":
        return torch.zeros_like(spatial), global_map
    if name == "zero_global":
        return spatial, torch.zeros_like(global_map)
    if name == "zero_both":
        return torch.zeros_like(spatial), torch.zeros_like(global_map)
    if name == "spatial_mean":
        return spatial.mean((-2, -1), keepdim=True).expand_as(spatial), global_map
    if name == "swap_spatial":
        return donor_maps[0], global_map
    if name == "swap_global":
        return spatial, donor_maps[1]
    raise ValueError(name)


def check_reproduction(rows, saved_path):
    with saved_path.open() as handle:
        saved = {r["filename"]: r for r in csv.DictReader(handle)}
    if set(saved) != {r["filename"] for r in rows}:
        raise ValueError("Validation filename coverage differs from parent")
    drift = {key: max(abs(r[key] - float(saved[r["filename"]][key])) for r in rows)
             for key in ("psnr", "ssim")}
    if drift["psnr"] > 0.001 or drift["ssim"] > 0.00001:
        raise ValueError(f"Parent per-image metrics do not reproduce: {drift}")
    return drift


def evaluation_batches(split, manifest):
    if split == "validation":
        data_loader = loader("validation", seed=0, filenames=True)
    else:
        # Separate evaluation-only loader: the parent's training interface stays
        # validation-only. Reuse its exact image preprocessing and frozen indices.
        c = config()
        dataset = torch.utils.data.Subset(base_dataset(augment=False), manifest["indices"]["test"])
        data_loader = torch.utils.data.DataLoader(
            dataset, batch_size=c["batch_size"], shuffle=False,
            num_workers=c["workers"], pin_memory=True, drop_last=False,
        )
    batches = [(x, y, list(names)) for x, y, names, _ in data_loader]
    expected = [manifest["pairs"][i]["filename"] for i in manifest["indices"][split]]
    count = 80 if split == "validation" else 90
    if [n for _, _, names in batches for n in names] != expected or len(expected) != count:
        raise ValueError(f"Frozen {split} sample order/count mismatch")
    if any(manifest["pairs"][i]["split"] != split for i in manifest["indices"][split]):
        raise ValueError("Manifest split membership mismatch")
    return batches


@torch.inference_mode()
def evaluate(condition, batches, checkpoint, output, split="validation", validation_batches=None):
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)
    identity = json.loads((checkpoint.parent / "run.json").read_text())
    if state["identity"] != identity:
        raise ValueError("Checkpoint/run identity mismatch")
    model = EnhancementModel("nafnet", condition, 0).cuda().eval()
    model.load_state_dict(state["model"], strict=True)
    del state
    if split == "test":
        anchor_rows = []
        for x, y, names in validation_batches:
            anchor_rows.extend(metric_rows(model(x.cuda()), y, names))
        drift = check_reproduction(anchor_rows, checkpoint.parent / "per_image_validation_normal.csv")
        print(f"{condition}: validation anchor reproduced; max drift {drift}", flush=True)
    maps_by_name, rows = {}, {"normal": []}
    for x, y, names in batches:
        prediction, maps = model(x.cuda(), return_maps=True)
        rows["normal"].extend(metric_rows(prediction, y, names))
        if maps is not None:
            if not all(torch.isfinite(m).all() for m in maps):
                raise FloatingPointError("Non-finite maps")
            for i, name in enumerate(names):
                maps_by_name[name] = tuple(m[i].cpu().clone() for m in maps)
    if split == "validation":
        drift = check_reproduction(rows["normal"], checkpoint.parent / "per_image_validation_normal.csv")
        print(f"{condition}: intact metrics reproduced; max drift {drift}", flush=True)
    print(f"{condition}/{split}/normal: PSNR {np.mean([r['psnr'] for r in rows['normal']]):.4f}", flush=True)
    donor_names = {}
    if condition != "rgb":
        names = sorted(maps_by_name)
        donor_names = {name: names[(i + 1) % len(names)] for i, name in enumerate(names)}
        for intervention in INTERVENTIONS[1:]:
            values = []
            for x, y, names in batches:
                maps = tuple(torch.stack([maps_by_name[n][i] for n in names]).cuda() for i in (0, 1))
                donors = tuple(torch.stack([maps_by_name[donor_names[n]][i] for n in names]).cuda()
                               for i in (0, 1))
                changed = override_maps(maps, intervention, donors)
                values.extend(metric_rows(model(x.cuda(), maps_override=changed), y, names))
            rows[intervention] = values
            print(f"{condition}/{intervention}: PSNR {np.mean([r['psnr'] for r in values]):.4f}", flush=True)
    for intervention, values in rows.items():
        count = 80 if split == "validation" else 90
        if len(values) != count or len({r["filename"] for r in values}) != count:
            raise ValueError(f"Expected {count} unique {split} images")
        if not all(np.isfinite(r[key]) for r in values for key in ("psnr", "ssim")):
            raise FloatingPointError("Non-finite metrics")
        write_csv(output / f"{condition}_{intervention}.csv", values)
    del model, maps_by_name
    torch.cuda.empty_cache()
    return rows, {"max_per_image_reproduction_drift": drift, "swap_donors": donor_names}


def summarize(all_rows, output, split="validation"):
    baseline = {r["filename"]: r for r in all_rows["rgb"]["normal"]}
    summaries, paired = [], []
    for condition, interventions in all_rows.items():
        normal = {r["filename"]: r for r in interventions["normal"]}
        for name, rows in interventions.items():
            delta = [r["psnr"] - normal[r["filename"]]["psnr"] for r in rows]
            summary = {
                "condition": condition, "intervention": name, "n": len(rows),
                "psnr": float(np.mean([r["psnr"] for r in rows])),
                "ssim": float(np.mean([r["ssim"] for r in rows])),
                "delta_psnr_vs_intact": float(np.mean(delta)),
                "delta_ssim_vs_intact": float(np.mean([r["ssim"] - normal[r["filename"]]["ssim"] for r in rows])),
                "delta_psnr_vs_rgb": float(np.mean([r["psnr"] - baseline[r["filename"]]["psnr"] for r in rows])),
                "median_delta_psnr_vs_intact": float(np.median(delta)),
                "psnr_wins_vs_intact": sum(d > 0 for d in delta),
            }
            summaries.append(summary)
            for r in rows:
                paired.append({"condition": condition, "intervention": name, **r,
                               "delta_psnr_vs_intact": r["psnr"] - normal[r["filename"]]["psnr"],
                               "delta_ssim_vs_intact": r["ssim"] - normal[r["filename"]]["ssim"],
                               "delta_psnr_vs_rgb": r["psnr"] - baseline[r["filename"]]["psnr"]})
    write_csv(output / "summary.csv", summaries)
    write_csv(output / "paired_images.csv", paired)
    count = 80 if split == "validation" else 90
    lines = [f"# NAFNet saved-checkpoint latent-map ablation: UIEB {split}", "",
             f"Seed 0; {count} {split} images; float32 inference; fixed validation-selected checkpoints; no retraining.", "",
             "| Checkpoint | Intervention | PSNR | SSIM | ΔPSNR vs intact | ΔPSNR vs RGB |",
             "|---|---|---:|---:|---:|---:|"]
    for r in summaries:
        lines.append(f"| {r['condition']} | {r['intervention']} | {r['psnr']:.4f} | {r['ssim']:.5f} | {r['delta_psnr_vs_intact']:+.4f} | {r['delta_psnr_vs_rgb']:+.4f} |")
    lines += ["", "Removing maps uses the same jointly trained checkpoint. The zero-both condition is not the separately trained RGB baseline.", "",
              "Zeroing and donor swaps can be out of distribution; a drop measures dependence, not the benefit of including that component during training. Differences between the two checkpoints also include different learned weights and selected epochs.", "",
              "These results cannot establish SCA redundancy or physical meaning. One seed and validation-selected checkpoints limit generalization. A fresh factorial training experiment is needed for a causal architecture comparison."]
    if split == "test":
        lines += ["", "The UIEB historical sorted test90 partition was evaluated at the user's explicit request. All checkpoints, interventions and donor rules were fixed before test inference. Historical test exposure already existed in the inherited study; this is not a previously unseen benchmark. No tuning or checkpoint selection used these test results. Scores use 256-pixel resize/center-crop, not native-resolution evaluation."]
    (output / "FINDINGS.md").write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id")
    parser.add_argument("--split", choices=("validation", "test"), default="validation")
    args = parser.parse_args()
    if args.run_id is None:
        args.run_id = "map_components_v1" if args.split == "validation" else "map_components_uieb_test_v1"
    if Path(args.run_id).name != args.run_id or args.run_id in (".", ".."):
        parser.error("run-id must be a single directory name")
    output = ROOT / "outputs" / args.run_id
    output.parent.mkdir(exist_ok=True)
    output.mkdir()  # Refuse completed or partial run replacement.
    lock = (output / ".lock").open("w")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    started = time.perf_counter()
    try:
        frozen, manifest = verify_frozen()
        seed_original(0)
        split_sets = {key: set(value) for key, value in manifest["indices"].items()}
        if (split_sets["train"] & split_sets["validation"] or
                split_sets["train"] & split_sets["test"] or
                split_sets["validation"] & split_sets["test"] or
                split_sets["test"] != set(range(800, 890))):
            raise ValueError("Frozen splits overlap or historical test90 identity changed")
        parent_output = PARENT / "outputs/map_init_diagnostics_v1"
        checkpoints, provenance = {}, {}
        for condition in CONDITIONS:
            checkpoint = parent_output / "nafnet" / condition / "seed_0/best.pt"
            diagnostic = json.loads((checkpoint.parent / "diagnostics.json").read_text())
            identity = json.loads((checkpoint.parent / "run.json").read_text())
            checkpoint_hash = digest(checkpoint)
            if identity["frozen_identity"] != canonical(frozen) or checkpoint_hash != diagnostic["checkpoint_sha256"]:
                raise ValueError("Parent checkpoint identity/hash mismatch")
            for filename, expected in diagnostic["artifact_hashes"].items():
                if digest(checkpoint.parent / filename) != expected:
                    raise ValueError(f"Parent diagnostic artifact changed: {filename}")
            checkpoints[condition] = checkpoint
            provenance[condition] = {"checkpoint": str(checkpoint), "sha256": checkpoint_hash,
                                     "selected_epoch": diagnostic["checkpoint_epoch"]}
        protocol = {"run_id": args.run_id, "utc": utc(), "parent_frozen_identity": canonical(frozen),
                    "manifest_identity": canonical(manifest), "parent_environment": frozen["environment"],
                    "conditions": CONDITIONS, "interventions": INTERVENTIONS,
                    "seed": 0, "dataset": "UIEB", "split": args.split,
                    "images": len(manifest["indices"][args.split]), "precision": "float32",
                    "preprocessing": "Parent resize shorter edge 256, aligned center crop 256; RGB [0,1].",
                    "selection": "Existing best.pt selected by parent validation (PSNR, SSIM); unchanged.",
                    "script_sha256": digest(__file__), "checkpoints": provenance,
                    "hypothesis": "Separate spatial-map and global-map dependence in trained NAFNet.",
                    "donor_rule": f"Sorted {args.split} filenames rotated by one; same donor for both components.",
                    "test_policy": ("User explicitly requested UIEB test ablation; fixed checkpoints/interventions; no tuning or selection; inherited historical test exposure."
                                    if args.split == "test" else "No test prediction or selection; inherited historical test exposure."),
                    "git": "Study directories are not Git repositories; source hashes identify code."}
        atomic_json(output / "protocol.json", protocol)
        shutil.copyfile(__file__, output / "ablate.py")
        batches = evaluation_batches(args.split, manifest)
        validation_batches = evaluation_batches("validation", manifest) if args.split == "test" else None
        all_rows, metadata = {}, {}
        torch.cuda.reset_peak_memory_stats()
        for condition in CONDITIONS:
            all_rows[condition], metadata[condition] = evaluate(
                condition, batches, checkpoints[condition], output, args.split, validation_batches)
        summarize(all_rows, output, args.split)
        # Ensure all inputs remain identical after evaluation.
        for condition, checkpoint in checkpoints.items():
            if digest(checkpoint) != provenance[condition]["sha256"]:
                raise ValueError("Checkpoint changed during evaluation")
        atomic_json(output / "complete.json", {
            "utc": utc(), "elapsed_seconds": time.perf_counter() - started,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "metadata": metadata,
            "artifact_hashes": {p.name: digest(p) for p in output.iterdir()
                                if p.is_file() and p.name != ".lock"}})
        print(f"Complete: {output / 'FINDINGS.md'}", flush=True)
    except BaseException as error:
        atomic_json(output / "failure.json", {"utc": utc(), "error": repr(error)})
        raise


if __name__ == "__main__":
    main()
