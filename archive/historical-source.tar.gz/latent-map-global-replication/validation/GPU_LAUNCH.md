# GPU launch verification — 2026-10-22

The authorized finite queue was launched in tmux session
`global-dimension-replication-v1` using the unchanged existing environment.
Preparation succeeded, freezing the new source/config/environment/manifest and
five reusable reference identities. NVIDIA-SMI and PyTorch CUDA both passed on
the RTX 5060 Ti. GPU preflight recorded utilization 3%, 15,250 MiB free, and
only the existing GNOME remote desktop service in the permitted compute list.

GPU smoke completed for d6/seed1, d12/seed1, d6/seed2 and d12/seed2. Each case
made two actual optimizer updates, had finite gradients reaching all global
coordinates, reproduced full model/optimizer/scheduler/scaler/early-stopping/RNG
state exactly after checkpoint restoration, and saw matching input/augmentation
hashes across dimensions within seed. The smoke marker contains all four
distinct cases. This is functionality evidence, not a quality result.

The initial real run d6/seed1 completed epoch 1/30, saving full last.pt state,
history and CSV. It recorded 180 actual updates with zero AMP skips. Independent
post-launch checks verified all frozen new source hashes, all five reference
checkpoint/history/run/validation/completion identities, the four smoke cases
and training batch hashes/learning rates against the same-seed d=3 reference
for every epoch saved at that check.

The queue continues automatically through the four runs and their diagnostics,
updating `outputs/global_dimension_replication_v1/job_status.json` and
`reports/FINDINGS.md`. This record confirms successful startup; it does not
claim that all research runs are complete. Existing source/checkpoints/results
were preserved; no new test inference or later training stage was launched.
