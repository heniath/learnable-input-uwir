"""Scientific controls: grouping, pairing, adapter fidelity and interventions."""

# Imports follow path bootstrap so the project needs no editable install.
# ruff: noqa: E402
import json
import random
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import torch

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [
    str(ROOT / "src"),
    str(ROOT / "third_party/upstream/src"),
    str(ROOT / "third_party/nafnet"),
]

from uwir.models.learnable_physics import LearnableLatentUNet

from diagnostics.audit import grouped_split, take_groups
from diagnostics.diagnose import diagnose_run, intervene, metric_rows
from diagnostics.models import EnhancementModel
from diagnostics.protocol import PairedEpochDataset, canonical
from diagnostics.validation import check_initialization


class DiagnosticsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(4)

    def test_duplicate_groups_transitive_fixed_test(self):
        rows = [{"filename": str(i)} for i in range(890)]
        audit = {
            "exact_duplicates": [{"a": "1", "b": "2"}],
            "near_duplicate_candidates": [{"a": "2", "b": "3"}],
        }
        splits, groups = grouped_split(rows, audit, 0)
        self.assertEqual(splits, grouped_split(rows, audit, 0)[0])
        self.assertEqual(
            [len(splits[s]) for s in ("train", "validation", "test")], [720, 80, 90]
        )
        self.assertEqual(splits["test"], list(range(800, 890)))
        self.assertIn([1, 2, 3], groups)
        assignment = {i: name for name, indices in splits.items() for i in indices}
        self.assertEqual(len({assignment[i] for i in [1, 2, 3]}), 1)
        audit["exact_duplicates"].append({"a": "799", "b": "800"})
        with self.assertRaises(ValueError):
            grouped_split(rows, audit, 0)

    def test_subset_sum_cannot_break_group(self):
        with self.assertRaises(ValueError):
            take_groups([[0, 1]], 1)
        selected, remainder = take_groups([[0, 1], [2], [3, 4]], 3)
        self.assertEqual(sum(map(len, selected)), 3)
        self.assertEqual(sum(map(len, remainder)), 2)

    def test_paired_initialization_and_added_capacity(self):
        results = check_initialization()
        self.assertEqual(len(results), 2)
        for row in results.values():
            self.assertTrue(row["shared_parameters_equal"])
            self.assertTrue(row["bounded_unbounded_initial_state_equal"])
            self.assertLess(row["relative_mismatch"], 0.02)

    def test_original_forward_fidelity(self):
        x = torch.rand(1, 3, 256, 256)
        for backbone in ("unet", "nafnet"):
            model = EnhancementModel(backbone, "rgb").eval()
            with torch.inference_mode():
                torch.testing.assert_close(model(x), model.backbone(x), rtol=0, atol=0)
        model = EnhancementModel("unet", "bounded").eval()
        original = LearnableLatentUNet(enhancer=model.backbone).eval()
        original.transmission_extractor.load_state_dict(
            model.transmission_extractor.state_dict()
        )
        original.background_extractor.load_state_dict(
            model.background_extractor.state_dict()
        )
        with torch.inference_mode():
            torch.testing.assert_close(model(x), original(x), rtol=0, atol=0)

    def test_stateless_augmentation_preserves_rng_and_epoch(self):
        class FakeDataset:
            input_files = [f"{i}.png" for i in range(890)]

            def __getitem__(self, index):
                value = random.random()
                tensor = torch.full((3, 256, 256), value)
                return tensor, tensor.clone(), str(index), str(index)

        with (
            patch("diagnostics.protocol.base_dataset", return_value=FakeDataset()),
            patch("diagnostics.protocol.split_indices", return_value={"train": [0, 1]}),
        ):
            dataset = PairedEpochDataset("train", seed=0, epoch=1)
            before = random.getstate()
            first = dataset[0]
            torch.testing.assert_close(first[0], dataset[0][0], rtol=0, atol=0)
            torch.testing.assert_close(first[0], first[1], rtol=0, atol=0)
            self.assertEqual(before, random.getstate())
            other_epoch = PairedEpochDataset("train", seed=0, epoch=2)
            self.assertFalse(torch.equal(first[0], other_epoch[0][0]))
        with self.assertRaises(ValueError):
            PairedEpochDataset("test")

    def test_interventions_keep_shape_and_channel_histograms(self):
        spatial = torch.arange(96).reshape(2, 3, 4, 4).float()
        global_map = torch.ones_like(spatial)
        permuted, background = intervene(
            (spatial, global_map), "spatial_permutation", ["a", "b"]
        )
        torch.testing.assert_close(
            permuted.flatten(2).sort().values, spatial.flatten(2).sort().values
        )
        self.assertFalse(torch.equal(permuted, spatial))
        torch.testing.assert_close(background, global_map, rtol=0, atol=0)
        again = intervene((spatial, global_map), "spatial_permutation", ["a", "b"])[0]
        torch.testing.assert_close(permuted, again, rtol=0, atol=0)
        mean, _ = intervene((spatial, global_map), "spatial_mean", ["a", "b"])
        torch.testing.assert_close(
            mean, spatial.mean((-2, -1), keepdim=True).expand_as(spatial)
        )
        donors = {"a": (spatial[1], global_map[1]), "b": (spatial[0], global_map[0])}
        swapped = intervene(
            (spatial, global_map), "cross_image_swap", ["a", "b"], donors=donors
        )
        torch.testing.assert_close(swapped[0], spatial.flip(0))

    def test_diagnostic_artifacts_for_rgb_and_bounded(self):
        # Exercise actual CSV/marker/metric/intervention orchestration without
        # expensive real training. Real CUDA/model checks belong to GPU smoke.
        class SmallModel(torch.nn.Module):
            def __init__(self, backbone, condition, seed):
                super().__init__()
                self.condition = condition
                self.weight = torch.nn.Parameter(torch.tensor(1.0))

            def cuda(self):
                return self

            def forward(self, x, return_maps=False, maps_override=None):
                maps = (
                    (x.clamp(0.1, 1), torch.full_like(x, 0.2))
                    if self.condition == "bounded"
                    else None
                )
                used = maps_override if maps_override is not None else maps
                pred = x * 0.8 * self.weight
                if used is not None:
                    pred = pred + used[0].mean((-2, -1), keepdim=True) * 0.001
                return (pred, maps) if return_maps else pred

        generator = torch.Generator().manual_seed(42)
        x = torch.rand(80, 3, 16, 16, generator=generator)
        y = x * 0.75
        names = [f"image_{i:03d}.png" for i in range(80)]

        def batches(*args, **kwargs):
            return [
                (x[i : i + 4], y[i : i + 4], names[i : i + 4], names[i : i + 4])
                for i in range(0, 80, 4)
            ]

        frozen = {"test_fixture": True}
        with tempfile.TemporaryDirectory() as temporary:
            for condition in ("rgb", "bounded"):
                directory = Path(temporary) / condition
                directory.mkdir()
                identity = {
                    "frozen_identity": canonical(frozen),
                    "condition": condition,
                }
                (directory / "run.json").write_text(json.dumps(identity))
                initial = SmallModel("unet", condition, 0)
                with torch.inference_mode():
                    rows = metric_rows(initial(x), y, names)
                best = {
                    "epoch": 1,
                    **{
                        key: sum(row[key] for row in rows) / 80
                        for key in ("psnr", "ssim")
                    },
                }
                torch.save(
                    {"identity": identity, "model": initial.state_dict(), "best": best},
                    directory / "best.pt",
                )
                with (
                    patch("diagnostics.diagnose.run_dir", return_value=directory),
                    patch("diagnostics.diagnose.EnhancementModel", SmallModel),
                    patch("diagnostics.diagnose.loader", batches),
                    patch("diagnostics.diagnose.seed_original"),
                    patch("torch.Tensor.cuda", lambda tensor: tensor),
                    patch("torch.cuda.reset_peak_memory_stats"),
                    patch("torch.cuda.max_memory_allocated", return_value=0),
                    patch(
                        "diagnostics.diagnose.latency", return_value={"median_ms": 1.0}
                    ),
                    patch("diagnostics.diagnose.convolution_macs", return_value=1),
                ):
                    diagnose_run("unet", condition, 0, frozen)
                    marker = directory / "diagnostics.json"
                    before = marker.read_bytes()
                    diagnose_run("unet", condition, 0, frozen)
                    self.assertEqual(marker.read_bytes(), before)
                result = json.loads(before)
                self.assertEqual(result["count"], 80)
                self.assertEqual(
                    len(result["interventions"]), 4 if condition == "bounded" else 1
                )
                if condition == "bounded":
                    self.assertTrue(
                        all(a != b for a, b in result["swap_donors"].items())
                    )
                self.assertFalse((directory / "per_image_test.csv").exists())


if __name__ == "__main__":
    unittest.main()
