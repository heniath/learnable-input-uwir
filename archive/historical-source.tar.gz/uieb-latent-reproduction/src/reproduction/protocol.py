"""Freeze source, environment and data; preserve the notebook's RNG ordering."""

import hashlib
import json
import os
import platform
import random
import subprocess
from pathlib import Path

import numpy as np
import torch
import torchvision
from torch.utils.data import DataLoader, Subset
from torchvision.transforms import Compose, ToTensor
from uwir.data.datasets import UIEBDataset

ROOT = Path(__file__).resolve().parents[2]
UPSTREAM = ROOT / "third_party/upstream"
CONFIG = ROOT / "configs/protocol.json"


def config():
    return json.loads(CONFIG.read_text())


def output_root():
    return ROOT / "outputs" / config()["experiment_id"]


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    os.replace(temporary, path)


def freeze_json(path, value):
    path = Path(path)
    if path.exists():
        if json.loads(path.read_text()) != value:
            raise ValueError(f"Frozen identity changed: {path}; use a new experiment ID")
    else:
        atomic_json(path, value)


def git(*args):
    return subprocess.check_output(["git", "-C", str(UPSTREAM), *args], text=True).strip()


def source_hashes():
    paths = [CONFIG, ROOT / "constraints.txt"]
    for folder in [ROOT / "src", ROOT / "scripts", ROOT / "tests"]:
        paths.extend(folder.rglob("*.py"))
    paths.extend(UPSTREAM / p for p in git("ls-files").splitlines())
    return {str(p.relative_to(ROOT)): digest(p) for p in sorted(paths)}


def environment():
    import importlib.metadata as metadata

    packages = {d.metadata["Name"].lower(): d.version for d in metadata.distributions()}
    return {
        "python": platform.python_version(),
        "packages": dict(sorted(packages.items())),
        "torch": torch.__version__,
        "torchvision": torchvision.__version__,
        "cuda_runtime": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(),
        "cudnn": torch.backends.cudnn.version(),
    }


def seed_original():
    seed = config()["seed"]
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def split_indices():
    order = torch.randperm(800, generator=torch.Generator().manual_seed(config()["seed"])).tolist()
    return {
        "train": sorted(order[80:]),
        "validation": sorted(order[:80]),
        "test": list(range(800, 890)),
    }


def base_dataset(augment=False):
    c = config()
    ds = UIEBDataset(
        c["data_root"], transform=Compose([ToTensor()]), augment=augment, img_size=c["crop_size"]
    )
    if len(ds) != 890:
        raise ValueError(f"Expected 890 paired images, found {len(ds)}")
    return ds


def collate_rgb(batch):
    return torch.stack([item[0] for item in batch]), torch.stack([item[1] for item in batch])


def loader(split, *, limit=None, filenames=False):
    indices = split_indices()[split]
    if limit is not None:
        indices = indices[:limit]
    c = config()
    return DataLoader(
        Subset(base_dataset(split == "train"), indices),
        batch_size=c["batch_size"],
        shuffle=split == "train",
        num_workers=c["workers"],
        pin_memory=True,
        drop_last=split == "train",
        persistent_workers=False,
        collate_fn=None if filenames else collate_rgb,
    )


def configure_weights():
    hub = ROOT / "artifacts/torch-hub"
    checkpoint = hub / "checkpoints/vgg16-397923af.pth"
    weights = ROOT / "artifacts/weights/vgg16-397923af.pth"
    if not weights.exists():
        raise FileNotFoundError(f"Download VGG16 IMAGENET1K_V1 before prepare: {weights}")
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    if not checkpoint.exists():
        checkpoint.symlink_to(weights)
    if checkpoint.resolve() != weights.resolve():
        raise ValueError("Unexpected VGG cache identity")
    torch.hub.set_dir(str(hub))
    return weights


def verify_frozen(*, data=True):
    p = output_root() / "frozen_protocol.json"
    frozen = json.loads(p.read_text())
    if git("rev-parse", "HEAD") != config()["upstream_commit"] or git("diff", "HEAD"):
        raise ValueError("Pinned upstream code has changed")
    if frozen["source_hashes"] != source_hashes() or frozen["config"] != config():
        raise ValueError("Source/config changed after prepare; create a new experiment")
    if frozen["environment"] != environment():
        raise ValueError("Resolved environment changed after prepare")
    if digest(configure_weights()) != frozen["weights"]["sha256"]:
        raise ValueError("VGG weights changed")
    manifest = json.loads((output_root() / "manifest.json").read_text())
    if canonical(manifest) != frozen["manifest_sha256"]:
        raise ValueError("Frozen dataset manifest changed")
    if data:
        ds = base_dataset()
        if [Path(p).name for p in ds.input_files] != [r["filename"] for r in manifest["pairs"]]:
            raise ValueError("Upstream file ordering changed")
        for r in manifest["pairs"]:
            for role in ["input", "reference"]:
                path = Path(config()["data_root"]) / r[role]["path"]
                if digest(path) != r[role]["sha256"]:
                    raise ValueError(f"Dataset file changed: {path}")
    return frozen, manifest
