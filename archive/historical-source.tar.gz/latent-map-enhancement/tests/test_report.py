import csv

from latent_maps.report import summarize
from latent_maps.utils import atomic_json, load_config


def test_report_compares_matched_seeds_and_capacity(tmp_path):
    config = load_config()
    config["seeds"] = [0, 1]
    config["conditions"] = ["rgb", "learned_maps", "capacity"]
    config["stages"] = {"initial": ["synthetic_fixture"]}
    for seed in config["seeds"]:
        for condition, delta in (("rgb", 0), ("learned_maps", 2), ("capacity", 1)):
            directory = (
                tmp_path / "runs" / "synthetic_fixture" / condition / f"seed_{seed}"
            )
            directory.mkdir(parents=True)
            # Synthetic metric fixtures only; never benchmark artifacts.
            score = 20 + seed + delta
            atomic_json(
                directory / "test_results.json",
                {
                    "test": {"psnr": score, "ssim": 0.8, "inference_ms": 1},
                    "checkpoint_epoch": 1,
                },
            )
            (directory / "per_image_test.csv").write_text(
                f"id,psnr,ssim\nfixture,{score},0.8\n"
            )
    inventory = summarize(config, tmp_path)
    assert len(inventory) == 6 and all(r["status"] == "evaluated" for r in inventory)
    with (tmp_path / "reports/paired_seed_differences.csv").open() as f:
        differences = list(csv.DictReader(f))
    direct = [r for r in differences if r["reference_condition"] == "capacity"]
    assert len(direct) == 2
    assert all(float(r["psnr_delta"]) == 1 for r in direct)
    with (tmp_path / "reports/cross_seed_summary.csv").open() as f:
        summaries = list(csv.DictReader(f))
    assert all(r["complete"] == "True" for r in summaries)
