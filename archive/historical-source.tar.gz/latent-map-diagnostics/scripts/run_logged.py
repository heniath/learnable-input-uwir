#!/usr/bin/env python3
"""Run the frozen eight-run study sequentially, then diagnose and report."""

import fcntl
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "configs/protocol.json").read_text())
OUT = ROOT / "outputs" / CONFIG["experiment_id"]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / ".runner.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (OUT / "reports/report_complete.json").exists():
            print("Study complete; preserving all results", flush=True)
            return
        started = datetime.now(timezone.utc).isoformat()

        def status(value):
            temporary = OUT / "job_status.json.tmp"
            temporary.write_text(
                json.dumps(
                    {
                        "started_utc": started,
                        "utc": datetime.now(timezone.utc).isoformat(),
                        **value,
                    },
                    indent=2,
                )
                + "\n"
            )
            os.replace(temporary, OUT / "job_status.json")

        stages = [
            ["train", "--backbone", b, "--condition", c, "--model-seed", str(s)]
            for b in CONFIG["backbones"]
            for s in CONFIG["model_seeds"]
            for c in CONFIG["conditions"]
        ]
        stages += [["diagnose"], ["report"]]
        with (OUT / "training.log").open("a", buffering=1) as log:
            for args in stages:
                status({"status": "running", "stage": args, "runner_pid": os.getpid()})
                result = subprocess.run(
                    [sys.executable, "-u", str(ROOT / "scripts/experiment.py"), *args],
                    cwd=ROOT,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    check=False,
                )
                if result.returncode:
                    status(
                        {
                            "status": "failed",
                            "stage": args,
                            "returncode": result.returncode,
                        }
                    )
                    subprocess.run(
                        [sys.executable, str(ROOT / "scripts/experiment.py"), "report"],
                        cwd=ROOT,
                        stdout=log,
                        stderr=subprocess.STDOUT,
                        check=False,
                    )
                    raise SystemExit(result.returncode)
            status({"status": "complete"})


if __name__ == "__main__":
    main()
