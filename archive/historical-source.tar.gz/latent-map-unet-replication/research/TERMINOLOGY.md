# Terminology ledger

| Canonical term | Meaning / first-use definition | Boundary |
|---|---|---|
| underwater image restoration | Supervised mapping from degraded RGB to a paired reference | Enhancement is the broader literature task; reference is not necessarily physical ground truth |
| U-Net | The pinned diagnostic encoder-decoder | Published-method fidelity remains separately audited |
| NAFNet | Nonlinear Activation Free Network | RGB NAFNet is an external backbone reference, not this stage's training target |
| fixed priors | Offline single-channel transmission/backscatter proxies from the published paper | Algorithm 1, not the learned heads |
| learned latent maps | Image-conditioned spatial/global channels optimized through restoration loss | No validated transmission/background-light semantics |
| spatial branch | Three dense learned channels | Former code name: transmission extractor |
| global branch | Three image-level learned values broadcast spatially | Former code name: background-light extractor; not the paper's dense backscatter map |
| bounded / unbounded | Whether original head output transforms are applied | The same head states and input-weight initialization are retained within seed |
| capacity control | RGB plus the parent's added-parameter-matched residual feature branch | Parameters matched within 2%; compute and architecture are not matched |
| UIEB | Underwater Image Enhancement Benchmark | Diagnostic validation80 and historical T90 are different roles |
| EUVP | Enhancing Underwater Visual Perception dataset | Published results; no new EUVP runs in this stage |
| PSNR | Peak signal-to-noise ratio, dB | Unweighted mean of per-image diagnostic metrics |
| SSIM | Structural similarity index | Original pinned metric implementation |
| experiment / run / artifact | Hypothesis comparison / one execution / produced or used file | Seeds 1 and 2 are new; seed 0 retains historical identity |
