"""Real GPU smoke and interrupted-versus-uninterrupted epoch replay checks."""

import gc
import hashlib
import importlib.util
import json
from datetime import datetime, timezone

import numpy as np
import torch
from PIL import Image
from torchvision.transforms import functional as TF
from uwir.training.checkpoint import save_checkpoint

from .engine import epoch_step, make_components, payload, restore
from .models import EnhancementModel, convolution_macs, parameter_count
from .protocol import (
    ROOT,
    atomic_json,
    base_dataset,
    canonical,
    config,
    loader,
    output_root,
    seed_original,
    split_indices,
    verify_frozen,
)


class TracedLoader:
    def __init__(self, underlying):
        self.underlying = underlying
        self.hashes = []

    def __len__(self):
        return len(self.underlying)

    def __iter__(self):
        for x, y in self.underlying:
            h = hashlib.sha256(x.numpy().tobytes() + y.numpy().tobytes()).hexdigest()
            self.hashes.append(h)
            yield x, y


def compare_state(a, b, stats, prefix=""):
    if isinstance(a, torch.Tensor):
        a, b = a.detach().cpu(), b.detach().cpu()
        if not torch.equal(a, b):
            stats["bitwise_equal"] = False
            if a.is_floating_point():
                delta = float((a - b).abs().max()) if a.numel() else 0.0
                stats["max_absolute_tensor_difference"] = max(
                    stats["max_absolute_tensor_difference"], delta
                )
            torch.testing.assert_close(a, b, rtol=1e-5, atol=1e-7, msg=prefix)
    elif isinstance(a, np.ndarray):
        np.testing.assert_array_equal(a, b)
    elif isinstance(a, dict):
        assert a.keys() == b.keys(), prefix
        for k in a:
            compare_state(a[k], b[k], stats, prefix + "/" + str(k))
    elif isinstance(a, (tuple, list)):
        assert len(a) == len(b), prefix
        for i, (x, y) in enumerate(zip(a, b)):
            compare_state(x, y, stats, prefix + "/" + str(i))
    else:
        assert a == b, f"{prefix}: {a} != {b}"


def check_preprocessing():
    ds = base_dataset()
    seed_original()
    splits = split_indices()
    assert [len(splits[s]) for s in ["train", "validation", "test"]] == [720, 80, 90]
    assert set(splits["train"]).isdisjoint(splits["validation"])
    assert sorted(splits["train"] + splits["validation"]) == list(range(800))
    # Independent center-crop expectation from resize dimensions, on a real pair.
    for index in [0, 799]:
        x, y, _, _ = ds[index]
        assert tuple(x.shape) == tuple(y.shape) == (3, 256, 256)
        assert torch.isfinite(x).all() and 0 <= x.min() <= x.max() <= 1
        with Image.open(ds.input_files[index]) as im:
            resized = TF.resize(im.convert("RGB"), 256, antialias=True)
            w, h = resized.size
            assert min(w, h) == 256
            expected = TF.to_tensor(
                TF.crop(resized, (h - 256) // 2, (w - 256) // 2, 256, 256)
            )
        torch.testing.assert_close(x, expected, rtol=0, atol=0)
    return {
        "split_counts": [720, 80, 90],
        "center_crop_checks": 2,
        "output_shape": [3, 256, 256],
    }


def measure_tensor_drift(a, b, stats, prefix=""):
    """Measure continuation variation without implying bitwise GPU replay."""
    if isinstance(a, torch.Tensor):
        a, b = a.detach().cpu(), b.detach().cpu()
        if not torch.equal(a, b):
            stats["bitwise_equal"] = False
            assert a.is_floating_point(), f"Integer state changed: {prefix}"
            assert torch.isfinite(a).all() and torch.isfinite(b).all(), prefix
            delta = float((a - b).abs().max()) if a.numel() else 0.0
            if delta > stats["max_absolute_tensor_difference"]:
                stats["max_absolute_tensor_difference"] = delta
                stats["largest_difference_field"] = prefix
    elif isinstance(a, dict):
        assert a.keys() == b.keys(), prefix
        for k in a:
            measure_tensor_drift(a[k], b[k], stats, prefix + "/" + str(k))
    else:
        assert a == b, prefix


@torch.no_grad()
def bounds(model, condition):
    x, _ = next(iter(loader("validation", limit=4)))
    model.eval()
    pred, maps = model(x.cuda(), return_maps=True)
    assert tuple(pred.shape) == (4, 3, 256, 256)
    assert torch.isfinite(pred).all()
    if model.backbone_name == "unet":
        assert 0 <= pred.min() <= pred.max() <= 1
    values = {"output_range": [float(pred.min()), float(pred.max())]}
    if maps is not None:
        spatial, background = maps
        assert torch.isfinite(spatial).all() and torch.isfinite(background).all()
        if model.map_kind == "bounded":
            assert 0.1 <= spatial.min() <= spatial.max() <= 1.0
            assert 0 <= background.min() <= background.max() <= 1.0
        torch.testing.assert_close(
            background, background[:, :, :1, :1].expand_as(background), rtol=0, atol=0
        )
        values.update(
            spatial_range=[float(spatial.min()), float(spatial.max())],
            global_range=[float(background.min()), float(background.max())],
        )
    return values


def smoke_condition(backbone, condition, seed, directory):
    objects = make_components(backbone, condition, seed)
    torch.cuda.reset_peak_memory_stats()
    train_loader = TracedLoader(loader("train", seed=seed, epoch=1, limit=12))
    val_loader = loader("validation", limit=8)
    first = {"epoch": 1, **epoch_step(objects, train_loader, val_loader)}
    model, _, optimizer, _, _, _ = objects
    assert optimizer.state, "Smoke must perform actual optimizer updates"
    if model.map_kind in ("bounded", "unbounded"):
        for head in (model.transmission_extractor, model.background_extractor):
            assert any(
                p.grad is not None and p.grad.abs().max() > 0 for p in head.parameters()
            ), "Map head has no nonzero gradient"
    assert all(
        p.grad is not None and torch.isfinite(p.grad).all()
        for p in model.parameters()
        if p.requires_grad
    )
    boundary = directory / f"{condition}_boundary.pt"
    save_checkpoint(
        boundary,
        payload(
            objects,
            epoch=1,
            history=[first],
            best=first["validation"],
            identity={"smoke": True},
        ),
    )
    train_loader = TracedLoader(loader("train", seed=seed, epoch=2, limit=12))
    second = {"epoch": 2, **epoch_step(objects, train_loader, val_loader)}
    expected_hashes = train_loader.hashes.copy()
    expected_path = directory / f"{condition}_uninterrupted.pt"
    save_checkpoint(
        expected_path,
        payload(
            objects,
            epoch=2,
            history=[first, second],
            best=second["validation"],
            identity={"smoke": True},
        ),
    )
    peak_allocated, peak_reserved = (
        torch.cuda.max_memory_allocated(),
        torch.cuda.max_memory_reserved(),
    )
    del model, optimizer, objects, train_loader, val_loader
    gc.collect()
    torch.cuda.empty_cache()

    objects = make_components(backbone, condition, seed)
    state = torch.load(boundary, map_location="cpu", weights_only=False)
    restore(objects, state)
    loaded = payload(
        objects,
        epoch=1,
        history=state["history"],
        best=state["best"],
        identity=state["identity"],
    )
    restored_stats = {"bitwise_equal": True, "max_absolute_tensor_difference": 0.0}
    for key in [
        "model",
        "optimizer",
        "scheduler",
        "scaler",
        "early_stopping",
        "rng_state",
    ]:
        compare_state(state[key], loaded[key], restored_stats, key)
    assert restored_stats["bitwise_equal"], "Checkpoint restoration must be exact"
    del loaded
    del state
    replay_loader = TracedLoader(loader("train", seed=seed, epoch=2, limit=12))
    replay = {
        "epoch": 2,
        **epoch_step(objects, replay_loader, loader("validation", limit=8)),
    }
    assert expected_hashes == replay_loader.hashes, (
        "Epoch-boundary augmentation or sample order changed"
    )
    actual = payload(
        objects,
        epoch=2,
        history=[first, replay],
        best=replay["validation"],
        identity={"smoke": True},
    )
    save_checkpoint(directory / f"{condition}_resumed.pt", actual)
    expected = torch.load(expected_path, map_location="cpu", weights_only=False)
    stats = {"bitwise_equal": True, "max_absolute_tensor_difference": 0.0}
    for key in ["model", "optimizer"]:
        measure_tensor_drift(expected[key], actual[key], stats, key)
    continued_stats = {"bitwise_equal": True, "max_absolute_tensor_difference": 0.0}
    for key in ["scheduler", "scaler", "rng_state"]:
        compare_state(expected[key], actual[key], continued_stats, key)
    assert continued_stats["bitwise_equal"]
    for key in ["counter", "stop", "patience", "min_delta", "mode"]:
        assert expected["early_stopping"][key] == actual["early_stopping"][key]
    # A smoke agreement bound detects gross continuation failures. It does not
    # establish deterministic replay, which the original AMP protocol cannot
    # guarantee. Preserve measured drift and the failed v1 strict check.
    metric_delta = {
        key: replay["validation"][key] - second["validation"][key]
        for key in ["psnr", "ssim"]
    }
    assert abs(metric_delta["psnr"]) < 0.01 and abs(metric_delta["ssim"]) < 0.0001, (
        metric_delta
    )
    stats.update(
        exact_restoration=restored_stats,
        exact_continued_scheduler_scaler_rng=continued_stats,
        validation_metric_deltas=metric_delta,
        validation_agreement_bounds={"psnr_db": 0.01, "ssim": 0.0001},
    )
    if not stats["bitwise_equal"]:
        print(
            f"{condition}: exact state restoration passed; continuation is not bitwise identical: {stats}",
            flush=True,
        )
    result = {
        "passed": True,
        "convolution_macs": convolution_macs(objects[0].eval()),
        "batch_size": 4,
        "train_batches_per_smoke_epoch": 3,
        "resume_check": stats,
        "augmentation_batch_hashes": expected_hashes,
        "seconds_per_training_batch": second["train_seconds"] / 3,
        "estimated_full_epoch_seconds": second["train_seconds"] * 60
        + (second["epoch_seconds"] - second["train_seconds"]) * 10,
        "peak_allocated_bytes": peak_allocated,
        "peak_reserved_bytes": peak_reserved,
        "parameter_count": sum(p.numel() for p in objects[0].parameters()),
        "first_smoke_epoch": first,
        "second_smoke_epoch": second,
        "bounds": bounds(objects[0], condition),
    }
    del objects, expected, actual
    gc.collect()
    torch.cuda.empty_cache()
    return result


def historical_model_class():
    path = (ROOT / config()["parent_directory"] / "outputs/map_diagnostics_v1"
            / "source_snapshot/src/diagnostics/models.py").resolve()
    spec = importlib.util.spec_from_file_location("diagnostics._historical_models", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.EnhancementModel


@torch.no_grad()
def check_initialization(device="cpu", development=None):
    """Compare every state tensor and forward against the frozen implementation."""
    records = {}
    original_class = historical_model_class()
    x = torch.rand(1, 3, 256, 256, generator=torch.Generator().manual_seed(123)).to(device)
    examples = {"synthetic": x}
    if development is not None:
        examples["development"] = development.to(device)
    for seed in config()["model_seeds"]:
        models = {c: EnhancementModel("nafnet", c, seed).to(device).eval()
                  for c in config()["conditions"]}
        for condition in ("rgb", "bounded", "unbounded"):
            original = original_class("nafnet", condition, seed).to(device).eval()
            current = models[condition]
            for key, value in original.state_dict().items():
                torch.testing.assert_close(current.state_dict()[key], value, rtol=0, atol=0)
            for example in examples.values():
                torch.testing.assert_close(current(example), original(example), rtol=0, atol=0)
            del original
        record = {"historical_states_and_forwards_equal": True, "pairs": {}}
        rgb = models["rgb"]
        for kind in ("bounded", "unbounded"):
            random_model, zero_model = models[kind], models[kind + "_zero_init"]
            assert parameter_count(random_model) == parameter_count(zero_model)
            for model in (random_model, zero_model):
                for key, value in rgb.backbone.state_dict().items():
                    actual = model.backbone.state_dict()[key]
                    if key == "intro.weight":
                        actual = actual[:, :3]
                    torch.testing.assert_close(actual, value, rtol=0, atol=0)
            for key, value in random_model.state_dict().items():
                actual = zero_model.state_dict()[key]
                if key == "backbone.intro.weight":
                    assert torch.count_nonzero(actual[:, 3:]) == 0
                    assert torch.count_nonzero(value[:, 3:]) > 0
                    actual, value = actual[:, :3], value[:, :3]
                torch.testing.assert_close(actual, value, rtol=0, atol=0)
            drift = {}
            for label, example in examples.items():
                for a, b in zip(random_model.extract_maps(example), zero_model.extract_maps(example)):
                    torch.testing.assert_close(a, b, rtol=0, atol=0)
                actual, expected = zero_model(example), rgb(example)
                torch.testing.assert_close(actual, expected, rtol=1e-5, atol=1e-6)
                drift[label] = float((actual - expected).abs().max())
            record["pairs"][kind] = {
                "only_added_input_weights_differ": True,
                "initial_maps_equal": True,
                "parameters": parameter_count(zero_model),
                "zero_vs_rgb_max_absolute_difference": drift,
                "rtol": 1e-5, "atol": 1e-6,
            }
        for suffix in ("", "_zero_init"):
            a, b = models["bounded" + suffix], models["unbounded" + suffix]
            for key, value in a.state_dict().items():
                torch.testing.assert_close(b.state_dict()[key], value, rtol=0, atol=0)
        records[f"nafnet/seed_{seed}"] = record
        del models, rgb, random_model, zero_model, a, b
    return records


def check_zero_gradient_flow(device="cpu", batch=None):
    """At zero input weights, heads activate only after the input weights learn."""
    if batch is None:
        generator = torch.Generator().manual_seed(456)
        batch = (torch.rand(2, 3, 256, 256, generator=generator),
                 torch.rand(2, 3, 256, 256, generator=generator))
    x, target = (tensor.to(device) for tensor in batch)
    records = {}
    for kind in ("bounded", "unbounded"):
        model = EnhancementModel("nafnet", kind + "_zero_init", 0).to(device).train()
        optimizer = torch.optim.AdamW(model.parameters(), lr=config()["lr"],
                                      weight_decay=config()["weight_decay"])
        record = []
        for step in range(2):
            optimizer.zero_grad(set_to_none=True)
            torch.nn.functional.l1_loss(model(x), target).backward()
            assert all(p.grad is not None and torch.isfinite(p.grad).all()
                       for p in model.parameters())
            input_grad = float(model.backbone.intro.weight.grad[:, 3:].abs().max())
            assert input_grad > 0
            heads = [float(max(p.grad.abs().max() for p in head.parameters()))
                     for head in (model.transmission_extractor, model.background_extractor)]
            assert all(value == 0 if step == 0 else value > 0 for value in heads)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
            optimizer.step()
            assert torch.count_nonzero(model.backbone.intro.weight[:, 3:]) > 0
            record.append({"step": step + 1, "added_input_max_gradient": input_grad,
                           "head_max_gradients": heads})
        records[kind] = record
        del model, optimizer
    return records


def smoke():
    frozen, _ = verify_frozen()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
    directory = output_root() / "smoke" / stamp
    directory.mkdir(parents=True)
    report = {
        "passed": False,
        "frozen_identity": canonical(frozen),
        "preprocessing": check_preprocessing(),
        "conditions": {},
        "note": "Functionality and resource checks only; smoke scores are not experimental results.",
    }
    try:
        development = next(iter(loader("validation", limit=4)))[0]
        report["paired_initialization"] = check_initialization("cuda", development)
        report["zero_gradient_flow"] = check_zero_gradient_flow(
            "cuda", next(iter(loader("train", epoch=1, limit=4))))
        for backbone in config()["backbones"]:
            for seed in config()["model_seeds"]:
                for condition in config()["conditions"]:
                    key = f"{backbone}/{condition}/seed_{seed}"
                    print(f"Smoke and epoch-boundary replay: {key}", flush=True)
                    sub = directory / backbone / condition / f"seed_{seed}"
                    sub.mkdir(parents=True)
                    report["conditions"][key] = smoke_condition(
                        backbone, condition, seed, sub
                    )
                    atomic_json(directory / "validation.json", report)
        for seed in config()["model_seeds"]:
            hashes = [
                r["augmentation_batch_hashes"]
                for key, r in report["conditions"].items()
                if key.endswith(f"/seed_{seed}")
            ]
            assert all(value == hashes[0] for value in hashes), (
                "Conditions saw different augmented sample batches"
            )
        report["paired_augmented_batches_equal"] = True
        report["passed"] = True
        report["estimated_five_run_hours_max_100_epochs"] = sum(
            r["estimated_full_epoch_seconds"] * config()["epochs"] / 3600
            for r in report["conditions"].values()
        )
        atomic_json(directory / "validation.json", report)
        atomic_json(output_root() / "validation.json", report)
        print(
            json.dumps(
                {
                    "passed": True,
                    "estimated_hours": report[
                        "estimated_five_run_hours_max_100_epochs"
                    ],
                    "conditions": {
                        s: {
                            k: r[k]
                            for k in [
                                "resume_check",
                                "peak_allocated_bytes",
                                "seconds_per_training_batch",
                            ]
                        }
                        for s, r in report["conditions"].items()
                    },
                },
                indent=2,
            ),
            flush=True,
        )
    except Exception as exc:
        report["failure"] = {"type": type(exc).__name__, "message": str(exc)}
        atomic_json(directory / "validation.json", report)
        raise
