"""Upstream inner loops, paired epoch loaders, durable training state; no test inference."""

import json
import time
from datetime import datetime, timezone

import numpy as np
import torch
from uwir.cli.train import EarlyStopping, train_epoch, val_loss_epoch
from uwir.losses import CompositeLoss
from uwir.metrics import evaluate_loader
from uwir.training.checkpoint import save_checkpoint
from uwir.training.schedulers import CosineAnnealingRestartLR
from uwir.training.seed import capture_rng_state, restore_rng_state

from .models import EnhancementModel
from .protocol import (
    atomic_json,
    canonical,
    config,
    configure_weights,
    freeze_json,
    loader,
    output_root,
    seed_original,
    verify_frozen,
)


def utc():
    return datetime.now(timezone.utc).isoformat()


def run_dir(backbone, condition, seed=0):
    return output_root() / backbone / condition / f"seed_{seed}"


def make_components(backbone, condition, seed=0):
    c = config()
    configure_weights()
    seed_original(seed)
    model = EnhancementModel(backbone, condition, seed).to("cuda")
    weights = c["loss_weights"]
    enhancement = CompositeLoss(
        lambda_l1=weights["l1"],
        lambda_perc=weights["perceptual"],
        lambda_ssim=weights["ssim"],
        device="cuda",
    )
    criterion = enhancement
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=c["lr"], weight_decay=c["weight_decay"]
    )
    scheduler = CosineAnnealingRestartLR(
        optimizer, periods=[c["epochs"]], restart_weights=[1.0], eta_min=c["eta_min"]
    )
    scaler = torch.amp.GradScaler(
        "cuda", enabled=True, init_scale=c["amp_initial_scale"]
    )
    early = EarlyStopping(patience=c["patience"], min_delta=c["min_delta"], mode="max")
    return model, criterion, optimizer, scheduler, scaler, early


def epoch_step(objects, train_loader, val_loader):
    model, criterion, optimizer, scheduler, scaler, early = objects
    started = time.perf_counter()
    train_started = started
    train_loss, parts = train_epoch(
        model, train_loader, optimizer, criterion, torch.device("cuda"), scaler=scaler
    )
    torch.cuda.synchronize()
    train_seconds = time.perf_counter() - train_started
    val_loss = val_loss_epoch(
        model, val_loader, criterion, torch.device("cuda"), amp_enabled=True
    )
    metrics, count = evaluate_loader(model, val_loader, torch.device("cuda"))
    if not all(
        np.isfinite(value) for value in [train_loss, val_loss, *metrics.values()]
    ):
        raise FloatingPointError("Non-finite loss or validation metrics")
    scheduler.step()
    stopped = early(metrics["psnr"])
    return {
        "train_loss": train_loss,
        "parts": parts,
        "val_loss": val_loss,
        "validation": metrics,
        "validation_count": count,
        "lr": optimizer.param_groups[0]["lr"],
        "scaler": scaler.get_scale(),
        "early_stopped": stopped,
        "train_seconds": train_seconds,
        "epoch_seconds": time.perf_counter() - started,
    }


def payload(objects, *, epoch, history, best, identity, complete=False):
    model, _, optimizer, scheduler, scaler, early = objects
    return {
        "epoch": epoch,
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict(),
        "scaler": scaler.state_dict(),
        "early_stopping": vars(early).copy(),
        "rng_state": capture_rng_state(),
        "history": history,
        "best": best,
        "identity": identity,
        "complete": complete,
        "metrics": history[-1]["validation"],
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
    }


def restore(objects, state):
    model, _, optimizer, scheduler, scaler, early = objects
    model.load_state_dict(state["model"])
    optimizer.load_state_dict(state["optimizer"])
    scheduler.load_state_dict(state["scheduler"])
    scaler.load_state_dict(state["scaler"])
    early.__dict__.update(state["early_stopping"])
    restore_rng_state(state["rng_state"])


def finish_run(directory, state):
    atomic_json(directory / "history.json", state["history"])
    atomic_json(
        directory / "run_complete.json",
        {
            "epoch": state["epoch"],
            "reason": "early_stop"
            if state["early_stopping"]["stop"]
            else "epochs_complete",
            "best": state["best"],
            "training_seconds": sum(r["epoch_seconds"] for r in state["history"]),
            "peak_allocated_bytes": state["peak_allocated_bytes"],
            "peak_reserved_bytes": state["peak_reserved_bytes"],
            "completed_utc": utc(),
            "identity": state["identity"],
        },
    )


def train(backbone, condition, seed=0):
    frozen, _ = verify_frozen()
    validation_path = output_root() / "validation.json"
    validation = json.loads(validation_path.read_text())
    if not validation.get("passed") or validation["frozen_identity"] != canonical(
        frozen
    ):
        raise ValueError(
            "Run smoke successfully for this frozen source/protocol before training"
        )
    directory = run_dir(backbone, condition, seed)
    identity = {
        "condition": condition,
        "backbone": backbone,
        "seed": seed,
        "frozen_identity": canonical(frozen),
    }
    directory.mkdir(parents=True, exist_ok=True)
    freeze_json(directory / "run.json", identity)
    if (directory / "run_complete.json").exists():
        print(f"{condition}: complete; preserving run", flush=True)
        return
    objects = make_components(backbone, condition, seed)
    val_loader = loader("validation", seed=seed)
    history, best, start = [], None, 1
    peak_allocated = peak_reserved = 0
    last = directory / "last.pt"
    if last.exists():
        state = torch.load(last, map_location="cpu", weights_only=False)
        if state["identity"] != identity:
            raise ValueError("Checkpoint run identity mismatch")
        if state["complete"]:
            finish_run(directory, state)
            return
        restore(objects, state)
        history, best, start = state["history"], state["best"], state["epoch"] + 1
        peak_allocated, peak_reserved = (
            state["peak_allocated_bytes"],
            state["peak_reserved_bytes"],
        )
        del state
        print(f"{condition}: resumed after epoch {start - 1}", flush=True)
    torch.cuda.reset_peak_memory_stats()
    print(
        f"{backbone}/{condition}: seed {seed}; train=720 validation=80; batch=4 workers=2; start epoch={start}",
        flush=True,
    )
    try:
        for epoch in range(start, config()["epochs"] + 1):
            train_loader = loader("train", seed=seed, epoch=epoch)
            row = {"epoch": epoch, **epoch_step(objects, train_loader, val_loader)}
            history.append(row)
            score = (row["validation"]["psnr"], row["validation"]["ssim"])
            improved = best is None or score > (best["psnr"], best["ssim"])
            if improved:
                best = {
                    "epoch": epoch,
                    "psnr": score[0],
                    "ssim": score[1],
                    "val_loss": row["val_loss"],
                }
            complete = row["early_stopped"] or epoch == config()["epochs"]
            state = payload(
                objects,
                epoch=epoch,
                history=history,
                best=best,
                identity=identity,
                complete=complete,
            )
            state["peak_allocated_bytes"] = max(
                peak_allocated, state["peak_allocated_bytes"]
            )
            state["peak_reserved_bytes"] = max(
                peak_reserved, state["peak_reserved_bytes"]
            )
            if improved:
                save_checkpoint(directory / "best.pt", state)
            save_checkpoint(last, state)
            atomic_json(directory / "history.json", history)
            print(
                f"{backbone}/{condition}/seed_{seed} {epoch:03d}/100 train={row['train_loss']:.4f} val={row['val_loss']:.4f} "
                f"PSNR={score[0]:.3f} SSIM={score[1]:.4f} lr={row['lr']:.2e} "
                f"scale={row['scaler']:g} {row['epoch_seconds']:.1f}s"
                + (" BEST" if improved else ""),
                flush=True,
            )
            if complete:
                finish_run(directory, state)
                break
            del state
    except Exception as exc:
        atomic_json(
            directory
            / f"failure_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')}.json",
            {
                "utc": utc(),
                "type": type(exc).__name__,
                "message": str(exc),
                "last_saved_epoch": json.loads(
                    (directory / "history.json").read_text()
                )[-1]["epoch"]
                if (directory / "history.json").exists()
                else 0,
            },
        )
        raise
