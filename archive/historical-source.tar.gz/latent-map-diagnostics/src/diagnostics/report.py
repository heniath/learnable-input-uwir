"""Durable descriptive report and predeclared validation screening decision."""

import csv
import json

from .engine import run_dir
from .protocol import atomic_json, config, freeze_json, output_root


def screening(metrics):
    eligible, details = [], {}
    for condition in ("bounded", "unbounded"):
        checks = {}
        for backbone in config()["backbones"]:
            for baseline in ("rgb", "capacity"):
                gain = {
                    k: metrics[(backbone, condition)][k]
                    - metrics[(backbone, baseline)][k]
                    for k in ("psnr", "ssim")
                }
                passes_psnr = (
                    gain["psnr"] >= config()["screening"]["nafnet_gain_db"]
                    if backbone == "nafnet"
                    else gain["psnr"] > 0
                )
                checks[f"{backbone}_vs_{baseline}"] = {
                    **gain,
                    "passes": passes_psnr and gain["ssim"] >= 0,
                }
        if all(row["passes"] for row in checks.values()):
            eligible.append(condition)
        details[condition] = checks
    chosen = (
        max(
            eligible,
            key=lambda c: (
                metrics[("nafnet", c)]["psnr"],
                metrics[("nafnet", c)]["ssim"],
                c == "bounded",
            ),
        )
        if eligible
        else None
    )
    return {
        "eligible": eligible,
        "candidate": chosen,
        "checks": details,
        "interpretation": "Practical single-seed validation screening; not statistical significance or proof of novelty.",
    }


def paired_differences(directory, rows):
    result = []
    for backbone in config()["backbones"]:
        for seed in config()["model_seeds"]:
            per_image = {}
            for condition in config()["conditions"]:
                path = (
                    run_dir(backbone, condition, seed)
                    / "per_image_validation_normal.csv"
                )
                with path.open() as f:
                    per_image[condition] = {r["filename"]: r for r in csv.DictReader(f)}
            names = sorted(per_image["rgb"])
            assert len(names) == 80 and all(
                sorted(v) == names for v in per_image.values()
            )
            for condition, baseline in [
                ("bounded", "rgb"),
                ("bounded", "capacity"),
                ("unbounded", "rgb"),
                ("unbounded", "capacity"),
                ("bounded", "unbounded"),
            ]:
                for name in names:
                    a, b = per_image[condition][name], per_image[baseline][name]
                    result.append(
                        {
                            "backbone": backbone,
                            "seed": seed,
                            "condition": condition,
                            "baseline": baseline,
                            "filename": name,
                            "psnr_difference": float(a["psnr"]) - float(b["psnr"]),
                            "ssim_difference": float(a["ssim"]) - float(b["ssim"]),
                        }
                    )
    with (directory / "paired_validation_differences.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(result[0]))
        writer.writeheader()
        writer.writerows(result)


def report():
    out = output_root()
    directory = out / "reports"
    directory.mkdir(parents=True, exist_ok=True)
    if (directory / "report_complete.json").exists():
        print(f"Completed report preserved: {directory / 'FINDINGS.md'}", flush=True)
        return
    rows, metrics, interventions = [], {}, {}
    for backbone in config()["backbones"]:
        for seed in config()["model_seeds"]:
            for condition in config()["conditions"]:
                run = run_dir(backbone, condition, seed)
                complete = run / "run_complete.json"
                diagnostic = run / "diagnostics.json"
                row = {
                    "backbone": backbone,
                    "condition": condition,
                    "seed": seed,
                    "status": "pending",
                }
                if (run / "history.json").exists():
                    history = json.loads((run / "history.json").read_text())
                    row.update(status="running", epochs=history[-1]["epoch"])
                if complete.exists():
                    state = json.loads(complete.read_text())
                    row.update(
                        status="trained",
                        epochs=state["epoch"],
                        selected_epoch=state["best"]["epoch"],
                        val_psnr=state["best"]["psnr"],
                        val_ssim=state["best"]["ssim"],
                        epoch_hours=state["training_seconds"] / 3600,
                        peak_allocated_gib=state["peak_allocated_bytes"] / 2**30,
                    )
                if diagnostic.exists():
                    d = json.loads(diagnostic.read_text())
                    row.update(
                        status="diagnosed",
                        val_psnr=d["normal"]["psnr"],
                        val_ssim=d["normal"]["ssim"],
                        parameters=d["resources"]["parameters"],
                        conv_gmacs=d["resources"]["convolution_macs"] / 1e9,
                        inference_median_ms=d["resources"]["latency"]["median_ms"],
                    )
                    metrics[(backbone, condition)] = d["normal"]
                    if condition == "bounded":
                        interventions[backbone] = {
                            name: {
                                k: values[k] - d["normal"][k] for k in ("psnr", "ssim")
                            }
                            for name, values in d["interventions"].items()
                            if name != "normal"
                        }
                rows.append(row)
    finished = all(row["status"] == "diagnosed" for row in rows)
    decision = screening(metrics) if finished else None
    value = {
        "complete": finished,
        "runs": rows,
        "screening": decision,
        "bounded_intervention_deltas": interventions,
        "test_evaluated": False,
    }
    atomic_json(directory / "results.json", value)
    fields = [
        "backbone",
        "condition",
        "seed",
        "status",
        "epochs",
        "selected_epoch",
        "val_psnr",
        "val_ssim",
        "epoch_hours",
        "peak_allocated_gib",
        "parameters",
        "conv_gmacs",
        "inference_median_ms",
    ]
    with (directory / "results.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    text = [
        "# Local/global map diagnostic study",
        "",
        "Seed-0 validation-only study on a fixed duplicate-grouped 720/80/90 split. Historical test90 reserved; no test predictions were computed.",
        "",
        "| Backbone | Condition | Status | Epochs | Selected | Val PSNR | Val SSIM | Epoch hours | Peak alloc GiB | Parameters | Conv GMACs | Median ms |",
        "|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        values = [row["backbone"], row["condition"], row["status"]]
        for key in fields[4:]:
            val = row.get(key, "—")
            values.append(f"{val:.4f}" if isinstance(val, float) else str(val))
        text.append("| " + " | ".join(values) + " |")
    text += [
        "",
        "Epoch runtime includes training, validation losses and metrics, but excludes checkpoint writes and setup. Peak allocated VRAM is PyTorch allocation, not driver-wide memory. Conv MACs exclude pooling, activations, normalization and gates. Latency is batch-1 float32 GPU forward with 10 warmups/50 measurements at 256×256.",
        "",
    ]
    if finished:
        paired_differences(directory, rows)
        candidate = decision["candidate"]
        text += [
            f"Screening candidate: **{candidate or 'none'}**. Require >0 dB against RGB and capacity on U-Net, ≥0.2 dB against both on NAFNet, and nonnegative SSIM differences against both on both backbones. This is an engineering screen, not a significance test.",
            "",
        ]
        for condition, checks in decision["checks"].items():
            for name, check in checks.items():
                text.append(
                    f"- {condition}, {name}: ΔPSNR {check['psnr']:+.4f} dB, ΔSSIM {check['ssim']:+.5f}; screen {'passes' if check['passes'] else 'fails'}."
                )
        text += [
            "",
            "Bounded-map validation interventions (change relative to normal inference):",
            "",
        ]
        for backbone, tests in interventions.items():
            for name, delta in tests.items():
                text.append(
                    f"- {backbone}, {name}: ΔPSNR {delta['psnr']:+.4f} dB, ΔSSIM {delta['ssim']:+.5f}."
                )
        if candidate:
            recommendation = f"Next hypothesis: the {candidate} image-conditioned representation provides repeatable benefit beyond a parameter-matched feature branch on both backbones. Review this candidate for seeds 1/2 and an independently audited underwater benchmark; establish a distinct contribution against the novelty table before designing a new module."
        else:
            recommendation = "Next hypothesis: the reproduction gain depends on backbone, map output constraints, or optimization interactions. Inspect the bounded/unbounded contrasts, convergence histories and interventions before funding broader training or asserting a general conditioning method."
        text += ["", recommendation, ""]
    text += [
        "Limits: validation-selected scores are selection-biased; one seed cannot establish repeatability. Matching parameter counts does not match computation or rule out all architecture differences. Map interventions can be out of distribution and do not prove physical semantics. Detected duplicates are grouped, but scene independence is unverified. The historical UIEB test was previously inspected. This protocol changes split and initialization relative to reproduction, and changes heads/loss/preprocessing relative to the older NAFNet pilot; absolute scores should not be combined.",
        "",
        "The same U-Net-derived recipe is used within each backbone. A weak NAFNet result under this recipe does not establish the backbone's best attainable performance. Exact checkpoint restoration is required; mixed-precision CUDA continuation may diverge numerically. No additional seeds, datasets or new modules run automatically.",
        "",
        "See [novelty comparison](../../../research/NOVELTY.md) for primary-source method differences and unresolved novelty questions.",
    ]
    (directory / "FINDINGS.md").write_text("\n".join(text) + "\n")
    if finished:
        from .protocol import digest

        artifacts = {
            name: digest(directory / name)
            for name in (
                "FINDINGS.md",
                "results.json",
                "results.csv",
                "paired_validation_differences.csv",
            )
        }
        freeze_json(
            directory / "report_complete.json",
            {"complete": True, "artifact_hashes": artifacts},
        )
    print(directory / "FINDINGS.md", flush=True)
