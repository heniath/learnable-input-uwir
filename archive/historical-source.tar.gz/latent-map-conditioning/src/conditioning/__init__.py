"""Validation-only spatial/global conditioning experiments."""
