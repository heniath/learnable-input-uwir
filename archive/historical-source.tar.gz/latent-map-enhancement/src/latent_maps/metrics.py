"""RGB PSNR and Gaussian SSIM; average images rather than pooled pixel errors."""

import math

import torch
from torch.nn import functional as F


def rgb_metrics(prediction, reference):
    if (
        prediction.shape != reference.shape
        or prediction.ndim != 4
        or prediction.shape[:2] != (1, 3)
    ):
        raise ValueError("Metrics expect matching 1×3×H×W images")
    if min(prediction.shape[-2:]) < 11:
        raise ValueError("Gaussian SSIM needs images at least 11 pixels wide and high")
    if not torch.isfinite(prediction).all() or not torch.isfinite(reference).all():
        raise FloatingPointError("Nonfinite metric inputs")
    x, y = prediction.float().clamp(0, 1), reference.float()
    if y.min() < 0 or y.max() > 1:
        raise ValueError("Reference must be in [0,1]")
    mse = (x.double() - y.double()).square().mean().item()
    psnr = math.inf if mse == 0 else -10 * math.log10(mse)
    coords = torch.arange(11, device=x.device, dtype=x.dtype) - 5
    g = torch.exp(-coords.square() / (2 * 1.5**2))
    g /= g.sum()

    def blur(z):
        channels = z.shape[1]
        z = F.conv2d(z, g.view(1, 1, 1, 11).expand(channels, 1, 1, 11), groups=channels)
        return F.conv2d(
            z, g.view(1, 1, 11, 1).expand(channels, 1, 11, 1), groups=channels
        )

    moments = blur(torch.cat((x, y, x.square(), y.square(), x * y), 1))
    ux, uy, exx, eyy, exy = moments.chunk(5, dim=1)
    vx, vy, cov = exx - ux.square(), eyy - uy.square(), exy - ux * uy
    score = (
        (2 * ux * uy + 0.01**2)
        * (2 * cov + 0.03**2)
        / ((ux.square() + uy.square() + 0.01**2) * (vx + vy + 0.03**2))
    )
    return {"psnr": psnr, "ssim": score.mean().item()}
