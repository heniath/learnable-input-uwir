"""Durable inventories, cross-seed summaries, and paired per-image comparisons."""

import csv
import json
import statistics
from pathlib import Path

from .utils import atomic_json


def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def cross_dataset_audit(manifests, destination):
    overlaps = []
    names = sorted(manifests)
    for index, a in enumerate(names):
        for b in names[index + 1 :]:
            for role in ("input", "reference"):
                left, right = {}, {}
                for r in manifests[a]["pairs"]:
                    left.setdefault(r[role + "_identity"]["decoded_sha256"], []).append(
                        r["id"]
                    )
                for r in manifests[b]["pairs"]:
                    right.setdefault(
                        r[role + "_identity"]["decoded_sha256"], []
                    ).append(r["id"])
                matches = [
                    {"a": left[h], "b": right[h]}
                    for h in sorted(set(left) & set(right))
                ]
                overlaps.append(
                    {
                        "datasets": [a, b],
                        "role": role,
                        "unique_matching_images": len(matches),
                        "matches": matches,
                    }
                )
    audit = {
        "overlaps": overlaps,
        "interpretation": "Each dataset is trained separately. Cross-dataset overlap must not be counted as independent evidence or used in an unreviewed transfer experiment. Near-duplicate/scene independence across datasets is not established.",
    }
    atomic_json(destination, audit)
    return audit


def summarize(config, output_root):
    root = Path(output_root)
    report_dir = root / "reports"
    inventory, summaries, paired = [], [], []
    validation_results = {}
    datasets = [name for names in config["stages"].values() for name in names]
    all_results = {}
    for dataset in datasets:
        for condition in config["conditions"]:
            results = []
            for seed in config["seeds"]:
                directory = root / "runs" / dataset / condition / f"seed_{seed}"
                result_path = directory / "test_results.json"
                metadata_path = directory / "run.json"
                metadata = (
                    json.loads(metadata_path.read_text())
                    if metadata_path.exists()
                    else {}
                )
                row = {
                    "dataset": dataset,
                    "condition": condition,
                    "seed": seed,
                    "status": metadata.get("status", "pending"),
                    "epochs": 0,
                    "test_psnr": None,
                    "test_ssim": None,
                    "checkpoint_epoch": None,
                    "validation_psnr": None,
                    "validation_ssim": None,
                    "validation_checkpoint_epoch": None,
                }
                if (directory / "history.json").exists():
                    row["epochs"] = len(
                        json.loads((directory / "history.json").read_text())
                    )
                selected_path = directory / "validation_results.json"
                if selected_path.exists():
                    selected = json.loads(selected_path.read_text())
                    validation_results[dataset, condition, seed] = selected
                    row.update(
                        validation_psnr=selected["validation"]["psnr"],
                        validation_ssim=selected["validation"]["ssim"],
                        validation_checkpoint_epoch=selected["checkpoint_epoch"],
                    )
                if result_path.exists():
                    result = json.loads(result_path.read_text())
                    row.update(
                        status="evaluated",
                        test_psnr=result["test"]["psnr"],
                        test_ssim=result["test"]["ssim"],
                        checkpoint_epoch=result["checkpoint_epoch"],
                    )
                    results.append(result)
                    all_results[(dataset, condition, seed)] = result
                inventory.append(row)
            if results:
                summary = {
                    "dataset": dataset,
                    "condition": condition,
                    "evaluated_seeds": len(results),
                    "complete": len(results) == len(config["seeds"]),
                }
                for metric in ("psnr", "ssim", "inference_ms"):
                    values = [r["test"][metric] for r in results]
                    summary[metric + "_mean"] = statistics.mean(values)
                    summary[metric + "_sample_sd"] = (
                        statistics.stdev(values) if len(values) > 1 else None
                    )
                summaries.append(summary)
    for dataset in datasets:
        comparisons = [(c, "rgb") for c in config["conditions"] if c != "rgb"]
        if (
            "learned_maps" in config["conditions"]
            and "capacity" in config["conditions"]
        ):
            comparisons.append(("learned_maps", "capacity"))
        for condition, reference_condition in comparisons:
            for seed in config["seeds"]:
                key, base = (
                    (dataset, condition, seed),
                    (dataset, reference_condition, seed),
                )
                if key not in all_results or base not in all_results:
                    continue
                row = {
                    "dataset": dataset,
                    "condition": condition,
                    "reference_condition": reference_condition,
                    "seed": seed,
                }
                row.update(
                    {
                        metric + "_delta": all_results[key]["test"][metric]
                        - all_results[base]["test"][metric]
                        for metric in ("psnr", "ssim")
                    }
                )
                paired.append(row)

                def per_image(c, dataset=dataset, seed=seed):
                    path = (
                        root
                        / "runs"
                        / dataset
                        / c
                        / f"seed_{seed}"
                        / "per_image_test.csv"
                    )
                    with path.open() as f:
                        return {r["id"]: r for r in csv.DictReader(f)}

                baseline, variant = per_image(reference_condition), per_image(condition)
                if baseline.keys() != variant.keys():
                    raise ValueError(
                        "Paired comparisons have different image identities"
                    )
                differences = [
                    {
                        "id": name,
                        "psnr_delta": float(variant[name]["psnr"])
                        - float(baseline[name]["psnr"]),
                        "ssim_delta": float(variant[name]["ssim"])
                        - float(baseline[name]["ssim"]),
                    }
                    for name in baseline
                ]
                write_csv(
                    report_dir
                    / "paired_images"
                    / f"{dataset}_{condition}_vs_{reference_condition}_seed_{seed}.csv",
                    differences,
                )
    write_csv(report_dir / "run_inventory.csv", inventory)
    write_csv(report_dir / "cross_seed_summary.csv", summaries)
    write_csv(report_dir / "paired_seed_differences.csv", paired)
    val_summaries, val_paired = [], []
    for dataset in datasets:
        for condition in config["conditions"]:
            available = [
                s
                for s in config["seeds"]
                if (dataset, condition, s) in validation_results
            ]
            if not available:
                continue
            entry = {
                "dataset": dataset,
                "condition": condition,
                "seeds": str(available),
                "n_seeds": len(available),
                "complete_seeds": len(available) == len(config["seeds"]),
            }
            for metric in ("psnr", "ssim"):
                values = [
                    validation_results[dataset, condition, s]["validation"][metric]
                    for s in available
                ]
                entry[metric + "_mean"] = statistics.mean(values)
                entry[metric + "_sample_sd"] = (
                    statistics.stdev(values) if len(values) > 1 else None
                )
            val_summaries.append(entry)
        comparisons = [(c, "rgb") for c in config["conditions"] if c != "rgb"]
        comparisons.append(("learned_maps", "capacity"))
        for condition, baseline in comparisons:
            for seed in config["seeds"]:
                key, base = (dataset, condition, seed), (dataset, baseline, seed)
                if key not in validation_results or base not in validation_results:
                    continue
                val_paired.append(
                    {
                        "dataset": dataset,
                        "condition": condition,
                        "baseline": baseline,
                        "seed": seed,
                        **{
                            m + "_delta": validation_results[key]["validation"][m]
                            - validation_results[base]["validation"][m]
                            for m in ("psnr", "ssim")
                        },
                    }
                )
    write_csv(report_dir / "validation_summary.csv", val_summaries)
    write_csv(report_dir / "paired_validation_seed_differences.csv", val_paired)
    all_trained = all(
        (
            root / "runs" / dataset / condition / f"seed_{seed}" / "train_complete.json"
        ).exists()
        for dataset in datasets
        for condition in config["conditions"]
        for seed in config["seeds"]
    )
    screen_checks = []
    if all_trained:
        for dataset in datasets:
            for seed in config["seeds"]:
                for baseline in ("rgb", "capacity"):
                    target, base = (
                        (dataset, "learned_maps", seed),
                        (dataset, baseline, seed),
                    )
                    if (
                        target not in validation_results
                        or base not in validation_results
                    ):
                        raise ValueError(
                            "Completed training is missing selected validation metrics"
                        )
                    delta = {
                        m: validation_results[target]["validation"][m]
                        - validation_results[base]["validation"][m]
                        for m in ("psnr", "ssim")
                    }
                    screen_checks.append(
                        {
                            "dataset": dataset,
                            "seed": seed,
                            "baseline": baseline,
                            **delta,
                            "passes": delta["psnr"] > 0 and delta["ssim"] >= 0,
                        }
                    )
    screen = {
        "all_training_complete": all_trained,
        "checks": screen_checks,
        "passes_all_datasets_and_seeds": all(x["passes"] for x in screen_checks)
        if all_trained
        else None,
        "interpretation": "Validation-selected descriptive screen; partial training gives no decision. Not significance or generalization evidence.",
    }
    atomic_json(report_dir / "screening.json", screen)
    lines = [
        "# Fresh auxiliary-map U-Net experiment: LOL-v2 real and LSUI",
        "",
        "Hypothesis: input-conditioned auxiliary maps improve restoration beyond comparable extra capacity.",
        "",
        f"Evaluated runs: {sum(r['status'] == 'evaluated' for r in inventory)}/{len(inventory)}.",
        "",
        "Smoke tests establish functionality only. Test results are reported per dataset; three seeds do not establish statistical significance.",
        "",
        "## Completed comparisons",
        "",
        "| Dataset | Condition | Seeds | RGB PSNR mean ± sample SD | SSIM mean ± sample SD |",
        "|---|---|---:|---:|---:|",
    ]
    for row in summaries:
        psnr_sd = (
            "—" if row["psnr_sample_sd"] is None else f"{row['psnr_sample_sd']:.3f}"
        )
        ssim_sd = (
            "—" if row["ssim_sample_sd"] is None else f"{row['ssim_sample_sd']:.4f}"
        )
        lines.append(
            f"| {row['dataset']} | {row['condition']} | {row['evaluated_seeds']} | {row['psnr_mean']:.3f} ± {psnr_sd} | {row['ssim_mean']:.4f} ± {ssim_sd} |"
        )
    if not summaries:
        lines.extend(["", "No held-out results yet."])
    lines.extend(
        [
            "",
            "## Validation-selected scores (including partial training)",
            "",
            "Available-seed summaries are provisional until all configured runs finish. These are selection-biased validation scores, separate from test results.",
            "",
            "| Dataset | Condition | Seeds | PSNR mean | PSNR sample SD | SSIM mean | SSIM sample SD |",
            "|---|---|---|---:|---:|---:|---:|",
        ]
    )
    for row in val_summaries:
        psnr_sd = (
            "—" if row["psnr_sample_sd"] is None else f"{row['psnr_sample_sd']:.4f}"
        )
        ssim_sd = (
            "—" if row["ssim_sample_sd"] is None else f"{row['ssim_sample_sd']:.6f}"
        )
        lines.append(
            f"| {row['dataset']} | {row['condition']} | {row['seeds']} | {row['psnr_mean']:.4f} | {psnr_sd} | {row['ssim_mean']:.6f} | {ssim_sd} |"
        )
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "Assess the learned-map model against both RGB and the capacity control using the paired seed differences. Preserve negative and inconsistent findings. Custom, group-aware splits and native-resolution evaluation prevent direct comparison with the historical notebook's T90 scores.",
            "",
            "Exact and conservative near-duplicate groups are held together. Automated image similarity does not establish subject/scene independence; inspect the manifests and overlap audit before making broader claims.",
            "",
        ]
    )
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "FINDINGS.md").write_text("\n".join(lines))
    return inventory
