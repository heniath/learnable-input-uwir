# Completed follow-up audit — 2026-10-22

The queue completed at 2026-10-21 22:21:48 Asia/Phnom_Penh (15:21:48 UTC).
All requested initial cells are present: 12 H1 cells across seeds 0/1/2,
four dimension cells at seed 0 and nine completed diagnostics. There are no
missing entries. The four historical H1 seed-0 checkpoints and d=3 reference
were reused; eight H1 replication and three dimension runs were new.

## Independent read-only checks performed

- Follow-up source hashes, frozen identity, manifest identity and every final
  report hash match the saved completion record.
- Both H1 source snapshots match current parent sources. All 15 distinct
  selected checkpoints and their original validation CSV hashes match completed
  run records; run identities and 30-epoch endpoints match the intended studies.
- H1 validation CSVs cover the exact same 80 filenames and reproduce selected
  PSNR/SSIM means within 1e-10. Selected epochs agree with the earliest maximum
  validation (PSNR, SSIM) tuple in histories.
- All H1 histories contain epochs 1–30 and 180 batches/80 validation images per
  epoch. Batch/augmentation hashes and learning rates match across conditions
  within each seed. Actual updates reconcile with AMP skip counts: all H1 cells
  record 5,400 optimizer updates and zero skips.
- All new dimension histories match their d=3 reference's 30 epochs of batch
  hashes and learning rates; checkpoint/CSV hashes, validation filename coverage
  and PSNR summaries match. The final dimension table records 5,400 updates and
  zero AMP skips for every dimension.
- Recomputed H1 paired image differences, seed means and sample SDs agree with
  saved reports within 1e-10. Images and training seeds were not pooled as
  independent replicates.
- Every diagnostic artifact hash matches. Recomputed means and population SDs
  from all 720 training G vectors agree within 1e-12. All 80 validation vectors
  use the expected filenames and are disjoint from training.
- Recomputed normal-versus-training-mean validation differences agree within
  1e-10. All nine saved normal validation reproductions have exactly zero
  per-image PSNR/SSIM drift. No new GPU inference or training was needed for
  this audit; environment and raw dataset files were not rehashed in this audit.

## H1 replication evidence

| Condition | Validation PSNR mean +/- sample SD | SSIM mean +/- sample SD | Paired PSNR gain vs RGB mean +/- sample SD |
|---|---:|---:|---:|
| RGB | 20.10224 +/- 0.11227 | 0.874379 +/- 0.004156 | — |
| Spatial only | 20.04897 +/- 0.05512 | 0.874032 +/- 0.003530 | -0.05327 +/- 0.12540 |
| Global only | 21.98802 +/- 0.09799 | 0.906993 +/- 0.002782 | +1.88578 +/- 0.12124 |
| Spatial + global | 21.92903 +/- 0.12476 | 0.904413 +/- 0.003376 | +1.82679 +/- 0.21558 |

Global-only gains over RGB are +1.90506, +1.75606 and +1.99623 dB for seeds
0/1/2; SSIM also improves in every seed. Joint maps also improve over RGB in
all seeds. Adding spatial to global yields +0.05132, -0.17813 and -0.05018 dB,
with paired mean -0.05900 +/- 0.11498 dB. Thus this input-concatenation pilot
supports a repeatable global-branch gain, without a consistent incremental
spatial benefit. This does not establish that all spatial mechanisms are
unhelpful or that models have converged beyond the 30-epoch budget.

## Global-vector diagnostic evidence

All six H1 global/joint checkpoints have numerical rank 3, no numerically
constant or descriptive near-constant coordinates, and training-coordinate
SDs approximately 0.108–0.149. Effective rank ranges from 2.62 to 2.84.

| Condition | Validation PSNR change under training-mean G, mean +/- sample SD | Range across seeds |
|---|---:|---:|
| Global only | -4.33841 +/- 0.07031 dB | -4.41945 to -4.29366 |
| Spatial + global | -4.21455 +/- 0.43509 dB | -4.69431 to -3.84551 |

These checkpoints contain image-dependent G vectors and are sensitive to the
specified mean-replacement intervention. This is not proof of physical map
semantics; distribution shift under intervention and dependence on the chosen
network remain relevant to interpretation.

## Dimension screen and research decision

| d | Seed-0 validation PSNR | SSIM | Delta PSNR vs d=3 | Effective rank of training G |
|---:|---:|---:|---:|---:|
| 1 | 20.77943 | 0.891454 | -1.11872 | 1.000 |
| 3 | 21.89814 | 0.903820 | 0 | 2.762 |
| 6 | 22.11815 | 0.908156 | +0.22000 | 3.903 |
| 12 | 22.07535 | 0.907285 | +0.17721 | 3.813 |

d=6 has the highest observed validation score in the prespecified seed-0
screen; d=12 trails it by only 0.04279 dB. Neither ranking nor the gains have
been replicated across seeds. Parameters/input widths vary as documented, so
this is not a parameter-matched comparison.

A focused next experiment would repeat d=6 at seeds 1/2 against the already
available d=3 global-only checkpoints for those seeds, keeping the same pilot
protocol and paired validation contrasts. It would not require a broader
dimension sweep. This audit did not launch that next experiment.

Keep the current spatial branch and its historical artifacts available. The
present input-concatenation design has no consistent additional spatial gain;
use global-only as the primary reference for further global studies, while
deferring a permanent spatial removal or redesign decision. The dimension
screen alone cannot settle that separate architectural question.

All reported scores here are validation-selected, under the same 30-epoch
pilot protocol, on the inherited UIEB split. Prior test exposure and unresolved
scene independence remain limitations. No new test inference or test-based
tuning was performed.
