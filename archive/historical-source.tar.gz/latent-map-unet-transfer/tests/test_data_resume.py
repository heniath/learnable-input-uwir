import copy

import numpy as np
import pytest
import torch
from PIL import Image

from latent_maps.data import (
    PairedImages,
    assign_splits,
    load_manifest,
    prepare_manifest,
)
from latent_maps.engine import evaluate_run, train
from latent_maps.utils import canonical_hash, load_config


def tiny_manifest(root):
    rows = []
    rng = np.random.default_rng(123)
    for i in range(6):
        a = rng.integers(0, 256, (32, 32, 3), dtype=np.uint8)
        b = np.minimum(a.astype(np.int16) + 20, 255).astype(np.uint8)
        for role, data in (("input", a), ("reference", b)):
            Image.fromarray(data).save(root / f"{role}_{i}.png")
        rows.append(
            {
                "id": f"{i}",
                "input": f"input_{i}.png",
                "reference": f"reference_{i}.png",
                "width": 32,
                "height": 32,
                "split": "train" if i < 4 else "validation" if i == 4 else "test",
            }
        )
    return {"dataset": "tiny", "pairs": rows, "content_sha256": canonical_hash(rows)}


def test_duplicate_groups_keep_partition_boundaries():
    rows = [{"partition": "development"} for _ in range(8)]
    groups = [[0, 1], [2], [3], [4], [5], [6], [7]]
    assigned = assign_splits(rows, groups, [4, 2, 2], seed=0)
    assert assigned[0]["split"] == assigned[1]["split"]
    assert [
        sum(r["split"] == s for r in assigned) for s in ("train", "validation", "test")
    ] == [4, 2, 2]
    rows[0]["partition"] = "test"
    with pytest.raises(ValueError, match="official"):
        assign_splits(rows, groups, [4, 2, 2], seed=0)


def test_paired_crops_are_deterministic_and_aligned(tmp_path):
    manifest = tiny_manifest(tmp_path)
    # Use identical targets to verify crop/flip alignment, including smaller-than-crop padding.
    for row in manifest["pairs"]:
        row["reference"] = row["input"]
    dataset = PairedImages(manifest, tmp_path, "train", seed=8, crop_size=40)
    first = dataset[0]
    again = dataset[0]
    assert torch.equal(first[0], first[1]) and torch.equal(first[0], again[0])
    dataset.epoch = 1
    assert not torch.equal(first[0], dataset[0][0])


def test_manifest_rejects_unpaired_and_changed_data(tmp_path):
    left, right = tmp_path / "UIEB/raw-890", tmp_path / "UIEB/reference-890"
    left.mkdir(parents=True)
    right.mkdir(parents=True)
    rng = np.random.default_rng(0)
    for i in range(4):
        image = Image.fromarray(rng.integers(0, 256, (16, 16, 3), dtype=np.uint8))
        image.save(left / f"{i}.png")
        image.save(right / f"{i}.png")
    path = tmp_path / "manifest.json"
    prepare_manifest(tmp_path, "uieb", [2, 1, 1], 0, path)
    load_manifest(path, tmp_path)
    Image.new("RGB", (16, 16), "red").save(left / "0.png")
    with pytest.raises(ValueError, match="changed"):
        load_manifest(path, tmp_path)
    with pytest.raises(ValueError, match="differs"):
        prepare_manifest(tmp_path, "uieb", [2, 1, 1], 0, path)
    Image.new("RGB", (16, 16)).save(left / "extra.png")
    with pytest.raises(ValueError, match="Unpaired"):
        prepare_manifest(tmp_path, "uieb", [2, 1, 1], 0, tmp_path / "new.json")


def test_epoch_boundary_resume_reproduces_training_and_evaluation(tmp_path):
    data = tmp_path / "data"
    data.mkdir()
    manifest = tiny_manifest(data)
    config = load_config()
    config["data_root"] = str(data)
    config["model"].update(
        width=4,
    )
    config["training"].update(
        epochs=2, batch_size=2, crop_size=16, workers=0, cpu_threads=2
    )
    full, resumed = tmp_path / "full", tmp_path / "resumed"
    device = torch.device("cpu")
    train(config, manifest, "learned_maps", 0, full, device)
    train(config, manifest, "learned_maps", 0, resumed, device, stop_after_epoch=1)
    train(config, manifest, "learned_maps", 0, resumed, device)
    a = torch.load(full / "last.pt", weights_only=False)
    b = torch.load(resumed / "last.pt", weights_only=False)
    for name in a["model"]:
        assert torch.equal(a["model"][name], b["model"][name]), name
    assert a["scheduler"] == b["scheduler"]
    assert [r["train_l1"] for r in a["history"]] == [
        r["train_l1"] for r in b["history"]
    ]
    assert [r["validation"]["psnr"] for r in a["history"]] == [
        r["validation"]["psnr"] for r in b["history"]
    ]
    before = (full / "last.pt").stat().st_mtime_ns
    train(config, manifest, "learned_maps", 0, full, device)
    assert (full / "last.pt").stat().st_mtime_ns == before
    result = evaluate_run(config, manifest, full, device)
    assert result["test"]["images"] == 1
    assert evaluate_run(config, manifest, full, device) == result
    changed = copy.deepcopy(config)
    changed["training"]["learning_rate"] *= 2
    with pytest.raises(ValueError, match="identity changed"):
        train(changed, manifest, "learned_maps", 0, full, device)
