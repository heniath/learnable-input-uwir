import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
GLOBAL = ROOT.parent / "latent-map-global-study"
TRAINING = ROOT.parent / "latent-map-conditioning"
PARENT = ROOT.parent / "latent-map-diagnostics"
sys.path[:0] = [str(ROOT / "src"), str(GLOBAL / "src"), str(TRAINING / "src"),
                str(PARENT / "src"), str(PARENT / "third_party/upstream/src"), str(PARENT / "third_party/nafnet")]
