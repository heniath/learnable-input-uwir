#!/usr/bin/env python3
"""Run the four authorized pairs sequentially with persistent status and logs."""

import csv
import fcntl
import json
import subprocess
import sys
import time
from datetime import datetime, timezone

import bootstrap
from replication.protocol import config, output_root
from diagnostics.protocol import atomic_json

OUT = output_root()


def utc():
    return datetime.now(timezone.utc).isoformat()


def status(state, **details):
    atomic_json(OUT / "job_status.json", {"status": state, "utc": utc(), **details})


def command(label, *args):
    status("running", stage=label, command=list(args))
    print(f"{utc()} Starting {label}", flush=True)
    argv = [sys.executable, "-B", str(bootstrap.ROOT / "scripts/run.py"), *args]
    with (OUT / "logs" / f"{label}.log").open("a") as log:
        log.write(f"\n{utc()} {json.dumps(argv)}\n")
        log.flush()
        subprocess.run(argv, cwd=bootstrap.ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)


def wait_for_gpu():
    while True:
        processes = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader"], text=True)
        resources = subprocess.check_output(["nvidia-smi", "--query-gpu=utilization.gpu,memory.free", "--format=csv,noheader,nounits"], text=True)
        utilization, free_mib = (int(v.strip()) for v in resources.strip().split(","))
        active, permitted = [], []
        for row in csv.reader(processes.splitlines()):
            if not row:
                continue
            name = row[1].strip()
            desktop = name == "/usr/libexec/gnome-remote-desktop-daemon"
            launcher = (name.replace("\\", "/").lower() == "s:/steamapps/common/warframe/tools/launcher.exe"
                        and float(row[2].split()[0]) <= 32 and utilization <= 10 and free_mib >= 4096)
            (permitted if desktop or launcher else active).append(row)
        if not active:
            with (OUT / "logs/preflight.log").open("a") as log:
                log.write(f"{utc()} GPU available; utilization={utilization}, free_mib={free_mib}, permitted={permitted}\n")
            return
        status("waiting_for_gpu", stage="waiting_for_gpu", active_processes=active, polling_seconds=30)
        print(f"{utc()} Waiting for GPU: {active}", flush=True)
        time.sleep(30)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "logs").mkdir(exist_ok=True)
    with (bootstrap.ROOT / ".runner.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            with (OUT / "logs/preflight.log").open("a") as log:
                subprocess.run(["nvidia-smi"], stdout=log, stderr=subprocess.STDOUT, check=True)
                subprocess.run([sys.executable, "-B", "-c", "import torch; print(torch.__version__, torch.version.cuda, flush=True); assert torch.cuda.is_available(); print(torch.cuda.get_device_name(0), flush=True)"],
                               stdout=log, stderr=subprocess.STDOUT, check=True)
            command("prepare", "prepare")
            wait_for_gpu()
            command("smoke", "smoke")
            command("report", "report")
            for dimension, seed in config()["new_runs"]:
                wait_for_gpu()
                command(f"train_d{dimension}_seed{seed}", "train", "--dimension", str(dimension), "--seed", str(seed))
                command("report", "report")
                wait_for_gpu()
                command(f"diagnostic_d{dimension}_seed{seed}", "diagnose", "--dimension", str(dimension), "--seed", str(seed))
                command("report", "report")
            if not (OUT / "complete.json").exists():
                raise RuntimeError("Finite queue ended without a complete report")
            status("complete", report=str(OUT / "reports/FINDINGS.md"), new_runs=4)
        except BaseException as error:
            status("failed", error=repr(error))
            raise


if __name__ == "__main__":
    main()
