# Local/global map diagnostics

Eight validation-only seed-0 runs test RGB, original bounded local/global maps,
identical unbounded heads, and an added-parameter-matched residual capacity branch
on the original U-Net and width-32 NAFNet. This is a distinct protocol from both
the historical reproduction and the previous NAFNet pilot. Existing artifacts
and local data are preserved.

## Execution

Use the unchanged Conda environment `uieb-latent-repro`; no new dependencies.
From this directory, with that environment's Python:

```bash
python scripts/experiment.py prepare
python -m unittest discover -s tests -v
python scripts/experiment.py smoke
python scripts/experiment.py train --backbone unet --condition rgb --model-seed 0
python scripts/experiment.py diagnose
python scripts/experiment.py report
```

`scripts/run_logged.py` runs all eight conditions sequentially, skips completed
training and diagnostics, then writes the final report. Start it in tmux session
`latent-map-diagnostics`. Re-running the runner resumes incomplete training from
the last saved epoch. Configuration/source/environment/data/weights must match
their frozen hashes. Source edits require a new experiment ID and new smoke.

The resolved configuration is `configs/protocol.json`; paths can be changed
before freezing. Run IDs include backbone, condition and model seed; the fixed
split seed is independent. Only seed 0 is enabled for this stage.

## Controls and data

Within each backbone/seed, shared RGB backbone parameters are identical at
initialization. Bounded/unbounded head states and extra input weights are also
identical. Their sole architectural difference is map output bounding.
Transmission-shaped and background-shaped heads are the original separate
width-32 BatchNorm modules; bounds do not establish physical semantics.

The capacity branch is inserted after U-Net's first encoder block or NAFNet's
input convolution. Its integer bottleneck width minimizes added-parameter
mismatch, required below 2%; the final convolution uses Normal(0,0.001) weights
and zero bias. It is an architecture control, not a full compute match.

Data is read in place. Historical filename indices 800:890 are reserved;
detected duplicate groups among the first 800 are shuffled with Python
Random(split_seed), then exact subset-sum allocation selects 80 validation and
720 training images. Both input and reference exact/near matches are grouped.
Any detected group crossing the reserved boundary stops preparation. Detection
does not guarantee independent scenes. Previous reproduction test results were
already inspected; this phase has no test loader or test prediction command.

Paired crop/flip transforms call the unchanged upstream dataset implementation
under a per-filename/seed/epoch local RNG. Loader shuffling has an independent
epoch generator. All conditions therefore see matching samples/augmentations.
Shared training settings and metric definitions follow the original U-Net
recipe, including its upstream full validation metric suite. NAFNet preserves
its RGB residual output and has no added sigmoid. This study does not optimize
each backbone's recipe independently.

## Artifacts and interpretation

`outputs/map_diagnostics_v1/` contains frozen source/data/environment identities,
source snapshots, smoke checks, persistent logs/status, and best/last full-state
checkpoints under `<backbone>/<condition>/seed_0/`. Validation diagnostics retain
80-image metrics, map statistics, intervention metrics and CUDA-event latency.
The final report includes paired image differences and the predeclared screen.
Smoke results are functionality checks, not performance evidence.

The screen requires >0 dB over RGB and capacity on U-Net, ≥0.2 dB over both on
NAFNet, and nonnegative SSIM gains on both. It is not statistical significance.
No seed expansion, extra datasets, new losses or new architectures run
automatically. Full-text comparisons are recorded in `research/NOVELTY.md`.

AMP/CUDA continuation may differ numerically despite exact checkpoint
restoration. Smoke requires exact restored model/optimizer/scheduler/scaler/RNG,
identical replayed batch hashes and continued scheduler/scaler/RNG, finite state,
and validation drift below 0.01 dB / 0.0001 SSIM. Limits and measured drift are
reported. The existing environment's unrelated mambavision dependency conflicts
and upstream Kornia AMP deprecation warnings remain preserved.

Upstream U-Net source is a pristine local clone at
`d9d28626cf32308fd6d57fd0c2f9ab39623cea60` with its license. NAFNet source at
`2b4af71ebe098a92a75910c233a3965a3e93ede4`, original files, licenses, source hashes
and standalone extraction provenance are retained under `third_party/nafnet`.
VGG16 ImageNet V1 weights are linked to the existing verified local artifact.
