"""Seed-aware repeatability screening and provenance-preserving summaries."""

import csv
import json
import math
import statistics

from .engine import run_dir
from .historical import parent_root, verify_reference
from .protocol import atomic_json, canonical, config, digest, freeze_json, output_root

COMPARISONS = (
    ("bounded", "rgb"),
    ("bounded", "capacity"),
    ("unbounded", "rgb"),
    ("unbounded", "capacity"),
    ("bounded", "unbounded"),
)


def screening(metrics):
    """Use every new seed; historical seed 0 cannot rescue a failed seed."""
    checks, eligible = {}, []
    for condition in ("bounded", "unbounded"):
        records = []
        for backbone in config()["backbones"]:
            for seed in config()["model_seeds"]:
                for baseline in ("rgb", "capacity"):
                    gain = {
                        key: metrics[backbone, condition, seed][key]
                        - metrics[backbone, baseline, seed][key]
                        for key in ("psnr", "ssim")
                    }
                    if not all(math.isfinite(x) for x in gain.values()):
                        raise ValueError("Non-finite screening metric")
                    records.append(
                        {
                            "backbone": backbone,
                            "seed": seed,
                            "baseline": baseline,
                            **gain,
                            "passes": gain["psnr"] > 0 and gain["ssim"] >= 0,
                        }
                    )
        checks[condition] = records
        if all(record["passes"] for record in records):
            eligible.append(condition)
    if "bounded" in eligible:
        decision = "advance_bounded_hypothesis"
    elif "unbounded" in eligible:
        decision = "investigate_bounds_next"
    else:
        decision = "investigate_seed_variation_before_additions"
    return {
        "eligible": eligible,
        "primary_condition": "bounded",
        "decision": decision,
        "checks": checks,
        "interpretation": "Positive PSNR and nonnegative SSIM against both controls in each new seed; descriptive screen, not a significance test.",
    }


def write_csv(path, rows, fields):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_run(
    directory, backbone, condition, seed, origin, expected_identity, expected_names
):
    row = {
        "backbone": backbone,
        "condition": condition,
        "seed": seed,
        "origin": origin,
        "directory": str(directory),
        "status": "pending",
    }
    history = []
    if (directory / "run.json").exists():
        if json.loads((directory / "run.json").read_text()) != expected_identity:
            raise ValueError(f"Run identity mismatch: {directory}")
    if (directory / "history.json").exists():
        history = json.loads((directory / "history.json").read_text())
        if not history or [item["epoch"] for item in history] != list(
            range(1, len(history) + 1)
        ):
            raise ValueError(f"Invalid epoch order: {directory}")
        for item in history:
            values = [
                item["train_loss"],
                item["val_loss"],
                *item["validation"].values(),
            ]
            if not all(math.isfinite(value) for value in values):
                raise ValueError(f"Non-finite history: {directory}")
            if item["validation_count"] != len(expected_names):
                raise ValueError(f"Wrong validation count: {directory}")
        row.update(status="running", epochs=history[-1]["epoch"])
    complete = directory / "run_complete.json"
    diagnostic = directory / "diagnostics.json"
    state = None
    if complete.exists():
        state = json.loads(complete.read_text())
        if state["identity"] != expected_identity or state["epoch"] != len(history):
            raise ValueError(f"Completion identity/epoch mismatch: {directory}")
        best = max(
            history,
            key=lambda item: (item["validation"]["psnr"], item["validation"]["ssim"]),
        )
        for key in ("psnr", "ssim"):
            if abs(state["best"][key] - best["validation"][key]) > 1e-9:
                raise ValueError(f"Selected score mismatch: {directory}")
        if state["best"]["epoch"] != best["epoch"]:
            raise ValueError(f"Selected epoch mismatch: {directory}")
        row.update(
            status="trained",
            selected_epoch=state["best"]["epoch"],
            val_psnr=state["best"]["psnr"],
            val_ssim=state["best"]["ssim"],
            epoch_hours=state["training_seconds"] / 3600,
            peak_allocated_gib=state["peak_allocated_bytes"] / 2**30,
        )
    if not diagnostic.exists():
        if origin == "historical":
            raise ValueError(f"Historical diagnostics missing: {directory}")
        return row, history, None, None
    if state is None:
        raise ValueError(f"Diagnostics without completed training: {directory}")
    d = json.loads(diagnostic.read_text())
    if (
        d["identity"] != expected_identity
        or d["checkpoint_epoch"] != row["selected_epoch"]
    ):
        raise ValueError(f"Diagnostic identity/epoch mismatch: {directory}")
    if d["count"] != len(expected_names) or d["split"] != "validation":
        raise ValueError(f"Diagnostic split/count mismatch: {directory}")
    if digest(directory / "best.pt") != d["checkpoint_sha256"]:
        raise ValueError(f"Selected checkpoint changed: {directory}")
    expected_interventions = (
        set(config()["interventions"]) if condition == "bounded" else {"normal"}
    )
    if set(d["interventions"]) != expected_interventions:
        raise ValueError(f"Missing intervention coverage: {directory}")
    for name, expected in d["artifact_hashes"].items():
        if digest(directory / name) != expected:
            raise ValueError(f"Diagnostic artifact changed: {directory}/{name}")
    required = {f"per_image_validation_{name}.csv" for name in expected_interventions}
    if condition in ("bounded", "unbounded"):
        required.add("map_statistics.json")
    if not required.issubset(d["artifact_hashes"]):
        raise ValueError(f"Unhashed diagnostic artifacts: {directory}")
    images = None
    for intervention in expected_interventions:
        with (directory / f"per_image_validation_{intervention}.csv").open() as stream:
            values = list(csv.DictReader(stream))
        if (
            len(values) != len(expected_names)
            or sorted(item["filename"] for item in values) != expected_names
        ):
            raise ValueError(f"Validation filenames differ: {directory}/{intervention}")
        records = {
            item["filename"]: {key: float(item[key]) for key in ("psnr", "ssim")}
            for item in values
        }
        for key in ("psnr", "ssim"):
            if not all(math.isfinite(item[key]) for item in records.values()):
                raise ValueError(f"Non-finite per-image metric: {directory}")
            if (
                abs(
                    statistics.mean(item[key] for item in records.values())
                    - d["interventions"][intervention][key]
                )
                > 1e-8
            ):
                raise ValueError(f"Per-image mean mismatch: {directory}/{intervention}")
        if intervention == "normal":
            images = records
    for key, tolerance in (("psnr", 0.001), ("ssim", 0.00001)):
        if (
            abs(d["normal"][key] - row[f"val_{key}"]) > tolerance
            or d["normal"][key] != d["interventions"]["normal"][key]
        ):
            raise ValueError(f"Selected diagnostic score mismatch: {directory}")
    row.update(
        status="diagnosed",
        val_psnr=d["normal"]["psnr"],
        val_ssim=d["normal"]["ssim"],
        checkpoint_sha256=d["checkpoint_sha256"],
        parameters=d["resources"]["parameters"],
        conv_gmacs=d["resources"]["convolution_macs"] / 1e9,
        inference_median_ms=d["resources"]["latency"]["median_ms"],
    )
    return row, history, images, d


def summarize(rows, paired):
    """Keep new-only and historical-inclusive estimates visibly separate."""
    aggregates, differences = [], []
    for scope in ("new_seeds_1_2", "historical_0_plus_new_1_2"):
        selected = [
            row
            for row in rows
            if row["status"] == "diagnosed"
            and (scope != "new_seeds_1_2" or row["origin"] == "new")
        ]
        for condition in config()["conditions"]:
            items = [row for row in selected if row["condition"] == condition]
            if not items:
                continue
            entry = {
                "scope": scope,
                "condition": condition,
                "n_seeds": len(items),
                "seeds": [row["seed"] for row in items],
            }
            for key in ("psnr", "ssim"):
                values = [row[f"val_{key}"] for row in items]
                entry[f"{key}_mean"] = statistics.mean(values)
                entry[f"{key}_sample_sd"] = (
                    statistics.stdev(values) if len(values) > 1 else None
                )
            aggregates.append(entry)
        metrics = {(row["condition"], row["seed"]): row for row in selected}
        for condition, baseline in COMPARISONS:
            seeds = sorted(
                {
                    row["seed"]
                    for row in selected
                    if (condition, row["seed"]) in metrics
                    and (baseline, row["seed"]) in metrics
                }
            )
            if not seeds:
                continue
            entry = {
                "scope": scope,
                "condition": condition,
                "baseline": baseline,
                "n_seeds": len(seeds),
                "seeds": seeds,
            }
            for key in ("psnr", "ssim"):
                values = [
                    metrics[condition, seed][f"val_{key}"]
                    - metrics[baseline, seed][f"val_{key}"]
                    for seed in seeds
                ]
                entry[f"{key}_difference_mean"] = statistics.mean(values)
                entry[f"{key}_difference_sample_sd"] = (
                    statistics.stdev(values) if len(values) > 1 else None
                )
            differences.append(entry)
    per_image = []
    for seed in sorted({row["seed"] for row in paired}):
        for condition, baseline in COMPARISONS:
            items = [
                row
                for row in paired
                if row["seed"] == seed
                and row["condition"] == condition
                and row["baseline"] == baseline
            ]
            if not items:
                continue
            ordered = sorted(items, key=lambda row: row["psnr_difference"])
            values = [row["psnr_difference"] for row in ordered]
            trim = len(values) // 10
            per_image.append(
                {
                    "seed": seed,
                    "origin": items[0]["origin"],
                    "condition": condition,
                    "baseline": baseline,
                    "count": len(values),
                    "psnr_mean": statistics.mean(values),
                    "psnr_median": statistics.median(values),
                    "psnr_trimmed_mean": statistics.mean(
                        values[trim : len(values) - trim] if trim else values
                    ),
                    "psnr_wins": sum(value > 0 for value in values),
                    "worst_five": ordered[:5],
                    "best_five": ordered[-5:][::-1],
                }
            )
    return aggregates, differences, per_image


def curve_records(rows, histories):
    convergence, horizons = [], []
    for row in rows:
        history = histories[row["backbone"], row["condition"], row["seed"]]
        best = None
        for item in history:
            if best is None or (
                item["validation"]["psnr"],
                item["validation"]["ssim"],
            ) > (best["validation"]["psnr"], best["validation"]["ssim"]):
                best = item
            convergence.append(
                {
                    "backbone": row["backbone"],
                    "condition": row["condition"],
                    "seed": row["seed"],
                    "origin": row["origin"],
                    "epoch": item["epoch"],
                    "train_loss": item["train_loss"],
                    "val_loss": item["val_loss"],
                    "psnr": item["validation"]["psnr"],
                    "ssim": item["validation"]["ssim"],
                    "lr": item["lr"],
                    "scaler": item["scaler"],
                    "best_psnr_so_far": best["validation"]["psnr"],
                    "selected_epoch_so_far": best["epoch"],
                }
            )
    for seed in sorted({row["seed"] for row in rows}):
        group = [row for row in rows if row["seed"] == seed]
        if len(group) != len(config()["conditions"]):
            continue
        horizon = min(
            len(histories[row["backbone"], row["condition"], seed]) for row in group
        )
        for epoch in range(1, horizon + 1):
            for row in group:
                best = max(
                    histories[row["backbone"], row["condition"], seed][:epoch],
                    key=lambda item: (
                        item["validation"]["psnr"],
                        item["validation"]["ssim"],
                    ),
                )
                horizons.append(
                    {
                        "seed": seed,
                        "origin": row["origin"],
                        "condition": row["condition"],
                        "horizon_epoch": epoch,
                        "best_psnr": best["validation"]["psnr"],
                        "best_ssim": best["validation"]["ssim"],
                        "selected_epoch_so_far": best["epoch"],
                    }
                )
    return convergence, horizons


def report():
    out = output_root()
    reference = verify_reference()
    directory = out / "reports"
    directory.mkdir(parents=True, exist_ok=True)
    marker = directory / "report_complete.json"
    if marker.exists():
        for name, expected in json.loads(marker.read_text())["artifact_hashes"].items():
            if digest(directory / name) != expected:
                raise ValueError(f"Completed report artifact changed: {name}")
        print(f"Completed report preserved: {directory / 'FINDINGS.md'}", flush=True)
        return
    frozen = json.loads((out / "frozen_protocol.json").read_text())
    if frozen["config"] != config():
        raise ValueError("Reporting configuration differs from frozen protocol")
    manifest = json.loads((out / "manifest.json").read_text())
    if canonical(manifest) != frozen["manifest_sha256"]:
        raise ValueError("Reporting manifest changed")
    names = sorted(
        manifest["pairs"][index]["filename"]
        for index in manifest["indices"]["validation"]
    )
    if len(names) != 80:
        raise ValueError("Expected 80 validation images")
    sources = []
    for record in reference["runs"]:
        identity = {
            key: record[key]
            for key in ("backbone", "condition", "seed", "frozen_identity")
        }
        sources.append(
            (
                parent_root() / record["directory"],
                record["backbone"],
                record["condition"],
                record["seed"],
                "historical",
                identity,
            )
        )
    for backbone in config()["backbones"]:
        for seed in config()["model_seeds"]:
            for condition in config()["conditions"]:
                identity = {
                    "backbone": backbone,
                    "condition": condition,
                    "seed": seed,
                    "frozen_identity": canonical(frozen),
                }
                sources.append(
                    (
                        run_dir(backbone, condition, seed),
                        backbone,
                        condition,
                        seed,
                        "new",
                        identity,
                    )
                )
    rows, histories, images, metrics, interventions = [], {}, {}, {}, []
    for source in sources:
        row, history, image, diagnostic = read_run(*source, names)
        key = row["backbone"], row["condition"], row["seed"]
        if key in histories:
            raise ValueError(f"Duplicate run key: {key}")
        rows.append(row)
        histories[key] = history
        if diagnostic is not None:
            images[key] = image
            metrics[key] = diagnostic["normal"]
            for name, value in diagnostic["interventions"].items():
                if name != "normal":
                    interventions.append(
                        {
                            "backbone": row["backbone"],
                            "condition": row["condition"],
                            "seed": row["seed"],
                            "origin": row["origin"],
                            "intervention": name,
                            **{
                                f"{metric}_difference": value[metric]
                                - diagnostic["normal"][metric]
                                for metric in ("psnr", "ssim")
                            },
                        }
                    )
    paired = []
    for seed in (0, *config()["model_seeds"]):
        for condition, baseline in COMPARISONS:
            left, right = ("unet", condition, seed), ("unet", baseline, seed)
            if left not in images or right not in images:
                continue
            for name in names:
                paired.append(
                    {
                        "backbone": "unet",
                        "seed": seed,
                        "origin": "historical" if seed == 0 else "new",
                        "condition": condition,
                        "baseline": baseline,
                        "filename": name,
                        **{
                            f"{key}_difference": images[left][name][key]
                            - images[right][name][key]
                            for key in ("psnr", "ssim")
                        },
                    }
                )
    new_rows = [row for row in rows if row["origin"] == "new"]
    expected_count = (
        len(config()["model_seeds"])
        * len(config()["conditions"])
        * len(config()["backbones"])
    )
    finished = len(new_rows) == expected_count and all(
        row["status"] == "diagnosed" for row in new_rows
    )
    decision = screening(metrics) if finished else None
    aggregate, differences, per_image = summarize(rows, paired)
    convergence, horizons = curve_records(rows, histories)
    value = {
        "complete": finished,
        "expected_new_runs": expected_count,
        "completed_new_training_runs": sum(
            row["status"] in ("trained", "diagnosed") for row in new_rows
        ),
        "diagnosed_new_runs": sum(row["status"] == "diagnosed" for row in new_rows),
        "runs": rows,
        "screening": decision,
        "aggregates": aggregate,
        "paired_seed_summaries": differences,
        "per_image_summaries": per_image,
        "bounded_intervention_deltas": interventions,
        "test_evaluated": False,
        "historical_reference_sha256": frozen["historical_reference_sha256"],
    }
    atomic_json(directory / "results.json", value)
    fields = [
        "backbone",
        "condition",
        "seed",
        "origin",
        "status",
        "epochs",
        "selected_epoch",
        "val_psnr",
        "val_ssim",
        "epoch_hours",
        "peak_allocated_gib",
        "parameters",
        "conv_gmacs",
        "inference_median_ms",
        "checkpoint_sha256",
        "directory",
    ]
    write_csv(directory / "results.csv", rows, fields)
    write_csv(
        directory / "paired_validation_differences.csv",
        paired,
        [
            "backbone",
            "seed",
            "origin",
            "condition",
            "baseline",
            "filename",
            "psnr_difference",
            "ssim_difference",
        ],
    )
    write_csv(
        directory / "convergence.csv",
        convergence,
        [
            "backbone",
            "condition",
            "seed",
            "origin",
            "epoch",
            "train_loss",
            "val_loss",
            "psnr",
            "ssim",
            "lr",
            "scaler",
            "best_psnr_so_far",
            "selected_epoch_so_far",
        ],
    )
    write_csv(
        directory / "common_horizon_scores.csv",
        horizons,
        [
            "seed",
            "origin",
            "condition",
            "horizon_epoch",
            "best_psnr",
            "best_ssim",
            "selected_epoch_so_far",
        ],
    )
    write_csv(
        directory / "seed_summary.csv",
        aggregate,
        [
            "scope",
            "condition",
            "n_seeds",
            "seeds",
            "psnr_mean",
            "psnr_sample_sd",
            "ssim_mean",
            "ssim_sample_sd",
        ],
    )
    write_csv(
        directory / "paired_seed_summary.csv",
        differences,
        [
            "scope",
            "condition",
            "baseline",
            "n_seeds",
            "seeds",
            "psnr_difference_mean",
            "psnr_difference_sample_sd",
            "ssim_difference_mean",
            "ssim_difference_sample_sd",
        ],
    )
    lines = [
        "# U-Net learned-map repeatability study",
        "",
        f"New training completed: {value['completed_new_training_runs']}/{expected_count}; new diagnostics completed: {value['diagnosed_new_runs']}/{expected_count}.",
        "",
        "Seeds 1 and 2 are new runs. Seed 0 is read-only historical evidence from map_diagnostics_v1, with original identity and verified hashes. All scores are validation-selected on the same fixed 80 images. No test predictions are available.",
        "",
        "| Condition | Seed | Origin | Status | Selected / total epochs | PSNR | SSIM |",
        "|---|---:|---|---|---|---:|---:|",
    ]
    for row in rows:
        psnr = f"{row['val_psnr']:.5f}" if "val_psnr" in row else "—"
        ssim = f"{row['val_ssim']:.6f}" if "val_ssim" in row else "—"
        lines.append(
            f"| {row['condition']} | {row['seed']} | {row['origin']} | {row['status']} | {row.get('selected_epoch', '—')} / {row.get('epochs', '—')} | {psnr} | {ssim} |"
        )
    lines += [
        "",
        "## Seed summaries",
        "",
        "Available diagnosed seeds only; n_seeds and seeds identify partial summaries. Sample SD measures seed variability, not uncertainty over independent scenes.",
        "",
        "| Scope | Condition | Seeds | PSNR mean ± sample SD | SSIM mean ± sample SD |",
        "|---|---|---|---:|---:|",
    ]
    for item in aggregate:
        sd_p = (
            f"{item['psnr_sample_sd']:.5f}"
            if item["psnr_sample_sd"] is not None
            else "undefined (one seed)"
        )
        sd_s = (
            f"{item['ssim_sample_sd']:.6f}"
            if item["ssim_sample_sd"] is not None
            else "undefined (one seed)"
        )
        lines.append(
            f"| {item['scope']} | {item['condition']} | {item['seeds']} | {item['psnr_mean']:.5f} ± {sd_p} | {item['ssim_mean']:.6f} ± {sd_s} |"
        )
    lines += ["", "## Predeclared decision", ""]
    if decision is None:
        lines.append(
            "Pending all eight new training runs and required diagnostics. Historical seed 0 and partial summaries cannot determine the repeatability decision."
        )
    else:
        lines += [
            f"Decision: **{decision['decision']}**.",
            "",
            decision["interpretation"],
            "",
        ]
        for condition, checks in decision["checks"].items():
            for check in checks:
                lines.append(
                    f"- {condition}, seed {check['seed']}, vs {check['baseline']}: ΔPSNR {check['psnr']:+.5f} dB, ΔSSIM {check['ssim']:+.6f}; {'passes' if check['passes'] else 'fails'}."
                )
    lines += [
        "",
        "## Interpretation and next evidence",
        "",
        "Bounded is the primary comparison; unbounded is the bounds ablation. A repeatability pass supports further investigation under this recipe. It does not establish novelty, physical map semantics, or generalization. If only unbounded passes, investigate bounds in a separately frozen experiment. If neither passes, investigate variation before adding modules. No further studies launch automatically.",
        "",
        "Paired image means, medians, trimmed means, wins and worst/best five cases are in results.json. Curves and shared observed epoch horizons are in convergence.csv and common_horizon_scores.csv. Per-image effects remain descriptive because checkpoints are validation-selected and scene independence is unverified.",
        "",
        "Resources are in results.csv: epoch time excludes setup/checkpoint writes, peak VRAM is PyTorch allocated memory, convolution MACs exclude non-convolution operations, and latency is batch-1 float32 GPU forward at 256×256 with 10 warmups and 50 measurements. Parameter matching does not match compute.",
        "",
        "Limits: two new seeds plus one historical seed; selection bias; uncertain scene independence; previous exposure to historical UIEB test results; shared U-Net-derived recipe; mixed-precision CUDA continuation may diverge numerically. Learned maps have no physical targets or reconstruction supervision. Published test scores are a separate protocol and are not combined with this validation study.",
        "",
        "See ../../../research/PAPER_OUTLINE.md, PRIOR_PAPER_AUDIT.md and NOVELTY.md for the provisional paper and outstanding contribution/generalization evidence.",
    ]
    (directory / "FINDINGS.md").write_text("\n".join(lines) + "\n")
    feasibility = [
        "# Paper feasibility assessment",
        "",
        "Status: provisional research evidence; not submission ready.",
        "",
        f"New training runs completed: {value['completed_new_training_runs']}/{expected_count}. "
        f"Required new diagnostics completed: {value['diagnosed_new_runs']}/{expected_count}.",
        "",
        f"Repeatability screen: {decision['decision'] if decision else 'pending complete evidence'}.",
        "",
        "A pass establishes repeatability under the diagnostic recipe only. A failed primary "
        "comparison must remain visible rather than being replaced by a favorable historical mean.",
        "",
        "The prior paper already contributes fixed-prior U-Net input ablation. "
        "The current three-channel spatial and three-channel global latent heads change "
        "learning, dimensionality and spatial structure together. No direct improvement "
        "over the published method or physical map interpretation is established.",
        "",
        "Before submitting: isolate the representation mechanism with separately trained "
        "local/global and matched fixed/learned controls; evaluate audited data outside "
        "model selection; compare faithful relevant baselines and measured resource costs; "
        "state the added contribution relative to the prior paper and closest literature.",
        "",
        "Select the conference from the resulting contribution and evidence. No major-conference "
        "acceptance or state-of-the-art claim is implied. The eight-run stage launches no follow-up study.",
        "",
        "Provisional outline and contribution audit: ../../../research/PAPER_OUTLINE.md, "
        "../../../research/PRIOR_PAPER_AUDIT.md, ../../../research/NOVELTY.md.",
    ]
    (directory / "PAPER_FEASIBILITY.md").write_text("\n".join(feasibility) + "\n")
    if finished:
        artifacts = {
            path.name: digest(path)
            for path in directory.iterdir()
            if path.suffix in (".csv", ".json", ".md") and path != marker
        }
        freeze_json(marker, {"complete": True, "artifact_hashes": artifacts})
    print(directory / "FINDINGS.md", flush=True)
