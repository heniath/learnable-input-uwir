# Fast U-Net architecture screening

This experiment follows the user's 2026-10-21 request to improve the existing
U-Net while retaining NAFNet as an external performance reference. Original
studies, splits, checkpoints and completed results remain unchanged.

The first stage runs four conditions for six full-data epochs at seed 0, each
starting from the same validation-selected bounded-map U-Net checkpoint:

| Condition | Single change |
|---|---|
| control | Continue training the original model |
| residual_refine | Add `0.1*tanh(Conv3x3(decoder64))` after the existing sigmoid output |
| multiscale | Add zero-initialized 1x1 projections of the six latent maps after encoder levels 2/3/4 |
| skip_gate | Multiply each encoder skip by `1 + 0.5*tanh(Conv1x1(resized_maps))` |

All additional weights/biases start at zero. The exact pretrained function must
reproduce before training, and each condition uses the same sample/augmentation
order within its seed. Residual refinement is an additive correction to the
pretrained output; it does not replace the head with a new RGB-residual head.
The residual variant can output outside [0,1] during training; inherited VGG loss
clips its input, L1 uses the raw prediction, and validation clips predictions.

Fine-tuning resets AdamW/scheduler for all conditions: LR 2e-5, cosine to 1e-6
over six epochs, original batch 4/720 train/80 validation/256-pixel processing,
original L1 + VGG weights 1/1 and AMP. No validation loss or unrelated quality
metrics are computed; validation uses the original float32 per-image PSNR/SSIM.
This is a distinct short-adaptation condition from the historical 100-epoch runs.

At most one candidate is promoted: best validation PSNR must beat continuation
control by at least 0.1 dB, its selected SSIM must not fall, and its mean PSNR over
the final three epochs must beat the corresponding control mean. Ties rank by
PSNR then SSIM. A passing candidate and control get six epochs at seed 1, using
that seed's existing pretrained checkpoint. Maximum budget: six runs/36 epochs.
No passing candidate means the study ends after four runs. No test inference,
architecture combinations, full retraining or unbounded search runs automatically.

Commands, using the unchanged `uieb-latent-repro` Conda environment:

```bash
python scripts/run.py smoke
python scripts/run.py all
python scripts/run.py report
```

`all` performs preflight and smoke if needed, then runs sequentially on one GPU.
Use tmux session `unet-fast-screen` for disconnect-safe execution. A process lock
prevents duplicate runners. `outputs/unet_arch_screen_v1/` contains frozen source,
configuration/environment/data/checkpoint identities, smoke results, live
`job_status.json`, logs, per-epoch histories/metrics, best/last checkpoints, CSV
comparisons and `FINDINGS.md`. Completed runs are preserved; interrupted training
resumes at the last saved epoch with optimizer/scheduler/scaler/RNG restored.
CUDA continuation is not guaranteed bitwise identical. No source/config edits
are permitted after freezing; create a new experiment for changes.

These measurements screen short warm-start adaptation and cannot rank converged
architectures, establish SOTA, prove physical map semantics, or isolate every
added-capacity explanation. New-only seed evidence is distinguished from the
historical pretrained state; no claim of a fresh unseen test is made.
