# Implementation validation, 2026-10-21

Current runnable configuration set is `configs/*_v2.json`. This record describes
functionality checks only. Neither H1 nor H2's 30-epoch pilot has been trained.
No held-out test predictions or external evaluation were performed.

## Passed checks

- CPU unit suite: 13 tests passed in 5.341 seconds with the unchanged
  `uieb-latent-repro` Python. Exact command and captured output are in
  `unit_tests_v2.log`.
- Tests cover shared initialization, removal of disabled heads, exact CPU A3
  compatibility with the original bounded U-Net, identity initialization of
  spatial/FiLM adapters, skip-copy isolation from the encoder stream, gradients,
  invalid G shapes, frozen recipe inheritance, split overlap rejection,
  prevention of a test loader, paired filename matching, missing factorial
  cells, sample SD and actual AdamW update counting.
- Parent source, pinned clean upstream checkout, VGG weights, all dataset file
  hashes and the original 720/80/90 split were verified during preparation.
- CUDA smoke passed for all four H1 and all four H2 conditions. Each condition
  executed two real optimizer updates at batch size4 with AMP and the original
  L1+VGG loss. Batch/augmentation hashes match across conditions within stage.
- All active heads and adapters receive finite gradients. Full model,
  optimizer, scheduler, scaler, early-stopping and RNG checkpoint state restored
  exactly in smoke. This does not establish bitwise continuation trajectories.
- A separate A3 functionality run completed one full epoch: 720 training images,
  180 batches, 180 measured AdamW updates, zero AMP-skipped updates and 80
  validation images. Best/last checkpoints, per-image metrics and CSV/history
  were written. Calling train again preserved the completed run.
- The report reproduced the selected checkpoint's PSNR/SSIM from its per-image
  file and correctly omitted factorial interaction with only one cell available.
- Inference profiling completed using the parent protocol, batch1 float32,
  10 warmups/50 CUDA-event measurements, and saved its own inference memory
  scope. These timings describe this implementation-check checkpoint only.
- H1/H2 pilot reports correctly show zero completed research runs and four
  missing runs each. No absent results are filled from smoke or old studies.

## Commands and artifacts

```bash
python -B -m unittest discover -s tests -v
python -B scripts/run.py --config configs/h1_pilot_v2.json prepare
python -B scripts/run.py --config configs/h1_pilot_v2.json smoke
python -B scripts/run.py --config configs/h2_pilot_v2.json prepare
python -B scripts/run.py --config configs/h2_pilot_v2.json smoke
python -B scripts/run.py --config configs/functional_check_v2.json prepare
python -B scripts/run.py --config configs/functional_check_v2.json smoke
python -B scripts/run.py --config configs/functional_check_v2.json train --condition A3_both --seed 0
python -B scripts/run.py --config configs/functional_check_v2.json report
python -B scripts/run.py --config configs/functional_check_v2.json profile --condition A3_both --seed 0
```

The exact absolute commands, exit codes and bounded runner log are preserved
under `validation/v2/implementation_checks.json` and `.log`. All ten commands
in that runner succeeded, including a second train call checking preservation.
Copies of the validation orchestration scripts are retained in this folder.

Source snapshots, resolved configs, identities and smoke files are under
`outputs/conditioning_h1_pilot_v2/`, `outputs/conditioning_h2_pilot_v2/` and
`outputs/conditioning_functional_check_v2/`. The full confirmation config is
provided but has not been prepared or executed.

## Limits and preserved observations

The existing Kornia CUDA AMP deprecation warning remains visible. GPU access
failed inside the restricted sandbox but both nvidia-smi and PyTorch worked
outside it. No drivers, environment packages or system configuration changed.

V1 artifacts remain unchanged. V2 corrects optimizer-update bookkeeping, using
the common backbone parameter's AdamW step rather than assuming every batch
updates weights. The two one-epoch implementation checks produced different
validation scores despite matching all180 training-batch hashes and both having
180 updates at final scaler1024. The source of this numerical variation has not
been isolated. Do not use these runs as architecture comparisons or evidence
of deterministic replay. Additional repeated runs would be a separate
reproducibility investigation.

No dataset/checkpoint/log was removed. Original parent files are read-only
dependencies; only the new project and validation records were written.
