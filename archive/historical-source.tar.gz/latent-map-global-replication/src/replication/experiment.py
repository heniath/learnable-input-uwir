"""Dimension runs use the original loss, epoch engine and durable state format."""

import json

import numpy as np
import torch

from conditioning.experiment import TraceLoader, evaluate, finish, optimizer_step_count
from conditioning.protocol import write_csv
from diagnostics.engine import epoch_step, payload, restore
from diagnostics.models import convolution_macs
from diagnostics.protocol import atomic_json, canonical, loader, seed_original
from diagnostics.validation import compare_state
from uwir.cli.train import train_epoch
from uwir.training.checkpoint import save_checkpoint

from global_study.models import GlobalLatentUNet
from global_study.training import make_objects
from global_study.diagnostic import training_batches, vector_statistics
from global_study.protocol import verify_diagnostic
from diagnostics.diagnose import metric_rows
from diagnostics.protocol import digest
from .protocol import config, output_root, verify_run, require_new, run_directory, diagnostic_directory, expected_identity


def smoke(frozen):
    out = output_root()
    marker = out / "smoke.json"
    if marker.exists():
        previous = json.loads(marker.read_text())
        if previous.get("passed") and previous["frozen_identity"] == canonical(frozen):
            print("Preserving completed dimension smoke", flush=True)
            return
        raise ValueError("Existing smoke identity is invalid")
    directory = out / "smoke"
    if directory.exists():
        raise ValueError("Partial smoke exists; inspect before rerun")
    directory.mkdir()
    results = {}
    for dimension, seed in config()["new_runs"]:
        key = f"d{dimension}_seed{seed}"
        objects = make_objects(dimension, seed, frozen)
        model = objects[0]
        traced = TraceLoader(loader("train", seed=seed, epoch=1, limit=8))
        loss, _ = train_epoch(model, traced, objects[2], objects[1], torch.device("cuda"), scaler=objects[4])
        if not np.isfinite(loss):
            raise FloatingPointError("Non-finite dimension smoke loss")
        if any(p.grad is None or not torch.isfinite(p.grad).all() for p in model.parameters()):
            raise ValueError("Missing/non-finite dimension smoke gradients")
        head_grad = model.base.background_extractor.net[-2].weight.grad.flatten(1).abs().sum(1)
        if not (head_grad > 0).all():
            raise ValueError("A global coordinate receives no smoke gradient")
        steps = optimizer_step_count(objects[2], model.base.backbone.enc1.net[0].weight)
        if steps != 2:
            raise ValueError("Expected two actual smoke optimizer updates")
        means, rows = evaluate(model, seed, limit=4)
        write_csv(directory / f"{key}_validation.csv", rows)
        state = payload(objects, epoch=1, history=[{"validation": means}], best=means,
                        identity={"smoke_dimension": dimension, "seed": seed})
        checkpoint = directory / f"{key}_roundtrip.pt"
        save_checkpoint(checkpoint, state)
        del state
        saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
        restore(objects, saved)
        actual = payload(objects, epoch=1, history=saved["history"], best=saved["best"], identity=saved["identity"])
        stats = {"bitwise_equal": True, "max_absolute_tensor_difference": 0.0}
        for state_key in ("model", "optimizer", "scheduler", "scaler", "early_stopping", "rng_state"):
            compare_state(saved[state_key], actual[state_key], stats, state_key)
        if not stats["bitwise_equal"]:
            raise ValueError("Dimension smoke full-state restoration failed")
        results[key] = {"train_loss": loss, "validation": means, "actual_updates": steps,
                                   "checkpoint_roundtrip_exact": True, "batch_hashes": traced.batch_hashes,
                                   "parameters": model.parameter_counts()}
        print(f"Smoke passed d={dimension}, seed={seed}, updates={steps}, full state exact", flush=True)
        del model, objects, saved, actual
        torch.cuda.empty_cache()
    for seed in (1, 2):
        hashes = [results[f"d{dimension}_seed{seed}"]["batch_hashes"] for dimension in (6, 12)]
        if hashes[0] != hashes[1]:
            raise ValueError("Dimension smoke batch/augmentation pairing differs within seed")
    atomic_json(marker, {"passed": True, "frozen_identity": canonical(frozen), "results": results,
                         "scope": "Two real updates and four validation images per dimension; functionality only"})


def train(dimension, seed, frozen):
    c = config()
    require_new(dimension, seed)
    smoke_result = json.loads((output_root() / "smoke.json").read_text())
    if not smoke_result["passed"] or smoke_result["frozen_identity"] != canonical(frozen):
        raise ValueError("Pass dimension smoke before training")
    condition = f"d_{dimension}"
    directory = run_directory(dimension, seed)
    directory.mkdir(parents=True, exist_ok=True)
    identity = {"condition": condition, "seed": seed, "frozen_identity": canonical(frozen)}
    if (directory / "complete.json").exists():
        verify_run(directory, identity)
        print(f"Preserving completed {condition}/seed_{seed}", flush=True)
        return
    objects = make_objects(dimension, seed, frozen)
    model = objects[0]
    model.eval()
    macs = convolution_macs(model)
    history, best, start, peak = [], None, 1, 0
    last = directory / "last.pt"
    if last.exists():
        saved = torch.load(last, map_location="cpu", weights_only=False)
        if saved["identity"] != identity:
            raise ValueError("Dimension resume identity mismatch")
        if saved["complete"]:
            finish(directory, saved)
            return
        selected = torch.load(directory / "best.pt", map_location="cpu", weights_only=False)
        if selected["identity"] != identity or selected["best"] != saved["best"]:
            raise ValueError("Interrupted best/last transaction; inspect before resume")
        del selected
        restore(objects, saved)
        history, best, start, peak = saved["history"], saved["best"], saved["epoch"] + 1, saved["peak_allocated_bytes"]
        del saved
    elif (directory / "best.pt").exists():
        raise ValueError("best.pt exists without resumable last.pt; inspect partial run")
    atomic_json(directory / "run.json", {**identity, "config": c, "dimension": dimension,
                                         "parameters": model.parameter_counts(), "conv_linear_macs": macs})
    torch.cuda.reset_peak_memory_stats()
    try:
        for epoch in range(start, c["budget"]["epochs"] + 1):
            traced = TraceLoader(loader("train", seed=seed, epoch=epoch))
            before = optimizer_step_count(objects[2], model.base.backbone.enc1.net[0].weight)
            row = {"epoch": epoch, **epoch_step(objects, traced, loader("validation", seed=seed))}
            row["batch_hashes"] = traced.batch_hashes
            row["optimizer_steps"] = optimizer_step_count(objects[2], model.base.backbone.enc1.net[0].weight)
            row["amp_skipped_updates_epoch"] = len(traced.batch_hashes) - (row["optimizer_steps"] - before)
            if not 0 <= row["amp_skipped_updates_epoch"] <= len(traced.batch_hashes):
                raise ValueError("Inconsistent AdamW update count")
            history.append(row)
            score = (row["validation"]["psnr"], row["validation"]["ssim"])
            if best is None or score > (best["psnr"], best["ssim"]):
                means, rows = evaluate(model, seed)
                if any(abs(means[key] - row["validation"][key]) > 1e-5 for key in means):
                    raise ValueError("Dimension validation per-image/aggregate mismatch")
                best = {"epoch": epoch, "psnr": score[0], "ssim": score[1]}
                save_checkpoint(directory / "best.pt", {"model": model.state_dict(), "identity": identity, "best": best,
                                                       "per_image": rows, "parameters": model.parameter_counts(), "conv_linear_macs": macs})
            complete = epoch == c["budget"]["epochs"]
            state = payload(objects, epoch=epoch, history=history, best=best, identity=identity, complete=complete)
            state["optimizer_steps"] = row["optimizer_steps"]
            peak = max(peak, state["peak_allocated_bytes"])
            state["peak_allocated_bytes"] = peak
            save_checkpoint(last, state)
            atomic_json(directory / "history.json", history)
            write_csv(directory / "train_log.csv", [{"epoch": r["epoch"], "psnr": r["validation"]["psnr"],
                                                     "ssim": r["validation"]["ssim"], "train_loss": r["train_loss"],
                                                     "val_loss": r["val_loss"], "lr": r["lr"], "epoch_seconds": r["epoch_seconds"],
                                                     "optimizer_steps": r["optimizer_steps"],
                                                     "amp_skipped_updates_epoch": r["amp_skipped_updates_epoch"]} for r in history])
            print(f"{condition}/seed_{seed} epoch={epoch} PSNR={score[0]:.5f} SSIM={score[1]:.6f}", flush=True)
            if complete:
                finish(directory, state)
                break
            del state
    except Exception as exc:
        import time
        atomic_json(directory / f"failure_{time.time_ns()}.json", {"error": repr(exc)})
        raise


@torch.inference_mode()
def diagnose(dimension, seed, frozen):
    require_new(dimension, seed)
    seed_original(seed)
    phase, condition = "dimension", f"d_{dimension}"
    source = run_directory(dimension, seed)
    saved, expected_rows, _ = verify_run(source, expected_identity(dimension, seed, frozen))
    state = torch.load(source / "best.pt", map_location="cpu", weights_only=False)
    if state["identity"] != saved["identity"] or state["best"] != saved["best"]:
        raise ValueError("Diagnostic checkpoint identity/selection mismatch")
    model = GlobalLatentUNet(dimension, seed)
    model.load_state_dict(state["model"], strict=True)
    del state
    model = model.cuda().eval()
    identity = {"phase": phase, "condition": condition, "seed": seed,
                "frozen_identity": canonical(frozen), "checkpoint_sha256": saved["best_sha256"]}
    target = diagnostic_directory(dimension, seed)
    if verify_diagnostic(target, identity):
        print(f"Preserving completed diagnostic: {phase}/{condition}/seed_{seed}", flush=True)
        return
    if target.exists():
        raise ValueError("Partial diagnostic exists; preserve it and inspect before rerunning")
    target.mkdir(parents=True)
    manifest = json.loads((output_root() / "manifest.json").read_text())
    batches, expected_names = training_batches(manifest)
    train_values, names = [], []
    for x, _, batch_names, _ in batches:
        values = model.base.background_extractor(x.cuda()).flatten(1).cpu().numpy()
        train_values.extend(values.astype(np.float64))
        names.extend(batch_names)
    train_values = np.asarray(train_values)
    if names != expected_names or len(names) != 720 or not np.isfinite(train_values).all():
        raise ValueError("Training-only G coverage/values invalid")
    mean = train_values.mean(axis=0)
    mean_tensor = torch.tensor(mean, dtype=torch.float32, device="cuda").reshape(1, -1, 1, 1)
    vector_rows = [{"filename": name, **{f"g_{i}": float(v) for i, v in enumerate(values)}}
                   for name, values in zip(names, train_values)]
    write_csv(target / "g_training.csv", vector_rows)
    normal, constant, val_values, val_names = [], [], [], []
    for x, y, batch_names, _ in loader("validation", seed=seed, filenames=True):
        x = x.cuda()
        prediction, maps = model(x, return_maps=True)
        spatial, values = maps
        normal.extend(metric_rows(prediction, y, batch_names))
        replacement = mean_tensor.expand(x.shape[0], -1, -1, -1)
        constant.extend(metric_rows(model(x, maps_override=(spatial, replacement)), y, batch_names))
        val_values.extend(values.flatten(1).cpu().numpy().astype(np.float64))
        val_names.extend(batch_names)
    expected = [manifest["pairs"][i]["filename"] for i in manifest["indices"]["validation"]]
    if val_names != expected or [r["filename"] for r in expected_rows] != expected:
        raise ValueError("Validation intervention filenames/order changed")
    original = {r["filename"]: r for r in expected_rows}
    drift = {key: max(abs(row[key] - float(original[row["filename"]][key])) for row in normal)
             for key in ("psnr", "ssim")}
    if drift["psnr"] > 0.001 or drift["ssim"] > 0.00001:
        raise ValueError(f"Normal validation reproduction failed: {drift}")
    differences = [{"filename": a["filename"], "delta_psnr_mean_minus_normal": b["psnr"] - a["psnr"],
                    "delta_ssim_mean_minus_normal": b["ssim"] - a["ssim"]} for a, b in zip(normal, constant)]
    write_csv(target / "g_validation.csv", [{"filename": name, **{f"g_{i}": float(v) for i, v in enumerate(values)}}
                                            for name, values in zip(val_names, val_values)])
    write_csv(target / "normal_validation.csv", normal)
    write_csv(target / "training_mean_validation.csv", constant)
    write_csv(target / "paired_intervention.csv", differences)
    normal_means = {key: float(np.mean([r[key] for r in normal])) for key in ("psnr", "ssim")}
    constant_means = {key: float(np.mean([r[key] for r in constant])) for key in ("psnr", "ssim")}
    result = {"identity": identity, "source": str(source), "selected_epoch": saved["best"]["epoch"],
              "training_mean_g": mean.tolist(), "training_statistics": vector_statistics(train_values),
              "validation_statistics": vector_statistics(val_values), "normal_validation": normal_means,
              "training_mean_validation": constant_means,
              "delta_mean_minus_normal": {key: constant_means[key] - normal_means[key] for key in normal_means},
              "normal_max_per_image_drift": drift,
              "mean_definition": "All 720 training images; eval mode; augmentation disabled; inherited resize/center crop; no validation/test contribution",
              "interpretation": "Descriptive variation and intervention sensitivity; no physical semantics or unconditional collapse claim"}
    atomic_json(target / "results.json", result)
    if digest(source / "best.pt") != saved["best_sha256"]:
        raise ValueError("Diagnostic source checkpoint changed")
    atomic_json(target / "complete.json", {"identity": identity,
                                           "artifact_hashes": {p.name: digest(p) for p in target.iterdir() if p.is_file()}})
    print(f"{phase}/{condition}/seed_{seed}: G train SD={result['training_statistics']['population_sd']}; "
          f"mean intervention delta PSNR={result['delta_mean_minus_normal']['psnr']:+.5f}", flush=True)
