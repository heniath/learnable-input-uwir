# H1 replication and global dimension test analysis — 2026-10-22

Evaluation: `outputs/global_followup_test90_v1/`. All 15 unique validation-selected
checkpoints completed inference on the same historical 90-image UIEB test split.
Dimension d=3 aliases H1 global-only seed 0. No model was selected or retrained
using these test results. The training studies remain unchanged.

## H1: the global contribution repeats on test

The table uses arithmetic test-image means for each model, followed by mean and
sample SD across the three training seeds. Gains are paired against same-seed RGB.

| Condition | Test PSNR mean +/- sample SD | Test SSIM mean +/- sample SD | Paired test PSNR gain vs RGB mean +/- sample SD |
|---|---:|---:|---:|
| RGB | 20.16029 +/- 0.18470 | 0.876384 +/- 0.002501 | — |
| Spatial only | 19.88696 +/- 0.17334 | 0.873743 +/- 0.002450 | -0.27333 +/- 0.22680 |
| Global only | 21.56529 +/- 0.04721 | 0.897096 +/- 0.002350 | +1.40500 +/- 0.20211 |
| Spatial + global | 21.59795 +/- 0.07686 | 0.895141 +/- 0.002812 | +1.43767 +/- 0.15915 |

Global-only gains over RGB are +1.63581, +1.25974 and +1.31945 dB at seeds
0/1/2. SSIM improves in all three seeds. The two new seeds alone average
+1.28959 +/- 0.04222 dB, so the observed effect is not confined to seed 0.
Joint maps likewise improve over RGB in every seed. Spatial-only PSNR is below
RGB in all three seeds, with losses -0.11593, -0.17077 and -0.53330 dB.

The consistent validation gain of global-only (+1.88578 dB mean) is therefore
also observed on this test partition (+1.40500 dB mean), although its magnitude
is smaller. These are descriptive repeated-seed results on one inherited split,
not a statistical significance or unseen-dataset generalization claim.

## Spatial: a small metric tradeoff, not a settled removal decision

| Seed | Joint minus global-only test PSNR | Joint minus global-only test SSIM |
|---:|---:|---:|
| 0 | -0.02531 | -0.000241 |
| 1 | +0.03744 | -0.003757 |
| 2 | +0.08588 | -0.001869 |
| Mean +/- sample SD | +0.03267 +/- 0.05575 | -0.001956 +/- 0.001760 |

Joint maps have the highest three-seed mean test PSNR, while global-only has the
highest mean test SSIM. The incremental spatial PSNR effect is small, changes
sign across seeds, and is accompanied by lower SSIM in every seed. Its mean
validation effect was -0.05900 dB; the mean test effect is +0.03267 dB.

This evidence does not support a broad improvement from the current spatial
input concatenation. It also does not justify claiming spatial information is
universally harmful or deleting the branch permanently. Alternative spatial
placements are separate experimental conditions; the previous H2 spatial-skip
result remains a separate one-seed study. None of these test scores is used here
to revise a model-selection rule or promote an architecture.

## Dimension screen: d=6 retains its validation signal, with uneven image gains

All dimension results below are seed 0 only and use their own validation-selected
checkpoint. d=3 is the already evaluated global-only seed-0 checkpoint.

| d | Val PSNR | Test PSNR | Test SSIM | Paired test PSNR gain vs d=3 | PSNR wins / 90 | Median image gain vs d=3 |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 20.77943 | 20.60163 | 0.882502 | -0.98187 | 27 | -1.01879 |
| 3 | 21.89814 | 21.58350 | 0.895447 | 0 | — | 0 |
| 6 | 22.11815 | 21.89807 | 0.899627 | +0.31457 | 45 | +0.01944 |
| 12 | 22.07535 | 21.85112 | 0.899169 | +0.26762 | 51 | +0.21834 |

d=6 had the highest validation score before this test evaluation, and also has
the highest mean test PSNR/SSIM in this one-seed screen. d=1 underperforms d=3
on both validation and test. Increasing to d=12 does not increase the observed
mean over d=6, but their test gap is only 0.04695 dB.

The per-image distribution matters: d=6 exceeds d=3 on only 45/90 images, with
median gain 0.01944 dB despite a mean gain of 0.31457 dB. Gains and losses range
from -4.56718 to +4.60583 dB. d=12 wins on 51/90 images against d=3 with a
larger median gain, despite its slightly smaller mean. Directly against d=12,
d=6 wins on 39/90 images and has median difference -0.07279 dB. Thus the mean
ranking does not imply uniform or per-image dominance. Quantiles, the full
d=6 versus d=12 contrast and descriptive extreme examples are saved alongside
this analysis; they do not change checkpoint choices or drive test tuning.

The fixed-example contact sheet also shows a local color failure: around the
bright light in `847_img_.png`, d=3/6/12 predictions have colored halos that
are not present in the white reference region. This is one qualitative
observation from a prespecified example, not an estimate of failure frequency.

## Relation to the global-vector diagnostics

The prior diagnostics used validation, not test interventions. Across all six
H1 global/joint checkpoints, training G has rank 3 and coordinate SDs about
0.108–0.149. Replacing image-dependent G with its checkpoint-specific training
mean reduces validation PSNR by 4.33841 dB on average for global-only and
4.21455 dB for joint maps. This supports image-dependent global conditioning
and sensitivity to the specified intervention. It does not identify G as
physical background light or exclude capacity/optimization explanations without
appropriate additional controls. No training-mean intervention was added on test.

## Research recommendation

The next focused experiment remains the one proposed from validation before
test inference: repeat d=6 at seeds 1/2, paired with existing d=3 global-only
checkpoints from those seeds, under the same pilot protocol. Do not expand the
dimension grid or reinterpret a single-seed 0.04695 dB gap as proof that d=6 is
optimal. This evaluation did not launch that experiment.

Use global-only as the primary reference for the global study. Preserve the
spatial branch and its artifacts; current input concatenation provides a small
and inconsistent additional PSNR effect with an SSIM tradeoff. A permanent
spatial removal/redesign decision needs evidence matched to that particular
architectural question, rather than further tuning on this exposed test split.

## Verification and scope

- All 15 full validation anchors reproduced saved per-image PSNR/SSIM with zero
  drift before any test prediction.
- Independent verification passed all 1,430 saved artifact hashes, all 15 test
  means, seed means/sample SDs, paired contrasts and dimension gains.
- All 1,350 prediction PNGs are readable RGB 256 x 256 images. Float metrics
  precede PNG quantization. Seed-0 H1 test metrics reproduce the previous
  evaluation within 1e-10 per image.
- The dimension contact sheet was visually inspected. All checkpoint and
  training metric/completion hashes were unchanged after inference.
- The run completed in 88.17 seconds including verification, metrics and file
  writing. This is not a model latency benchmark. GPU preflight permitted the
  observed idle 7 MiB launcher, with low GPU utilization, and recorded the
  policy and readings; no existing process was stopped.
- Syntax/import and synthetic report checks passed, including paired seed
  mean/sample SD and the d=3 alias. The existing Kornia AMP deprecation warning
  remained visible. No package or system setting changed.

All results retain the historical UIEB test90, resize/center-crop 256, float32
protocol and 30-epoch pilot budget. Prior test exposure, unresolved scene
independence and one-seed dimension comparisons limit the conclusions. No new
training, TTA, ensembling, test-based checkpoint choice or automatic spatial
decision was performed.
