#!/usr/bin/env python3
"""Explicit operations for the four-run dimension replication study."""

import argparse
import fcntl

import bootstrap

from replication import protocol


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("prepare", "smoke", "report"):
        sub.add_parser(name)
    for name in ("train", "diagnose"):
        child = sub.add_parser(name)
        child.add_argument("--dimension", type=int, choices=(6, 12), required=True)
        child.add_argument("--seed", type=int, choices=(1, 2), required=True)
    args = parser.parse_args()
    with (protocol.TRAINING / ".execution.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.command == "prepare":
            protocol.prepare()
            print(f"Prepared {protocol.output_root()}", flush=True)
            return
        frozen = protocol.verify()
        if args.command == "report":
            from replication.report import report
            report(frozen)
        else:
            from replication import experiment
            if args.command == "smoke":
                experiment.smoke(frozen)
            else:
                getattr(experiment, args.command)(args.dimension, args.seed, frozen)


if __name__ == "__main__":
    main()
