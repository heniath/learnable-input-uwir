"""Model registry for the paper backbone and the retained UW-LYT study."""

from typing import NamedTuple

import torch.nn as nn


class ModelSpec(NamedTuple):
    """Model metadata derived from a registered model name."""

    backbone: str
    in_channels: int
    physics_mode: str


_LEGACY_VARIANTS = {
    "3ch": (3, "none"),
    "4ch_t": (4, "t"),
    "4ch_b": (4, "b"),
    "5ch": (5, "tb"),
}
_V2_VARIANTS = {
    "3ch": (3, "none"),
    "4ch_t": (4, "t"),
    "6ch_b": (6, "b_rgb"),
    "7ch": (7, "tb_rgb"),
}
_BACKBONE_VARIANTS = {
    "unet": _LEGACY_VARIANTS,
    "uwlyt": _LEGACY_VARIANTS,
    "uwlyttiny": _LEGACY_VARIANTS,
    "uwlytms": _LEGACY_VARIANTS,
    "uwlytmsv2": _LEGACY_VARIANTS,
    "uwlytv2": _V2_VARIANTS,
    "uwlytv2tiny": _V2_VARIANTS,
}

ALL_MODEL_NAMES = [
    f"{backbone}_{variant}"
    for backbone, variants in _BACKBONE_VARIANTS.items()
    for variant in variants
]
ALL_MODEL_NAMES.extend(
    (
        "learnable_physics_unet",
        "learnable_latent_unet",
        "parameterized_physics_unet",
        "learnable_latent_mobilenet_unet",
        "parameterized_physics_mobilenet_unet",
    )
)

_END_TO_END_MODELS = {
    "learnable_physics_unet",
    "learnable_latent_unet",
    "parameterized_physics_unet",
    "learnable_latent_mobilenet_unet",
    "parameterized_physics_mobilenet_unet",
}


def parse_model_variant(name: str) -> ModelSpec:
    """Parse ``<backbone>_<input variant>`` into its input contract."""
    if name in _END_TO_END_MODELS:
        return ModelSpec(name, 3, "none")
    for backbone, variants in _BACKBONE_VARIANTS.items():
        prefix = f"{backbone}_"
        if name.startswith(prefix):
            variant = name[len(prefix) :]
            if variant not in variants:
                break
            in_channels, physics_mode = variants[variant]
            return ModelSpec(backbone, in_channels, physics_mode)
    raise ValueError(f"Unknown model '{name}'. Expected one of: {', '.join(ALL_MODEL_NAMES)}")


def build_model(name: str, pretrained_backbone: bool = False) -> nn.Module:
    """Build a paper U-Net or retained UW-LYT variant."""
    del pretrained_backbone
    backbone, in_channels, physics_schema = parse_model_variant(name)

    if backbone in ("learnable_physics_unet", "learnable_latent_unet"):
        from .learnable_physics import LearnableLatentUNet

        return LearnableLatentUNet()

    if backbone == "parameterized_physics_unet":
        from .learnable_physics import ParameterizedPhysicsUNet

        return ParameterizedPhysicsUNet()

    if backbone == "learnable_latent_mobilenet_unet":
        from .learnable_physics import LearnableLatentUNet
        from .mobilenet_unet import MobileNetUNet

        return LearnableLatentUNet(enhancer=MobileNetUNet(in_channels=9))

    if backbone == "parameterized_physics_mobilenet_unet":
        from .learnable_physics import ParameterizedPhysicsUNet
        from .mobilenet_unet import MobileNetUNet

        return ParameterizedPhysicsUNet(enhancer=MobileNetUNet(in_channels=9))

    if backbone == "unet":
        from .unet import UNet5ch

        return UNet5ch(in_channels=in_channels)

    from .uwlyt import build_uwlyt, build_uwlytms, build_uwlytmsv2, build_uwlytv2

    if backbone in ("uwlytv2", "uwlytv2tiny"):
        return build_uwlytv2(physics_schema, tiny=backbone == "uwlytv2tiny")
    if backbone == "uwlytms":
        return build_uwlytms(in_channels)
    if backbone == "uwlytmsv2":
        return build_uwlytmsv2(in_channels)
    return build_uwlyt(in_channels, tiny=backbone == "uwlyttiny")
