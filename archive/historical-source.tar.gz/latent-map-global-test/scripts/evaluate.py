#!/usr/bin/env python3
"""Test reporting for H1 replication and the completed global dimension screen."""

import argparse
import csv
import fcntl
import importlib.util
import json
import re
import shutil
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
GLOBAL = ROOT.parent / "latent-map-global-study"
TRAINING = ROOT.parent / "latent-map-conditioning"
PARENT = ROOT.parent / "latent-map-diagnostics"
PREVIOUS = ROOT.parent / "latent-map-conditioning-test"
sys.path[:0] = [str(GLOBAL / "src"), str(TRAINING / "src"), str(PARENT / "src"),
                str(PARENT / "third_party/upstream/src"), str(PARENT / "third_party/nafnet")]

import numpy as np
import torch
from PIL import Image, ImageDraw

from conditioning.models import ConditionedUNet
from diagnostics.diagnose import metric_rows
from diagnostics.protocol import atomic_json, base_dataset, canonical, digest, seed_original
from global_study.models import GlobalLatentUNet
from global_study import protocol as study

HELPER_PATH = PREVIOUS / "scripts/evaluate.py"
spec = importlib.util.spec_from_file_location("prior_conditioning_evaluation", HELPER_PATH)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
indexed, write_csv, image_from = helpers.indexed, helpers.write_csv, helpers.image_from
TOLERANCES = {"psnr": 0.001, "ssim": 0.00001}
CONDITIONS = ("A0_rgb", "A1_spatial", "A2_global", "A3_both")
DIMENSIONS = (1, 3, 6, 12)


def utc():
    return datetime.now(timezone.utc).isoformat()


def item_key(item):
    return item["phase"], item["seed"], item["condition"]


def item_directory(output, item):
    return output / item["phase"] / f"seed_{item['seed']}" / item["condition"]


def inventory():
    frozen = study.verify()
    archive = study.output_root()
    complete = json.loads((archive / "complete.json").read_text())
    if complete["frozen_identity"] != canonical(frozen) or (complete["h1_cells"], complete["dimension_cells"], complete["diagnostics"]) != (12, 4, 9):
        raise ValueError("Follow-up is not complete with the required cells")
    for relative, expected in complete["report_hashes"].items():
        if digest(archive / "reports" / relative) != expected:
            raise ValueError("Completed follow-up report changed")
    previous_protocol = json.loads((PREVIOUS / "outputs/conditioning_pilots_test90_v1/protocol.json").read_text())
    if digest(HELPER_PATH) != previous_protocol["script_sha256"]:
        raise ValueError("Previous evaluation helpers changed")
    manifest = json.loads((archive / "manifest.json").read_text())
    if canonical(manifest) != frozen["manifest_sha256"] or set(manifest["indices"]["test"]) != set(range(800, 890)):
        raise ValueError("Frozen historical test90 identity changed")
    items = []

    def add(phase, condition, seed, directory, expected_identity, dimension=None):
        saved, _ = study.verify_run(directory, expected_identity)
        items.append({"phase": phase, "condition": condition, "seed": seed, "dimension": dimension,
                      "identity": saved["identity"], "selected": saved["best"], "parameters": saved["parameters"],
                      "checkpoint": str(directory / "best.pt"), "checkpoint_sha256": saved["best_sha256"],
                      "validation_csv": str(directory / "metrics_per_image.csv"),
                      "validation_csv_sha256": saved["per_image_sha256"], "complete_sha256": digest(directory / "complete.json")})

    for seed in (0, 1, 2):
        scope = "h1_seed0_config" if seed == 0 else "h1_seeds12_config"
        for condition in CONDITIONS:
            add("H1", condition, seed, study.h1_directory(seed, condition),
                {"seed": seed, "condition": condition, "frozen_identity": frozen["parent_identities"][scope]})
    for dimension in (1, 6, 12):
        condition = f"d_{dimension}"
        add("dimension", condition, 0, archive / "runs/seed_0" / condition,
            {"seed": 0, "condition": condition, "frozen_identity": canonical(frozen)}, dimension)
    if len(items) != 15 or len({item["checkpoint"] for item in items}) != 15:
        raise ValueError("Expected 15 unique fixed checkpoints")
    return frozen, complete, items, manifest


def load_model(item):
    if digest(item["checkpoint"]) != item["checkpoint_sha256"]:
        raise ValueError("Checkpoint changed after inventory")
    seed_original(item["seed"])
    model = (ConditionedUNet(item["condition"], item["seed"]) if item["phase"] == "H1"
             else GlobalLatentUNet(item["dimension"], item["seed"]))
    state = torch.load(item["checkpoint"], map_location="cpu", weights_only=False)
    if state["identity"] != item["identity"] or state["best"] != item["selected"]:
        raise ValueError("Loaded checkpoint identity/selection mismatch")
    model.load_state_dict(state["model"], strict=True)
    if model.parameter_counts() != item["parameters"]:
        raise ValueError("Model parameter counts differ from training")
    return model.cuda().eval()


@torch.inference_mode()
def validate(item, batches, names, directory):
    model = load_model(item)
    rows = []
    for x, y, batch_names in batches:
        rows.extend(metric_rows(model(x.cuda()), y, batch_names))
    indexed(rows, names)
    with Path(item["validation_csv"]).open() as handle:
        saved = indexed(list(csv.DictReader(handle)), names)
    drift = {key: max(abs(row[key] - float(saved[row["filename"]][key])) for row in rows)
             for key in ("psnr", "ssim")}
    if any(drift[key] > TOLERANCES[key] for key in TOLERANCES):
        raise ValueError(f"Validation anchor failed for {item_key(item)}: {drift}")
    write_csv(directory / "per_image_validation.csv", rows)
    atomic_json(directory / "validation_anchor.json", {"max_per_image_drift": drift, "n": 80,
                                                       "checkpoint_sha256": item["checkpoint_sha256"]})
    del model
    torch.cuda.empty_cache()
    return drift


@torch.inference_mode()
def evaluate(item, batches, names, directory, drift):
    model = load_model(item)
    predictions = directory / "predictions"
    predictions.mkdir()
    rows, examples = [], {}
    for x, y, batch_names in batches:
        prediction = model(x.cuda())
        if prediction.dtype != torch.float32 or prediction.shape != y.shape:
            raise ValueError("Unexpected output shape/precision")
        rows.extend(metric_rows(prediction, y, batch_names))
        for name, tensor in zip(batch_names, prediction):
            image = image_from(tensor)
            image.save(predictions / f"{name}.png")
            if name in names[:6]:
                examples[name] = image
    indexed(rows, names)
    if len(list(predictions.glob("*.png"))) != 90:
        raise ValueError("Expected 90 prediction PNGs")
    write_csv(directory / "per_image_test.csv", rows)
    result = {"phase": item["phase"], "condition": item["condition"], "seed": item["seed"],
              "selected_epoch": item["selected"]["epoch"], "n_test": 90,
              "validation_psnr": item["selected"]["psnr"], "validation_ssim": item["selected"]["ssim"],
              "test_psnr": float(np.mean([r["psnr"] for r in rows])), "test_ssim": float(np.mean([r["ssim"] for r in rows])),
              "max_validation_psnr_drift": drift["psnr"], "max_validation_ssim_drift": drift["ssim"],
              "checkpoint_sha256": item["checkpoint_sha256"]}
    atomic_json(directory / "result.json", result)
    del model
    torch.cuda.empty_cache()
    return result, rows, examples


def dimension_key(dimension):
    return ("H1", 0, "A2_global") if dimension == 3 else ("dimension", 0, f"d_{dimension}")


def paired(candidate, baseline, names):
    a, b = indexed(candidate, names), indexed(baseline, names)
    differences = [{"filename": name, **{f"delta_{key}": a[name][key] - b[name][key] for key in ("psnr", "ssim")}}
                   for name in names]
    values = [r["delta_psnr"] for r in differences]
    return {"delta_psnr": float(np.mean(values)), "delta_ssim": float(np.mean([r["delta_ssim"] for r in differences])),
            "median_delta_psnr": float(np.median(values)), "psnr_wins": sum(v > 0 for v in values), "n_images": len(values)}, differences


def summarize(results, per_image, output, names):
    lookup = {item_key(row): row for row in results}
    contrasts, differences = [], []
    pairs = [(condition, "A0_rgb") for condition in CONDITIONS if condition != "A0_rgb"] + [("A3_both", "A2_global")]
    for seed in (0, 1, 2):
        for condition, baseline in pairs:
            summary, details = paired(per_image[("H1", seed, condition)], per_image[("H1", seed, baseline)], names)
            contrasts.append({"seed": seed, "condition": condition, "baseline": baseline, **summary})
            differences.extend({"seed": seed, "condition": condition, "baseline": baseline, **r} for r in details)
    summaries, aggregates = [], []
    for scope, seeds in (("all_seeds_0_1_2", (0, 1, 2)), ("new_seeds_1_2", (1, 2))):
        for condition in CONDITIONS:
            values = [lookup[("H1", seed, condition)] for seed in seeds]
            row = {"scope": scope, "condition": condition, "seeds": list(seeds), "n_seeds": len(seeds)}
            for key in ("validation_psnr", "validation_ssim", "test_psnr", "test_ssim"):
                row[key + "_mean"] = statistics.mean(r[key] for r in values)
                row[key + "_sample_sd"] = statistics.stdev(r[key] for r in values)
            summaries.append(row)
        for condition, baseline in pairs:
            values = [r for r in contrasts if r["seed"] in seeds and r["condition"] == condition and r["baseline"] == baseline]
            aggregates.append({"scope": scope, "condition": condition, "baseline": baseline, "n_seeds": len(seeds),
                               "delta_psnr_mean": statistics.mean(r["delta_psnr"] for r in values),
                               "delta_psnr_sample_sd": statistics.stdev(r["delta_psnr"] for r in values),
                               "delta_ssim_mean": statistics.mean(r["delta_ssim"] for r in values),
                               "delta_ssim_sample_sd": statistics.stdev(r["delta_ssim"] for r in values)})
    dimensions = []
    dimension_pairs = []
    for dimension in DIMENSIONS:
        row = lookup[dimension_key(dimension)]
        delta, details = paired(per_image[dimension_key(dimension)], per_image[dimension_key(3)], names)
        dimensions.append({"dimension": dimension, "seed": 0, "selected_epoch": row["selected_epoch"],
                           "validation_psnr": row["validation_psnr"], "validation_ssim": row["validation_ssim"],
                           "test_psnr": row["test_psnr"], "test_ssim": row["test_ssim"],
                           **delta, "checkpoint_sha256": row["checkpoint_sha256"]})
        dimension_pairs.extend({"dimension": dimension, "baseline_dimension": 3, **r} for r in details)
    for name, rows in (("results.csv", results), ("h1_seed_summary.csv", summaries), ("h1_seed_contrasts.csv", contrasts),
                       ("h1_paired_summary.csv", aggregates), ("h1_paired_per_image.csv", differences),
                       ("dimension_test.csv", dimensions), ("dimension_paired_per_image.csv", dimension_pairs)):
        write_csv(output / name, rows)
    atomic_json(output / "results.json", {"h1_summaries": summaries, "h1_paired_summaries": aggregates,
                                          "h1_seed_contrasts": contrasts, "dimensions": dimensions, "individual": results})
    lines = ["# Global follow-up: validation-selected UIEB test90", "",
             "15 unique checkpoints; 12 H1 cells across seeds 0/1/2 and 3 additional dimension models at seed 0. "
             "d=3 aliases H1 global-only seed 0. All 15 full validation anchors passed before test inference.", "",
             "## Per-seed H1", "", "| Seed | Condition | Selected epoch | Val PSNR | Val SSIM | Test PSNR | Test SSIM |",
             "|---|---|---:|---:|---:|---:|---:|"]
    for r in results:
        if r["phase"] == "H1":
            lines.append(f"| {r['seed']} | {r['condition']} | {r['selected_epoch']} | {r['validation_psnr']:.5f} | {r['validation_ssim']:.6f} | {r['test_psnr']:.5f} | {r['test_ssim']:.6f} |")
    lines += ["", "## H1 three-seed summaries", "", "Means +/- sample SD across training seeds, not image-level confidence intervals.", "",
              "| Condition | Val PSNR | Test PSNR | Test SSIM |", "|---|---:|---:|---:|"]
    for r in summaries:
        if r["scope"] == "all_seeds_0_1_2":
            lines.append(f"| {r['condition']} | {r['validation_psnr_mean']:.5f} +/- {r['validation_psnr_sample_sd']:.5f} | "
                         f"{r['test_psnr_mean']:.5f} +/- {r['test_psnr_sample_sd']:.5f} | {r['test_ssim_mean']:.6f} +/- {r['test_ssim_sample_sd']:.6f} |")
    lines += ["", "## H1 paired test effects", "", "| Seed | Condition | Baseline | Delta PSNR | Delta SSIM | PSNR wins / 90 |",
              "|---|---|---|---:|---:|---:|"]
    for r in contrasts:
        lines.append(f"| {r['seed']} | {r['condition']} | {r['baseline']} | {r['delta_psnr']:+.5f} | {r['delta_ssim']:+.6f} | {r['psnr_wins']} |")
    lines += ["", "| Condition | Baseline | Paired delta PSNR mean +/- SD | Paired delta SSIM mean +/- SD |", "|---|---|---:|---:|"]
    for r in aggregates:
        if r["scope"] == "all_seeds_0_1_2":
            lines.append(f"| {r['condition']} | {r['baseline']} | {r['delta_psnr_mean']:+.5f} +/- {r['delta_psnr_sample_sd']:.5f} | {r['delta_ssim_mean']:+.6f} +/- {r['delta_ssim_sample_sd']:.6f} |")
    lines += ["", "New-seeds-only (1/2) summaries are retained separately in the CSV/JSON summaries.", "",
              "## Global-only dimension screen: seed 0", "", "| d | Selected epoch | Val PSNR | Test PSNR | Test SSIM | Delta test PSNR vs d=3 | PSNR wins / 90 |",
              "|---:|---:|---:|---:|---:|---:|---:|"]
    for r in dimensions:
        lines.append(f"| {r['dimension']} | {r['selected_epoch']} | {r['validation_psnr']:.5f} | {r['test_psnr']:.5f} | {r['test_ssim']:.6f} | {r['delta_psnr']:+.5f} | {r['psnr_wins']} |")
    lines += ["", "## Protocol and evidence boundaries", "",
              "User requested test reporting after completion of the validation-only study. All best.pt choices were fixed by validation before inference. "
              "No training, test-driven checkpoint choice, TTA or ensemble. This evaluation does not change the spatial decision or launch later experiments.", "",
              "Inherited historical UIEB test90, shorter-edge resize 256 and aligned center crop 256, float32 batch4. "
              "Original per-image PSNR/SSIM on clipped float predictions; arithmetic image means. All 90 prediction PNGs per model are saved, "
              "but quantization does not affect metrics. Contact sheets use the first six frozen filenames chosen before inference.", "",
              "Training seeds and images are distinct units. Across-seed sample SD is descriptive; no significance or scene-independent confidence interval is claimed. "
              "Dimension effects have one seed only and varying parameter/input widths. All runs retain a 30-epoch pilot budget. "
              "Prior test exposure and unresolved scene independence remain; these are not unseen native-resolution benchmark scores.", "",
              "See protocol.json, validation_anchor.json files, execution.log and complete.json for sources/environment, identities, exact validation drift and artifact hashes."]
    (output / "FINDINGS.md").write_text("\n".join(lines) + "\n")


def contact_sheet(batches, examples, columns, path):
    samples = [(name, image_from(x[i]), image_from(y[i])) for x, y, names in batches for i, name in enumerate(names)][:6]
    sheet = Image.new("RGB", ((len(columns) + 2) * 256, len(samples) * 286), "white")
    draw = ImageDraw.Draw(sheet)
    for row, (name, raw, reference) in enumerate(samples):
        images = [("Input", raw), ("Reference", reference)] + [(label, examples[key][name]) for label, key in columns]
        for col, (label, image) in enumerate(images):
            left, top = col * 256, row * 286
            draw.text((left + 4, top + 2), label, fill="black")
            draw.text((left + 4, top + 14), name, fill="black")
            sheet.paste(image, (left, top + 28))
    sheet.save(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", default="global_followup_test90_v1")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", args.run_id):
        parser.error("run-id must be a safe directory name")
    started = time.perf_counter()
    # GPU checks precede output creation so a busy-GPU refusal creates no partial evaluation.
    gpu = subprocess.check_output(["nvidia-smi"], text=True)
    processes = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader"], text=True)
    resources = subprocess.check_output(["nvidia-smi", "--query-gpu=utilization.gpu,memory.free", "--format=csv,noheader,nounits"], text=True)
    utilization, free_mib = (int(v.strip()) for v in resources.strip().split(","))
    active, permitted_services = [], []
    for row in csv.reader(processes.splitlines()):
        if not row:
            continue
        name = row[1].strip()
        desktop = name == "/usr/libexec/gnome-remote-desktop-daemon"
        idle_launcher = (name.replace("\\", "/").lower() == "s:/steamapps/common/warframe/tools/launcher.exe"
                         and float(row[2].split()[0]) <= 32 and utilization <= 10 and free_mib >= 4096)
        (permitted_services if desktop or idle_launcher else active).append(row)
    if active:
        raise RuntimeError(f"Other GPU compute processes active: {active}")
    if not torch.cuda.is_available():
        raise RuntimeError("PyTorch CUDA unavailable")
    output = ROOT / "outputs" / args.run_id
    output.mkdir(parents=True, exist_ok=False)

    def log(message):
        line = f"{utc()} {message}"
        print(line, flush=True)
        with (output / "execution.log").open("a") as handle:
            handle.write(line + "\n")

    def status(stage, **details):
        atomic_json(output / "job_status.json", {"stage": stage, "updated_utc": utc(), **details})

    try:
        with (TRAINING / ".execution.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            status("preflight")
            (output / "nvidia-smi.txt").write_text(gpu)
            log("Verifying completed global follow-up, frozen sources/environment/data and checkpoint hashes")
            frozen, complete, items, manifest = inventory()
            names = {split: [manifest["pairs"][i]["filename"] for i in manifest["indices"][split]] for split in ("validation", "test")}
            atomic_json(output / "protocol.json", {
                "run_id": args.run_id, "utc": utc(), "authorization": "User requested inference then analysis of the completed global follow-up",
                "training_frozen_identity": canonical(frozen), "training_complete_sha256": digest(study.output_root() / "complete.json"),
                "environment": frozen["environment"], "checkpoint_inventory": items,
                "dimension_d3_alias": {"phase": "H1", "seed": 0, "condition": "A2_global"},
                "script_sha256": digest(__file__), "helpers_path": str(HELPER_PATH), "helpers_sha256": digest(HELPER_PATH),
                "manifest_sha256": canonical(manifest), "test_names": names["test"], "examples": names["test"][:6],
                "selection": "Existing validation best.pt; no test-based selection", "precision": "float32", "batch_size": 4,
                "preprocessing": "Inherited shorter-edge resize 256 then aligned center crop 256; RGB [0,1]",
                "metrics": "Original clipped float per-image PSNR/SSIM; arithmetic image means",
                "validation_max_per_image_tolerance": TOLERANCES,
                "gpu_preflight": {"utilization_percent": utilization, "free_mib": free_mib,
                                  "permitted_existing_services": permitted_services},
                "limits": "Historical test exposure; scene independence unresolved; 30-epoch pilot; dimension study has one seed",
            })
            shutil.copyfile(__file__, output / "evaluate.py")
            shutil.copyfile(ROOT / "README.md", output / "README.md")
            shutil.copyfile(HELPER_PATH, output / "previous_evaluation_helpers.py")
            seed_original(0)
            dataset = base_dataset(augment=False)
            validation = helpers.batches_for(dataset, manifest, "validation")
            drifts = {}
            for item in items:
                key = item_key(item)
                directory = item_directory(output, item)
                directory.mkdir(parents=True)
                status("validation", phase=key[0], seed=key[1], condition=key[2])
                drifts[key] = validate(item, validation, names["validation"], directory)
                log(f"{key}: validation passed, max per-image drift={drifts[key]}")
            log("All 15 validation anchors passed; starting fixed test inference")
            test = helpers.batches_for(dataset, manifest, "test")
            torch.cuda.reset_peak_memory_stats()
            results, per_image, examples = [], {}, {}
            for item in items:
                key = item_key(item)
                status("test", phase=key[0], seed=key[1], condition=key[2])
                result, per_image[key], examples[key] = evaluate(item, test, names["test"], item_directory(output, item), drifts[key])
                results.append(result)
                log(f"{key}: test PSNR={result['test_psnr']:.5f}, SSIM={result['test_ssim']:.6f}; 90 prediction PNGs saved")
            summarize(results, per_image, output, names["test"])
            for seed in (0, 1, 2):
                contact_sheet(test, examples, [(c, ("H1", seed, c)) for c in CONDITIONS], output / f"comparison_H1_seed{seed}.png")
            contact_sheet(test, examples, [(f"d={d}", dimension_key(d)) for d in DIMENSIONS], output / "comparison_dimensions_seed0.png")
            for item in items:
                directory = Path(item["checkpoint"]).parent
                if (digest(item["checkpoint"]) != item["checkpoint_sha256"]
                        or digest(item["validation_csv"]) != item["validation_csv_sha256"]
                        or digest(directory / "complete.json") != item["complete_sha256"]):
                    raise ValueError("Training artifacts changed during evaluation")
            status("complete", unique_checkpoints=15, test_predictions=1350)
            log("Complete: 15 unique checkpoints, 1350 predictions; training artifacts unchanged")
            atomic_json(output / "complete.json", {"utc": utc(), "elapsed_seconds": time.perf_counter() - started,
                                                   "unique_checkpoints": 15, "logical_study_cells": 16, "test_predictions": 1350,
                                                   "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                                                   "resource_scope": "Model loading and test inference; not a latency benchmark",
                                                   "artifact_hashes": {str(p.relative_to(output)): digest(p) for p in output.rglob("*") if p.is_file()}})
    except BaseException as error:
        status("failed", error=repr(error))
        atomic_json(output / "failure.json", {"utc": utc(), "error": repr(error)})
        raise


if __name__ == "__main__":
    main()
