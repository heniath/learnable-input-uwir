# UWIR new-run analysis — 15 October 2026

The U-Net learned-map gain repeats in both new seeds. The predeclared bounded-map screen passes against RGB and the parameter-matched control. This establishes repeatability under this diagnostic recipe; generalization and physical interpretation remain open.

Experiment: `unet_map_replication_v1`. Eight new diagnosed runs (seeds 1 and 2); seed 0 remains historical. All scores use the same validation80, with checkpoints selected on those images. Frozen split: 720/80/90, duplicate grouping, 256-pixel preprocessing/crops, paired initialization/augmentation, AdamW, L1+VGG, original early stopping and scheduler. No test predictions were computed.

## New-seed results

Mean ± sample SD across two seeds; SD is seed variability.

| Condition | PSNR (dB) | SSIM |
|---|---:|---:|
| rgb | 21.1124 ± 0.1520 | 0.889739 ± 0.002207 |
| bounded | 22.7724 ± 0.0258 | 0.914704 ± 0.000986 |
| unbounded | 22.7604 ± 0.0780 | 0.914883 ± 0.000385 |
| capacity | 21.0617 ± 0.1070 | 0.892595 ± 0.001233 |

Bounded gains over RGB are +1.5342/+1.7857 dB and +0.022707/+0.027223 SSIM in seeds 1/2; against capacity they are +1.6167/+1.8045 dB and +0.022283/+0.021934. The mean gains are +1.6599 dB over RGB and +1.7106 dB over capacity. Historical seed 0 showed +1.5713 dB over RGB, consistent in direction but separate in origin.

Capacity versus RGB changes PSNR by −0.0825/−0.0189 dB. Added parameters in this particular residual control do not reproduce the gain; architecture, conditioning and optimization are still confounded.

Bounded versus unbounded changes PSNR by −0.0614/+0.0854 dB (mean +0.0120); SSIM also changes sign. Output bounds have no consistent advantage in these two seeds. This is not evidence of equivalence. Bounded remains primary because it was predeclared.

## Image-level benefit and failures

| Contrast | Seed | PSNR mean | Median | 10% trimmed mean | PSNR wins / 80 |
|---|---:|---:|---:|---:|---:|
| bounded vs rgb | 1 | +1.5342 | +1.4504 | +1.4465 | 55 |
| bounded vs capacity | 1 | +1.6167 | +1.5185 | +1.5093 | 54 |
| bounded vs rgb | 2 | +1.7857 | +1.4828 | +1.8232 | 59 |
| bounded vs capacity | 2 | +1.8045 | +1.7853 | +1.8212 | 58 |

The median and trimmed mean remain positive, so the average improvement is not driven solely by a few large wins. Bounded is worse than RGB on the same 17 images in both new seeds. The largest recurring regressions are:

| Image | Seed 1 ΔPSNR | Seed 2 ΔPSNR |
|---|---:|---:|
| 809_img_.png | -6.8766 | -6.7760 |
| 661_img_.png | -4.6260 | -7.2955 |
| 490_img_.png | -4.3046 | -6.6175 |
| 806_img_.png | -2.3753 | -4.8195 |
| 370_img_.png | -3.5852 | -2.1357 |

These filenames identify cases for visual inspection; their content and failure cause have not been visually diagnosed. Do not infer color, scene, or degradation categories from PSNR alone.

## Convergence and numerical behavior

The advantage is already present at epoch 20 and survives shared observed horizons. These are best-so-far validation scores, rather than new fixed-budget training conditions.

| Seed | Shared horizon | Bounded − RGB (dB) | Bounded − capacity (dB) |
|---|---:|---:|---:|
| 1 | 20 | +1.6963 | +1.8850 |
| 1 | 50 | +1.6659 | +1.7403 |
| 1 | 96 | +1.5342 | +1.6167 |
| 2 | 20 | +1.9830 | +1.8630 |
| 2 | 50 | +1.5631 | +1.5806 |
| 2 | 81 | +1.7857 | +1.8045 |

Selected epochs: bounded 93/72, unbounded 93/72, RGB 76/66, capacity 76/61 (seeds 1/2). All selected checkpoints occur within their seed's all-condition shared horizon, so the final advantage cannot be explained solely by extra late map epochs. Seed 1 map runs hit the 100-epoch cap; full convergence is not established.

All saved epoch losses and validation metrics are finite. The training log records 16 AMP overflow skips across 743 epochs; per-run counts are in analysis.json. Skips alter the successful-update count and should remain part of provenance. GPU continuation was not bitwise deterministic in the saved smoke checks; restoration and metric agreement passed their declared tolerances. No new CUDA smoke or inference was run for this analysis.

At PSNR-selected checkpoints, CIEDE2000 decreases from RGB's 10.779/11.067 to bounded's 9.072/8.964. This is a supportive secondary color-error observation on the same selected validation data, not an independent evaluation.

## What the interventions support

Change from normal bounded inference; negative is worse.

| Intervention | Seed 1 ΔPSNR | Seed 2 ΔPSNR | Seed 1 ΔSSIM | Seed 2 ΔSSIM |
|---|---:|---:|---:|---:|
| spatial_permutation | -0.3226 | -0.1604 | -0.028473 | -0.013701 |
| spatial_mean | -0.2036 | -0.1173 | -0.003916 | -0.001728 |
| cross_image_swap | -5.3797 | -5.4614 | -0.100796 | -0.101753 |

Inference: the trained model uses image-specific conditioning and is sensitive to spatial arrangement. Cross-image swapping changes both spatial and global branches; spatial averaging preserves image-specific spatial-channel means and the global branch. Thus these interventions cannot isolate the global branch's contribution. Their distribution shift also prevents treating the score drop as a clean causal effect or a physical-map validation. Spatial sensitivity is modest in PSNR, motivating separate global-only and spatial-only comparisons.

## Resource tradeoff

Latency is the mean of two run medians, batch-1 float32 GPU forward at 256×256; it excludes preprocessing, transfer and metrics. VRAM is peak allocated training memory, not driver memory.

| Condition | Parameters | Conv GMACs | Forward ms | Peak allocated GiB | Mean epoch s |
|---|---:|---:|---:|---:|---:|
| rgb | 31,384,963 | 55.692 | 8.793 | 1.593 | 20.60 |
| bounded | 31,418,409 | 56.675 | 8.946 | 1.714 | 21.44 |
| unbounded | 31,418,409 | 56.675 | 9.090 | 1.712 | 21.43 |
| capacity | 31,418,291 | 57.865 | 9.226 | 1.733 | 21.83 |

Bounded adds 33,446 parameters (+0.107%), 0.983 conv GMACs (+1.77%), and 0.121 GiB allocated VRAM. Its observed forward overhead is 1.74%; this small timing difference needs repeated profiling before a strong speed claim. Capacity differs by 118 parameters from bounded but uses more convolution compute. Parameter matching does not match architecture or compute.

Eight new runs used 4.401 summed epoch-hours (training plus validation; excludes setup and checkpoint writes).

## Research decision and next evidence

Advance the bounded-map hypothesis under this U-Net recipe. A defensible claim is: learned local/global conditioning improves this U-Net's validation PSNR and SSIM across both new seeds and the historical seed, beyond this particular added-parameter control.

The previous NAFNet experiments remain a limitation: random bounded maps lost 0.614 dB to RGB at seed 0; zero initialization recovered 0.338 dB but remained 0.276 dB below RGB. The current U-Net replication does not resolve that cross-backbone limitation. Published fixed-prior test scores use a different representation and protocol and cannot be compared numerically with these validation scores.

Recommended order for separately authorized, frozen follow-up work:

1. Inspect the recurring failure images and their saved-model outputs; retain all failures in reporting.
2. Test global-only and spatial-only conditioning against the same RGB and capacity controls, preserving the split, recipe and seeds. This isolates a clearer mechanism before adding modules.
3. Compare fixed and learned representations with controlled channel count and spatial/global structure, since the prior paper already studies fixed-prior input ablations.
4. Freeze the method and evaluate on audited independent data before any generalization claim. The historical UIEB test has previously been inspected and should not serve as a fresh untouched confirmation set.

Evidence limits: only two new seeds; checkpoints selected on validation80; 79 unique decoded validation inputs, including an exact-input duplicate pair; scene independence unverified; one shared U-Net-derived training recipe; no physical-map supervision; intervention distribution shift. Image×seed rows are repeated observations, not independent experimental units. No significance, equivalence, state-of-the-art, or novelty claim is supported by this screen alone.

## Verification and reproducibility

Recomputed all new-seed means/SDs, paired image differences, selected epochs and common-horizon scores from saved files. Verified 9 sealed report hashes, 118 live-source hashes, 118 snapshot hashes, 12 selected-checkpoint hashes, and 27 diagnostic artifact hashes; manifest and historical-reference hashes also match. All 12 run histories are contiguous and finite and their selected metrics agree with per-image diagnostic means within frozen tolerances.

Reproduce with `python3 analyses/2026-10-15/analysis.py` from the project root. Uses only Python's standard library, hashes checkpoint bytes without loading tensors, and writes only this supplementary directory. No training/inference, live dataset rehash, dependency installation, or run-report regeneration. The existing saved preflight supplies the initialization/augmentation/environment checks; it was not rerun. `analysis.json` contains full computed details, audit scope and this script's hash.
