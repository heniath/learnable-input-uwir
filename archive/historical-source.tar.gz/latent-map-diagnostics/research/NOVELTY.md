# Novelty comparison — 2026-10-13

Full-text method/experiment inspection, using the nature-academic-search
multi-source-search workflow. Academic MCP services were unavailable. Public
endpoint preflight passed, but OpenAlex retrieval failed DNS resolution; primary
arXiv HTML and the publisher's public CPLDP PDF supplied the comparison. The web
PDF reader failed for CPLDP; direct public download and `pdftotext` succeeded.
This is a targeted comparison, not an exhaustive novelty clearance.

| Work | Conditioning and injection | Supervision | Controls and generalization relevant here |
|---|---|---|---|
| [Ucolor, TIP 2021](https://arxiv.org/html/2104.13015v1), §§III-D/E, IV-B/E | Prior-estimated reverse transmission weights decoder features; RGB/HSV/Lab encoders and channel attention | Paired pixel loss plus VGG19 perceptual loss | Guidance removal/replacement and repeated RGB encoders; real/synthetic reference tests and additional non-reference/color benchmarks. Our learned six-channel input representation differs, but transmission guidance and extra-input controls are established. |
| [CPLDP, AAAI 2026](https://ojs.aaai.org/index.php/AAAI/article/view/38176), Method/Experiments, pp.11894–11897 | Five degradation-specific prompts and positive-reference prompts learned with frozen CLIP encoders; prompt projection/concatenation into intermediate features | Prompt classification/reference learning, then frozen prompt module; pixel/reference-prompt and adaptive degradation losses | Prompt/component ablations; UIEB full-reference and U45/UCCS non-reference comparisons. Our heads require no text encoder or degradation labels, but image-dependent degradation conditioning is established. |
| [PROTEUS, August 2026 preprint](https://arxiv.org/html/2608.08661v1), Method; Table 4; Supplementary spatial-guidance analysis | Gray-Edge guide drives deformable cross-attention/feature modulation; bottleneck control code generates channel-wise skip gates | Paired restoration and reference-latent, orthogonality, contrastive and consistency regularization | Module/loss ablations, uniform/cross-image guide interventions, and cross-dataset controls. This directly overlaps generic degradation-guided latent-control claims; our interventions are standard diagnostics, not a proposed novelty. |

The diagnostic study uses paired shared initialization, bounded/unbounded
versions of the same original heads, a parameter-matched feature branch, and two
backbones under one frozen recipe. Those controls improve evidence for this
local hypothesis; they do not by themselves constitute a new enhancement method.

## Claim boundaries and next decision

- Current claim: the historical seed-0 U-Net gain reproduced locally. General
  map utility, physical interpretation and novelty remain unestablished.
- Passing this stage supports further investigation of a specific representation
  under this recipe. A strong method paper still needs a demonstrably distinct
  mechanism, repeated-seed evidence, suitable current baselines and independently
  audited generalization evaluation.
- Bounds are an optimization/representation choice, not supervision identifying
  physical parameters. Swaps or permutation can create out-of-distribution
  inputs; sensitivity cannot prove disentanglement or physical semantics.
- If a variant passes the frozen screen, test the hypothesis that its advantage
  over the capacity control repeats on both backbones and a fresh underwater
  benchmark. Decide any new mechanism after reviewing the evidence and an
  expanded full-text/code comparison.
- If it fails, test backbone/optimization dependence before adding modules.
  Do not rebrand a U-Net-only gain as general degradation conditioning.

No paper scores are combined with local scores: split, preprocessing, supervision,
metrics and training resources differ. PROTEUS is identified as a preprint;
its reported comparisons were inspected as author evidence, not reproduced here.

The public CPLDP PDF is retained at `papers/CPLDP.pdf`, SHA-256
`c4b248e21ba813b7d092ddbb0b0bb4a4ec500c1ffb21e380da5c636e9ff27713`.
Its extracted text is retained for traceability. All local research files are
hashed into the diagnostic source snapshot before training.
