# U-Net UIEB test inference

Separate evaluation of the completed diagnostic seed-0 and replication seed-1/2
U-Net checkpoints. The user requested test inference on 2026-10-21. Existing
studies remain unchanged; this evaluation extends their validation-only scope.

Run with the existing environment from this directory:

```bash
/home/heniath/miniforge3/envs/uieb-latent-repro/bin/python scripts/evaluate.py
```

The runner verifies the inherited frozen environment/source/data manifest and
checkpoint hashes, then reproduces all 80 validation-image metrics for each
checkpoint before evaluating the fixed historical 90-image test partition.
It evaluates RGB, bounded maps, unbounded maps and capacity controls at all three
seeds with inherited float32 inference and 256-pixel resize/center-crop metrics.
Historical seed 0 is distinguished from the two replication seeds in reports.
There is no training, tuning, checkpoint selection, TTA or ensembling.

Outputs under `outputs/unet_uieb_test90_v1/` include per-image CSVs, per-seed and
cross-seed summaries, paired differences, checkpoint/source/environment identities,
validation reproduction drift, a persistent log, and six fixed PNG examples per
checkpoint with contact sheets. PNG quantization does not affect float metrics.
A completed or partial output directory is never overwritten; use a distinct
`--run-id` for another execution. Exceptions are retained in `failure.json`.

These are historical test results with prior exposure, not previously unseen
native-resolution benchmark scores. Inherited scene-independence limits remain.
