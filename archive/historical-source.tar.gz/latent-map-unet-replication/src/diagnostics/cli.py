"""Headless CLI with explicit run identities and validation-only diagnostics."""

import argparse
import fcntl

from .protocol import config, output_root


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("prepare", "smoke", "diagnose", "report"):
        commands.add_parser(name)
    train = commands.add_parser("train")
    train.add_argument("--backbone", choices=config()["backbones"], required=True)
    train.add_argument("--condition", choices=config()["conditions"], required=True)
    train.add_argument(
        "--model-seed", type=int, choices=config()["model_seeds"], required=True
    )
    args = parser.parse_args()
    output_root().mkdir(parents=True, exist_ok=True)
    lock_name = ".report.lock" if args.command == "report" else ".operation.lock"
    with (output_root() / lock_name).open("a") as lock:
        flags = (
            fcntl.LOCK_EX if args.command == "report" else fcntl.LOCK_EX | fcntl.LOCK_NB
        )
        fcntl.flock(lock, flags)
        if args.command == "prepare":
            from .audit import prepare

            prepare()
        elif args.command == "smoke":
            from .validation import smoke

            smoke()
        elif args.command == "train":
            from .engine import train

            train(args.backbone, args.condition, args.model_seed)
        elif args.command == "diagnose":
            from .diagnose import diagnose

            diagnose()
        else:
            from .report import report

            report()
