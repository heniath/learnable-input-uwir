import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from .utils import PROJECT_ROOT, atomic_json, load_config


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Controlled latent-map enhancement experiments"
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "configs/protocol.yaml"
    )
    parser.add_argument(
        "--data-root",
        type=Path,
        help="Override dataset root; paths inside manifests stay relative",
    )
    parser.add_argument(
        "--output-root", type=Path, help="Defaults to outputs/<experiment_id>"
    )
    parser.add_argument("--manifest-dir", type=Path, default=PROJECT_ROOT / "manifests")
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("prepare")
    commands.add_parser("verify-data")
    commands.add_parser("smoke")
    commands.add_parser("summarize")
    train_parser = commands.add_parser("train")
    evaluate_parser = commands.add_parser("evaluate")
    for sub in (train_parser, evaluate_parser):
        sub.add_argument(
            "--dataset", choices=("lolv2_real", "uieb", "lsui"), required=True
        )
        sub.add_argument(
            "--condition",
            choices=("rgb", "zero_maps", "learned_maps", "capacity"),
            required=True,
        )
        sub.add_argument("--seed", type=int, required=True)
    stage_parser = commands.add_parser("run-stage")
    stage_parser.add_argument(
        "--stage", choices=("initial", "extension", "all"), default="initial"
    )
    args = parser.parse_args(argv)
    config = load_config(args.config)
    if args.data_root:
        config["data_root"] = str(args.data_root.resolve())
    output_root = args.output_root or PROJECT_ROOT / "outputs" / config["experiment_id"]
    manifest_dir = args.manifest_dir
    from .data import load_manifest, prepare_manifest
    from .report import cross_dataset_audit, summarize

    datasets = [name for names in config["stages"].values() for name in names]
    if args.command == "prepare":
        manifests = {}
        for name in datasets:
            print(f"Auditing {name}", flush=True)
            manifests[name] = prepare_manifest(
                config["data_root"],
                name,
                config["split"][name],
                config["split"]["seed"],
                manifest_dir / f"{name}.json",
            )
            print(f"{name}: {manifests[name]['split_counts']}", flush=True)
        cross_dataset_audit(manifests, manifest_dir / "cross_dataset_audit.json")
        return
    if args.command == "verify-data":
        # Explicit full-content verification also detects edits that preserve stat metadata.
        from .utils import digest

        for name in datasets:
            m = load_manifest(manifest_dir / f"{name}.json", config["data_root"])
            for r in m["pairs"]:
                for role in ("input", "reference"):
                    if (
                        digest(Path(config["data_root"]) / r[role])
                        != r[role + "_identity"]["sha256"]
                    ):
                        raise ValueError(f"Content changed: {r[role]}")
            print(f"Verified every file: {name}", flush=True)
        return
    if args.command == "summarize":
        summarize(config, output_root)
        print(output_root / "reports/FINDINGS.md")
        return
    # cuBLAS requires this before CUDA context creation for deterministic algorithms.
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    import torch

    from .engine import evaluate_run, freeze_experiment, smoke, train

    device_name = (
        "cuda" if args.device == "auto" and torch.cuda.is_available() else args.device
    )
    device_name = "cpu" if device_name == "auto" else device_name
    if device_name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    device = torch.device(device_name)
    if args.command == "smoke":
        manifests = {
            name: load_manifest(manifest_dir / f"{name}.json", config["data_root"])
            for name in datasets
        }
        destination = (
            output_root.parent
            / ("smoke_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f"))
            / "resources.json"
        )
        report = smoke(config, manifests, device, destination)
        print(json.dumps(report, indent=2))
        print(f"Saved smoke report: {destination}")
        return
    manifests = freeze_experiment(config, output_root, manifest_dir)
    cross_dataset_audit(manifests, output_root / "cross_dataset_audit.json")
    if args.command in ("train", "evaluate"):
        if (
            args.seed not in config["seeds"]
            or args.condition not in config["conditions"]
        ):
            raise ValueError("Seed/condition is outside the frozen comparison")
        directory = (
            output_root / "runs" / args.dataset / args.condition / f"seed_{args.seed}"
        )
        if args.command == "train":
            train(
                config,
                manifests[args.dataset],
                args.condition,
                args.seed,
                directory,
                device,
            )
        else:
            evaluate_run(config, manifests[args.dataset], directory, device)
        summarize(config, output_root)
        return
    stages = ("initial", "extension") if args.stage == "all" else (args.stage,)
    for stage in stages:
        stage_runs = [
            (name, condition, seed)
            for name in config["stages"][stage]
            for seed in config["seeds"]
            for condition in config["conditions"]
        ]
        for name, condition, seed in stage_runs:
            # Recheck the frozen identity between runs, including after long jobs.
            freeze_experiment(config, output_root, manifest_dir)
            directory = output_root / "runs" / name / condition / f"seed_{seed}"
            train(config, manifests[name], condition, seed, directory, device)
            torch.cuda.empty_cache() if device.type == "cuda" else None
            summarize(config, output_root)
        # Held-out test scores are computed after every run in this stage has trained.
        atomic_json(
            output_root / f"{stage}_training_complete.json", {"runs": len(stage_runs)}
        )
        for name, condition, seed in stage_runs:
            evaluate_run(
                config,
                manifests[name],
                output_root / "runs" / name / condition / f"seed_{seed}",
                device,
            )
            torch.cuda.empty_cache() if device.type == "cuda" else None
            summarize(config, output_root)
        atomic_json(
            output_root / f"{stage}_complete.json", {"evaluated_runs": len(stage_runs)}
        )


if __name__ == "__main__":
    main()
