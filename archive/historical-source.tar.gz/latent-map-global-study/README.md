# Global branch follow-up

User-authorized follow-up: H1 paired-seed confirmation, global-vector diagnostics,
and an initial d=1/3/6/12 global-only dimension screen. Existing H1/H2 and test
artifacts remain unchanged. Use the existing `uieb-latent-repro` environment.

H1 seed 0 is reused. The new H1 config `../latent-map-conditioning/configs/h1_pilot_seeds12_v2.json`
inherits exactly the 30-epoch pilot budget (first 30 epochs of the 100-epoch
cosine schedule, no early stopping), 720/80 split, paired augmentation,
initialization, losses, optimizer and validation checkpoint selection. Existing
100-epoch/early-stopped replication runs are not interchangeable with this pilot.
All four H1 conditions are repeated at seeds 1/2; RGB, global and joint maps
are prioritized. No old source or frozen config is edited.

For the initial dimension screen, d=3 reuses H1 global-only and d=1/6/12
are new seed-0 runs with the same recipe. The only architectural factor varied
is the global-vector width and corresponding input/head dimensions. Shared
parameters retain H1 initialization; new coordinates have isolated initialization.
The three spatial input slots remain zero. Parameter/MAC counts are recorded;
this is not a parameter-matched experiment. The seed-0 screen does not establish
cross-seed dimension effects. It is kept separate from H1's three-seed summary.

For each H1 global-only/joint checkpoint, diagnostics record G on all 720
training and 80 validation images in eval mode without augmentation. They save
coordinate means, SDs, ranges, saturation, covariance/SVD/effective rank and
descriptive near-constant flags. Thresholds are prespecified in the config;
continuous measurements remain primary, and small variation alone is not
evidence of irrelevance. Each model's training-only mean G replaces G on
validation, keeping its spatial map and weights fixed. Normal validation must
reproduce the saved selected scores before interpreting an intervention.
The same diagnostics apply to newly trained dimensions.

All new conclusions use validation; previously inspected test results are not
used to choose dimensions or remove spatial features. Reports keep seed and
image units distinct, report paired seed gains and sample SD, and make no
scene-independent confidence interval or physical-map claim. Spatial-branch
removal, revision or retention remains an explicit later research decision.

```bash
python -B -m unittest discover -s tests -v
python -B scripts/run.py prepare
python -B scripts/run.py smoke
python -B scripts/run.py diagnose --phase H1 --condition A2_global --seed 0
python -B scripts/run.py train-dimension --dimension 1 --seed 0
python -B scripts/run.py report
python -B scripts/run_logged.py
```

Run the logged pipeline in tmux. It preserves completed runs, resumes dimension
training from full optimizer/scheduler/scaler/early-stopping/RNG checkpoints,
records job status and persistent logs, and stops on failure without changing
batch size or protocol. Completed diagnostic artifacts and training runs are
hash-verified before reuse. Frozen source/config/environment changes require a
new experiment identity. CUDA trajectories are not guaranteed bitwise replayable.

Before smoke/training, the runner waits while another GPU compute process is
active (the existing GNOME remote desktop service is exempt). It checks every
30 seconds and writes `waiting_for_gpu` to job status. After explicit user
authorization, an output-local `gpu_policy.json` with `allow_shared_gpu: true`
may release this wait; the effective policy and active processes are logged.
No existing process is stopped by the runner. Runtime under shared use is not
interpreted as an isolated performance benchmark.
