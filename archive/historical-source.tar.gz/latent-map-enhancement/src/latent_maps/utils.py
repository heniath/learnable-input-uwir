import hashlib
import json
import os
import random
from pathlib import Path

import numpy as np
import torch
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def load_config(path=None):
    with open(path or PROJECT_ROOT / "configs/protocol.yaml") as f:
        return yaml.safe_load(f)


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    os.replace(temporary, path)


def atomic_checkpoint(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temporary)
    os.replace(temporary, path)


def seed_everything(seed, deterministic=True):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(deterministic)
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False


def rng_state():
    return {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
    }


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"].cpu())
    if state["cuda"]:
        torch.cuda.set_rng_state_all([s.cpu() for s in state["cuda"]])


def source_state():
    import subprocess

    files = sorted(
        p
        for p in PROJECT_ROOT.rglob("*")
        if p.is_file()
        and p.suffix in {".py", ".yaml", ".toml"}
        and not any(
            part in {"outputs", ".pytest_cache", "__pycache__"} for part in p.parts
        )
    )
    hashes = {str(p.relative_to(PROJECT_ROOT)): digest(p) for p in files}

    def git(args):
        result = subprocess.run(
            ["git", "-C", str(PROJECT_ROOT), *args],
            capture_output=True,
            text=True,
            check=False,
        )
        return result.stdout.strip() if result.returncode == 0 else None

    return {
        "files": hashes,
        "sha256": canonical_hash(hashes),
        "git_commit": git(["rev-parse", "HEAD"]),
        "git_status": git(["status", "--short"]),
        "upstream": json.loads(
            (PROJECT_ROOT / "third_party/nafnet/SOURCE.json").read_text()
        ),
    }


def environment():
    import importlib.metadata
    import platform
    import subprocess

    driver = None
    if torch.cuda.is_available():
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
            capture_output=True,
            text=True,
            check=False,
        )
        driver = result.stdout.strip() if result.returncode == 0 else None

    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "packages": {
            p: importlib.metadata.version(p)
            for p in ("torch", "numpy", "Pillow", "PyYAML")
        },
        "cuda_runtime": torch.version.cuda,
        "cudnn_version": torch.backends.cudnn.version(),
        "driver_version": driver,
        "gpu": torch.cuda.get_device_name() if torch.cuda.is_available() else None,
        "deterministic_note": "Deterministic algorithms are required; replay across hardware/framework versions is not guaranteed.",
    }


def snapshot_source(directory):
    import shutil

    state = source_state()
    target = Path(directory)
    for rel in state["files"]:
        dest = target / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(PROJECT_ROOT / rel, dest)
    shutil.copytree(
        PROJECT_ROOT / "third_party", target / "third_party", dirs_exist_ok=True
    )
    return state
