"""Read-only audit of completed UWIR artifacts; standard library only.

Run: python3 analyses/2026-10-15/analysis.py
Writes supplementary analysis beside this script, outside the frozen run.
"""

import csv
import hashlib
import json
import math
import re
import statistics as st
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RUN = ROOT / "outputs/unet_map_replication_v1"


def read_json(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def check_hashes(base, hashes):
    failures = [name for name, expected in hashes.items() if digest(base / name) != expected]
    assert not failures, (base, failures)
    return len(hashes)


def main():
    report_dir = RUN / "reports"
    results = read_json(report_dir / "results.json")
    marker = read_json(report_dir / "report_complete.json")
    assert marker["complete"] and results["complete"]
    checks = {"report_hashes": check_hashes(report_dir, marker["artifact_hashes"])}
    frozen = read_json(RUN / "frozen_protocol.json")
    checks["live_source_hashes"] = check_hashes(ROOT, frozen["source_hashes"])
    checks["snapshot_source_hashes"] = check_hashes(RUN / "source_snapshot", frozen["source_hashes"])
    manifest = read_json(RUN / "manifest.json")
    # The protocol hashes canonical JSON for the manifest, file bytes elsewhere.
    assert hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest() == frozen["manifest_sha256"]
    assert digest(RUN / "historical_reference.json") == frozen["historical_reference_sha256"]
    expected_names = {x["filename"] for x in manifest["pairs"] if x["split"] == "validation"}
    assert len(expected_names) == 80
    histories, image_scores, diagnostics = {}, {}, {}
    checkpoints = 0
    diagnostic_artifacts = 0
    for row in results["runs"]:
        key = (row["condition"], row["seed"])
        directory = Path(row["directory"])
        history = read_json(directory / "history.json")
        assert [x["epoch"] for x in history] == list(range(1, row["epochs"] + 1))
        assert all(x["validation_count"] == 80 for x in history)
        assert all(math.isfinite(v) for x in history for v in
                   (x["train_loss"], x["val_loss"], *x["validation"].values()))
        best = max(history, key=lambda x: (x["validation"]["psnr"], x["validation"]["ssim"]))
        assert best["epoch"] == row["selected_epoch"]
        diagnostic = read_json(directory / "diagnostics.json")
        assert digest(directory / "best.pt") == diagnostic["checkpoint_sha256"] == row["checkpoint_sha256"]
        checkpoints += 1
        diagnostic_artifacts += check_hashes(directory, diagnostic["artifact_hashes"])
        scores = read_csv(directory / "per_image_validation_normal.csv")
        assert len(scores) == 80 and {x["filename"] for x in scores} == expected_names
        for metric, tolerance in (("psnr", 0.001), ("ssim", 0.00001)):
            mean = st.mean(float(x[metric]) for x in scores)
            assert abs(mean - row[f"val_{metric}"]) < 1e-8
            assert abs(mean - best["validation"][metric]) < tolerance
        histories[key], diagnostics[key] = history, diagnostic
        image_scores[key] = {x["filename"]: {m: float(x[m]) for m in ("psnr", "ssim")} for x in scores}
    checks.update(checkpoint_hashes=checkpoints, diagnostic_artifact_hashes=diagnostic_artifacts,
                  manifest_hash=True, historical_reference_hash=True,
                  contiguous_finite_histories=True, selected_epochs_and_metrics=True,
                  validation_names_and_means=True)
    new = [x for x in results["runs"] if x["origin"] == "new"]
    assert len(new) == results["completed_new_training_runs"] == results["diagnosed_new_runs"] == 8
    aggregates = [x for x in results["aggregates"] if x["scope"] == "new_seeds_1_2"]
    for a in aggregates:
        rows = [x for x in new if x["condition"] == a["condition"]]
        for metric in ("psnr", "ssim"):
            assert abs(st.mean(x[f"val_{metric}"] for x in rows) - a[f"{metric}_mean"]) < 1e-10
            assert abs(st.stdev(x[f"val_{metric}"] for x in rows) - a[f"{metric}_sample_sd"]) < 1e-10
    paired = []
    for seed in (1, 2):
        for condition, baseline in (("bounded", "rgb"), ("bounded", "capacity"),
                                    ("unbounded", "rgb"), ("unbounded", "capacity"),
                                    ("bounded", "unbounded")):
            delta = {name: {m: image_scores[condition, seed][name][m] - image_scores[baseline, seed][name][m]
                            for m in ("psnr", "ssim")} for name in sorted(expected_names)}
            values = sorted(x["psnr"] for x in delta.values())
            paired.append(dict(seed=seed, condition=condition, baseline=baseline,
                               mean_psnr=st.mean(values), median_psnr=st.median(values),
                               trimmed_mean_psnr=st.mean(values[8:-8]),
                               mean_ssim=st.mean(x["ssim"] for x in delta.values()),
                               psnr_wins=sum(x > 0 for x in values),
                               ssim_wins=sum(x["ssim"] > 0 for x in delta.values()),
                               worst_five=[dict(filename=name, **delta[name]) for name in sorted(delta, key=lambda n: delta[n]["psnr"])[:5]]))
    horizon_rows = read_csv(report_dir / "common_horizon_scores.csv")
    horizons = []
    for seed in (1, 2):
        shared = min(len(histories[c, seed]) for c in ("rgb", "bounded", "unbounded", "capacity"))
        for epoch in (20, 50, shared):
            best = {c: max(histories[c, seed][:epoch], key=lambda x: (x["validation"]["psnr"], x["validation"]["ssim"]))["validation"]["psnr"]
                    for c in ("rgb", "bounded", "unbounded", "capacity")}
            for c in best:
                saved = next(x for x in horizon_rows if int(x["seed"]) == seed and x["condition"] == c and int(x["horizon_epoch"]) == epoch)
                assert abs(float(saved["best_psnr"]) - best[c]) < 1e-10
            horizons.append(dict(seed=seed, epoch=epoch, psnr=best,
                                 bounded_vs_rgb=best["bounded"]-best["rgb"],
                                 bounded_vs_capacity=best["bounded"]-best["capacity"]))
    skips, current = Counter(), None
    for line in (RUN / "training.log").read_text().splitlines():
        start = re.match(r"unet/(\w+): seed (\d+);", line)
        if start:
            current = (start[1], int(start[2]))
        if "[AMP] skipped batch" in line:
            assert current is not None
            skips[current] += 1
    resources = []
    for condition in ("rgb", "bounded", "unbounded", "capacity"):
        rows = [x for x in new if x["condition"] == condition]
        resources.append(dict(condition=condition, parameters=rows[0]["parameters"],
                              conv_gmacs=rows[0]["conv_gmacs"],
                              mean_of_run_median_ms=st.mean(x["inference_median_ms"] for x in rows),
                              max_training_allocated_gib=max(x["peak_allocated_gib"] for x in rows),
                              mean_epoch_seconds=st.mean(st.mean(h["epoch_seconds"] for h in histories[condition, s]) for s in (1, 2))))
    stable_failures = []
    for name in sorted(expected_names):
        deltas = [image_scores["bounded", s][name]["psnr"]-image_scores["rgb", s][name]["psnr"] for s in (1, 2)]
        if all(v < 0 for v in deltas):
            stable_failures.append(dict(filename=name, seed_1=deltas[0], seed_2=deltas[1], mean=st.mean(deltas)))
    stable_failures.sort(key=lambda x: x["mean"])
    selected_metrics = [dict(condition=x["condition"], seed=x["seed"],
                             **histories[x["condition"], x["seed"]][x["selected_epoch"]-1]["validation"]) for x in new]
    audit = dict(generated_utc=datetime.now(timezone.utc).isoformat(), experiment_id=frozen["config"]["experiment_id"],
                 analysis_source_sha256=digest(Path(__file__)), checks=checks,
                 new_seed_aggregates=aggregates, paired=paired, common_horizons=horizons,
                 bounded_interventions=[x for x in results["bounded_intervention_deltas"] if x["origin"] == "new"],
                 resources=resources, stable_bounded_vs_rgb_failures=stable_failures,
                 selected_epoch_secondary_metrics=selected_metrics,
                 amp_skips=[dict(condition=x["condition"], seed=x["seed"], logged_skips=skips[x["condition"], x["seed"]]) for x in new],
                 total_epoch_hours=sum(x["epoch_hours"] for x in new),
                 validation_unique_input_hashes=len({x["input"]["decoded_sha256"] for x in manifest["pairs"] if x["split"] == "validation"}),
                 scope="Saved artifacts audited; no training, inference, live data rehash, or environment modification.")
    (HERE / "analysis.json").write_text(json.dumps(audit, indent=2, allow_nan=False) + "\n")
    lines = ["# UWIR new-run analysis — 15 October 2026", "",
             "The U-Net learned-map gain repeats in both new seeds. The predeclared bounded-map screen passes against RGB and the parameter-matched control. This establishes repeatability under this diagnostic recipe; generalization and physical interpretation remain open.", "",
             "Experiment: `unet_map_replication_v1`. Eight new diagnosed runs (seeds 1 and 2); seed 0 remains historical. All scores use the same validation80, with checkpoints selected on those images. Frozen split: 720/80/90, duplicate grouping, 256-pixel preprocessing/crops, paired initialization/augmentation, AdamW, L1+VGG, original early stopping and scheduler. No test predictions were computed.", "",
             "## New-seed results", "", "Mean ± sample SD across two seeds; SD is seed variability.", "",
             "| Condition | PSNR (dB) | SSIM |", "|---|---:|---:|"]
    for a in aggregates:
        lines.append(f"| {a['condition']} | {a['psnr_mean']:.4f} ± {a['psnr_sample_sd']:.4f} | {a['ssim_mean']:.6f} ± {a['ssim_sample_sd']:.6f} |")
    lines += ["", "Bounded gains over RGB are +1.5342/+1.7857 dB and +0.022707/+0.027223 SSIM in seeds 1/2; against capacity they are +1.6167/+1.8045 dB and +0.022283/+0.021934. The mean gains are +1.6599 dB over RGB and +1.7106 dB over capacity. Historical seed 0 showed +1.5713 dB over RGB, consistent in direction but separate in origin.", "",
              "Capacity versus RGB changes PSNR by −0.0825/−0.0189 dB. Added parameters in this particular residual control do not reproduce the gain; architecture, conditioning and optimization are still confounded.", "",
              "Bounded versus unbounded changes PSNR by −0.0614/+0.0854 dB (mean +0.0120); SSIM also changes sign. Output bounds have no consistent advantage in these two seeds. This is not evidence of equivalence. Bounded remains primary because it was predeclared.", "",
              "## Image-level benefit and failures", "", "| Contrast | Seed | PSNR mean | Median | 10% trimmed mean | PSNR wins / 80 |", "|---|---:|---:|---:|---:|---:|"]
    for x in paired:
        if x["condition"] == "bounded" and x["baseline"] in ("rgb", "capacity"):
            lines.append(f"| bounded vs {x['baseline']} | {x['seed']} | {x['mean_psnr']:+.4f} | {x['median_psnr']:+.4f} | {x['trimmed_mean_psnr']:+.4f} | {x['psnr_wins']} |")
    lines += ["", f"The median and trimmed mean remain positive, so the average improvement is not driven solely by a few large wins. Bounded is worse than RGB on the same {len(stable_failures)} images in both new seeds. The largest recurring regressions are:", "", "| Image | Seed 1 ΔPSNR | Seed 2 ΔPSNR |", "|---|---:|---:|"]
    for x in stable_failures[:5]:
        lines.append(f"| {x['filename']} | {x['seed_1']:+.4f} | {x['seed_2']:+.4f} |")
    lines += ["", "These filenames identify cases for visual inspection; their content and failure cause have not been visually diagnosed. Do not infer color, scene, or degradation categories from PSNR alone.", "",
              "## Convergence and numerical behavior", "", "The advantage is already present at epoch 20 and survives shared observed horizons. These are best-so-far validation scores, rather than new fixed-budget training conditions.", "", "| Seed | Shared horizon | Bounded − RGB (dB) | Bounded − capacity (dB) |", "|---|---:|---:|---:|"]
    for x in horizons:
        lines.append(f"| {x['seed']} | {x['epoch']} | {x['bounded_vs_rgb']:+.4f} | {x['bounded_vs_capacity']:+.4f} |")
    lines += ["", "Selected epochs: bounded 93/72, unbounded 93/72, RGB 76/66, capacity 76/61 (seeds 1/2). All selected checkpoints occur within their seed's all-condition shared horizon, so the final advantage cannot be explained solely by extra late map epochs. Seed 1 map runs hit the 100-epoch cap; full convergence is not established.", "",
              f"All saved epoch losses and validation metrics are finite. The training log records {sum(skips.values())} AMP overflow skips across {sum(x['epochs'] for x in new)} epochs; per-run counts are in analysis.json. Skips alter the successful-update count and should remain part of provenance. GPU continuation was not bitwise deterministic in the saved smoke checks; restoration and metric agreement passed their declared tolerances. No new CUDA smoke or inference was run for this analysis.", "",
              "At PSNR-selected checkpoints, CIEDE2000 decreases from RGB's 10.779/11.067 to bounded's 9.072/8.964. This is a supportive secondary color-error observation on the same selected validation data, not an independent evaluation.", "",
              "## What the interventions support", "", "Change from normal bounded inference; negative is worse.", "", "| Intervention | Seed 1 ΔPSNR | Seed 2 ΔPSNR | Seed 1 ΔSSIM | Seed 2 ΔSSIM |", "|---|---:|---:|---:|---:|"]
    for name in ("spatial_permutation", "spatial_mean", "cross_image_swap"):
        a, b = [next(x for x in audit["bounded_interventions"] if x["intervention"] == name and x["seed"] == s) for s in (1, 2)]
        lines.append(f"| {name} | {a['psnr_difference']:+.4f} | {b['psnr_difference']:+.4f} | {a['ssim_difference']:+.6f} | {b['ssim_difference']:+.6f} |")
    lines += ["", "Inference: the trained model uses image-specific conditioning and is sensitive to spatial arrangement. Cross-image swapping changes both spatial and global branches; spatial averaging preserves image-specific spatial-channel means and the global branch. Thus these interventions cannot isolate the global branch's contribution. Their distribution shift also prevents treating the score drop as a clean causal effect or a physical-map validation. Spatial sensitivity is modest in PSNR, motivating separate global-only and spatial-only comparisons.", "",
              "## Resource tradeoff", "", "Latency is the mean of two run medians, batch-1 float32 GPU forward at 256×256; it excludes preprocessing, transfer and metrics. VRAM is peak allocated training memory, not driver memory.", "", "| Condition | Parameters | Conv GMACs | Forward ms | Peak allocated GiB | Mean epoch s |", "|---|---:|---:|---:|---:|---:|"]
    for x in resources:
        lines.append(f"| {x['condition']} | {x['parameters']:,} | {x['conv_gmacs']:.3f} | {x['mean_of_run_median_ms']:.3f} | {x['max_training_allocated_gib']:.3f} | {x['mean_epoch_seconds']:.2f} |")
    rgb, bounded = resources[:2]
    lines += ["", f"Bounded adds 33,446 parameters (+{100*(bounded['parameters']/rgb['parameters']-1):.3f}%), {bounded['conv_gmacs']-rgb['conv_gmacs']:.3f} conv GMACs (+{100*(bounded['conv_gmacs']/rgb['conv_gmacs']-1):.2f}%), and {bounded['max_training_allocated_gib']-rgb['max_training_allocated_gib']:.3f} GiB allocated VRAM. Its observed forward overhead is {100*(bounded['mean_of_run_median_ms']/rgb['mean_of_run_median_ms']-1):.2f}%; this small timing difference needs repeated profiling before a strong speed claim. Capacity differs by 118 parameters from bounded but uses more convolution compute. Parameter matching does not match architecture or compute.", "",
              f"Eight new runs used {audit['total_epoch_hours']:.3f} summed epoch-hours (training plus validation; excludes setup and checkpoint writes).", "",
              "## Research decision and next evidence", "",
              "Advance the bounded-map hypothesis under this U-Net recipe. A defensible claim is: learned local/global conditioning improves this U-Net's validation PSNR and SSIM across both new seeds and the historical seed, beyond this particular added-parameter control.", "",
              "The previous NAFNet experiments remain a limitation: random bounded maps lost 0.614 dB to RGB at seed 0; zero initialization recovered 0.338 dB but remained 0.276 dB below RGB. The current U-Net replication does not resolve that cross-backbone limitation. Published fixed-prior test scores use a different representation and protocol and cannot be compared numerically with these validation scores.", "",
              "Recommended order for separately authorized, frozen follow-up work:", "",
              "1. Inspect the recurring failure images and their saved-model outputs; retain all failures in reporting.",
              "2. Test global-only and spatial-only conditioning against the same RGB and capacity controls, preserving the split, recipe and seeds. This isolates a clearer mechanism before adding modules.",
              "3. Compare fixed and learned representations with controlled channel count and spatial/global structure, since the prior paper already studies fixed-prior input ablations.",
              "4. Freeze the method and evaluate on audited independent data before any generalization claim. The historical UIEB test has previously been inspected and should not serve as a fresh untouched confirmation set.", "",
              f"Evidence limits: only two new seeds; checkpoints selected on validation80; {audit['validation_unique_input_hashes']} unique decoded validation inputs, including an exact-input duplicate pair; scene independence unverified; one shared U-Net-derived training recipe; no physical-map supervision; intervention distribution shift. Image×seed rows are repeated observations, not independent experimental units. No significance, equivalence, state-of-the-art, or novelty claim is supported by this screen alone.", "",
              "## Verification and reproducibility", "",
              f"Recomputed all new-seed means/SDs, paired image differences, selected epochs and common-horizon scores from saved files. Verified {checks['report_hashes']} sealed report hashes, {checks['live_source_hashes']} live-source hashes, {checks['snapshot_source_hashes']} snapshot hashes, {checkpoints} selected-checkpoint hashes, and {diagnostic_artifacts} diagnostic artifact hashes; manifest and historical-reference hashes also match. All 12 run histories are contiguous and finite and their selected metrics agree with per-image diagnostic means within frozen tolerances.", "",
              "Reproduce with `python3 analyses/2026-10-15/analysis.py` from the project root. Uses only Python's standard library, hashes checkpoint bytes without loading tensors, and writes only this supplementary directory. No training/inference, live dataset rehash, dependency installation, or run-report regeneration. The existing saved preflight supplies the initialization/augmentation/environment checks; it was not rerun. `analysis.json` contains full computed details, audit scope and this script's hash.", ""]
    (HERE / "ANALYSIS.md").write_text("\n".join(lines))
    print(json.dumps({"checks": checks, "amp_skips": audit["amp_skips"],
                      "stable_failure_count": len(stable_failures),
                      "report": str(HERE / "ANALYSIS.md")}, indent=2))


if __name__ == "__main__":
    main()
