#!/usr/bin/env python3
"""Run from any working directory, using the existing uieb-latent-repro environment."""

import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT.parent / "latent-map-diagnostics"
sys.path[:0] = [str(ROOT / "src"), str(PARENT / "src"), str(PARENT / "third_party/upstream/src"), str(PARENT / "third_party/nafnet")]

from conditioning.experiment import main

if __name__ == "__main__":
    main()
