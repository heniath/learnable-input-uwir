# Original UIEB latent-map reproduction

Two seed-0 conditions: original RGB U-Net and original latent-map U-Net with reconstruction and smoothness weights zero. Source is pinned to `d9d28626cf32308fd6d57fd0c2f9ab39623cea60` from <https://github.com/heniath/underwater-image-enhancement>. The full unmodified checkout and its license remain in `third_party/upstream/`.

Use the dedicated Conda environment `uieb-latent-repro`, cloned from `ml-base`. Only scikit-image 0.25.2, Kornia 0.7.3 and missing transitive dependencies were added. Core packages are constrained in `constraints.txt`; prepare freezes every resolved package and a Conda explicit specification. The exact torchvision VGG16 ImageNet V1 file is retained under `artifacts/weights/` with SHA-256 provenance.

The frozen configuration is `configs/protocol.json`. Data stays in its existing location. Original lexicographic filenames 0:800 form the pool; seed-0 `randperm(800)` gives 80 validation and 720 training indices, each sorted. Filenames 800:890 form the held-out test. Original shorter-edge resize to 256, paired training crops/flips, evaluation center crops, sigmoid/BatchNorm models, separate width-32 extractors and map bounds are preserved.

Training calls the upstream inner loop with batch size 4, two workers, AMP initial scale 1024, gradient clipping at 1, L1/VGG weights 1/1, AdamW at 2e-4 with weight decay 1e-5, original cosine to 1e-6 over 100 epochs and early stopping patience 20/min delta 1e-4. Best checkpoint maximizes the validation (PSNR, SSIM) tuple. Original initialization and global RNG consumption are preserved; independent model alignment, loader generators and stateless augmentations are not added.

From this directory:

```bash
conda activate uieb-latent-repro
python scripts/experiment.py prepare
python -m pytest -q tests
python scripts/experiment.py smoke
python scripts/experiment.py train --condition rgb
python scripts/experiment.py train --condition latent
python scripts/experiment.py evaluate
python scripts/experiment.py report
```

For the entire sequential workflow after successful preparation and smoke:

```bash
tmux new-session -d -s uieb-latent-repro 'cd /home/heniath/Experiments/uieb-latent-reproduction && /home/heniath/miniforge3/envs/uieb-latent-repro/bin/python -u scripts/run_logged.py'
tail -f outputs/original_uieb_seed0_v2/training.log
```

Re-running `run_logged.py` resumes incomplete runs at an epoch boundary and skips complete runs and completed test evaluations. Atomic best/last checkpoints retain model, optimizer, scheduler, scaler, early stopping, full history and Python/NumPy/CPU/CUDA RNG. File locks prevent concurrent mutation. Frozen source, configuration, weights, environment and dataset hashes are checked at startup. If these change, use a distinct experiment ID. Do not edit source/configuration during active training. Completed artifacts are preserved.

`outputs/original_uieb_seed0_v2/` holds the audited manifest, source snapshot, environment locks, smoke checkpoints/results, persistent log, job status, both run directories and `reports/FINDINGS.md`. Smoke measurements are functionality checks, not benchmark results. Full evaluation waits for both runs and saves the selected checkpoint hash, 90 per-image PSNR/SSIM values and their unweighted means.

The historical split is preserved even when duplicate candidates cross it; read the audit and interpretation limits. The notebook's seed-0 PSNR values are 20.589 dB RGB and 22.336 dB latent. Historical code/environment identity is unverified. Single-seed differences are descriptive; a negative result is valid. Additional seeds, NAFNet, LOL, LSUI and reconstruction variants remain deferred.

Preflight v1 artifacts are preserved separately. The revised v2 resume check verifies exact checkpoint restoration and matching sample/RNG/scheduler/scaler progression, measures GPU continuation variation and requires validation drift below 0.01 dB PSNR and 0.0001 SSIM. Strict bitwise continuation failed under the original AMP protocol; no scientific protocol factor was changed.
