# Fresh learned-map pilot on standard U-Net: LOL-v2 real and LSUI

Experiment `unet_lol_lsui_v1`: 24 new runs, two independently trained datasets,
four conditions (`rgb`, `zero_maps`, `learned_maps`, `capacity`), seeds 0/1/2.
UIEB is excluded at the user's request. Existing UIEB U-Net results remain a
separate protocol, not the missing UIEB arm of this experiment.

Primary hypothesis: learned maps improve validation PSNR over RGB and capacity,
with nonnegative SSIM differences in each seed on each dataset. Report every
seed and negative result. Test evaluation occurs once after all 12 training
runs in its dataset stage, using validation-selected checkpoints. Do not tune
the model, recipe or stopping policy against test results.

The fresh NAFNet pilot supplies byte-identical data/metric code and manifests:
LOL-v2 real 620/69/100 (official test preserved), LSUI 3423/428/428. Inputs and
reference pairs remain in place under the configurable data root. Exact and
conservative near-duplicate groups are inherited unchanged; scene independence
is not established. These are separately trained datasets, not transfer tests.

Preserve the pilot's 100 epochs, float32 batch 8, paired 256-pixel crops/flips,
L1, AdamW 2e-4 with zero weight decay, cosine to zero, first maximum-validation-
PSNR checkpoint, strict deterministic algorithms and disabled TF32. Evaluate
full native images at batch 1, reflection padding to multiples of 16, unchanged
PSNR/SSIM. No pretrained weights, resizing, AMP, auxiliary losses or early stop.

Backbone is the standard pinned four-level U-Net (64/128/256/512, bottleneck
1024), bilinear interpolation, BatchNorm/ReLU and its original sigmoid RGB head.
It retains direct RGB prediction; the pilot's NAFNet had an RGB residual output.
This architecture/output change is explicit and defines the U-Net condition.
Original U-Net source, revision/hash and Apache license are retained under
`third_party/unet/`; the imported `_unet.py` is byte-identical to that source.

The map head is the fresh pilot's unchanged two-layer width-16 SiLU extractor
with linear three-channel spatial and three-channel pooled global projections.
Expand the first convolution to nine input channels while copying common RGB
weights. Share backbone initialization and stateless order/augmentation within
seed. Zero maps test the expanded interface. Capacity adds a residual branch
after the first encoder block, with bottleneck 20 instead of NAFNet's 19 to
match the U-Net's added map/input parameter budget within 2%. This does not
match architecture or compute. All four conditions share the same output head.

The project is not a Git repository. `copy_provenance.json` retains initial
parent-copy hashes; the frozen protocol and source snapshot identify final
code/config/environment/manifests. Source/config edits after freezing require a
new experiment. Existing studies and their runs are read only.

Use existing `ml-base` Python without installation or package updates:

```bash
/home/heniath/miniforge3/envs/ml-base/bin/python -m pytest -q
/home/heniath/miniforge3/envs/ml-base/bin/python scripts/experiment.py verify-data
/home/heniath/miniforge3/envs/ml-base/bin/python scripts/experiment.py --device cuda smoke
/home/heniath/miniforge3/envs/ml-base/bin/python scripts/preflight.py
/home/heniath/miniforge3/envs/ml-base/bin/python scripts/run_logged.py
```

Run the logged runner in tmux session `unet-lol-lsui`. The single-GPU runner
retains `outputs/unet_lol_lsui_v1/training.log`, `job_status.json`, full epoch
histories, best/last checkpoints, selected per-image validation metrics and final
test metrics. Repeating the same command skips completed runs and resumes an
incomplete run at the last saved epoch. Inspect current processes/GPU before
launching. A global project GPU-operation lock prevents duplicate CLI jobs;
reporting remains independently available. On OOM, stop and report, retaining
the original batch, precision, resolution and architecture.

`scripts/experiment.py summarize` produces partial validation tables during
training and separate held-out tables after evaluation. Preflight scores are
functionality checks only. Their runtime estimates are estimates, not results.
No changes to dependencies, system CUDA or drivers are required.
