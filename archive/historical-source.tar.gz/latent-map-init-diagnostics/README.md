# NAFNet map-input initialization diagnostics

Five fresh seed-0 runs test whether zero initialization of the six added map
input channels improves NAFNet over the original random initialization. This
is a separate experiment, `map_init_diagnostics_v1`; the completed parent study
at `../latent-map-diagnostics` is preserved.

Conditions, in execution order: `rgb`, `bounded`, `bounded_zero_init`,
`unbounded`, `unbounded_zero_init`. Zero variants construct the exact original
model and then zero only `backbone.intro.weight[:, 3:]`, without drawing RNG.
Map heads, RGB input weights and bias, and the remaining backbone are identical
within pairs. Initial zero-map models are mathematically equal to RGB; measured
float32 differences must satisfy rtol=1e-5, atol=1e-6.

## Frozen protocol

Reuse the original exact duplicate-grouped 720/80/90 manifest. Preparation
rechecks hashes and grouping and rejects any deviation from the original
manifest. No test prediction is available. Historical test results were already
inspected in earlier work; scene independence is not established.

Preserve width-32 NAFNet, shared initialization, sample order, augmentation,
256-pixel crops, batch 4, workers 2, AdamW at 2e-4, original loss weights and AMP,
100-epoch cosine schedule, PSNR early stopping with patience 20/min_delta 0.0001,
and validation (PSNR, SSIM) checkpoint selection. No hyperparameter search or
stopping-policy change is part of this experiment. Full settings are in
`configs/protocol.json`.

Use the existing `uieb-latent-repro` environment without dependency changes.
Data is read in place, VGG weights link to the existing verified artifact, and
pinned vendor code retains its licenses/provenance and upstream Git metadata.
The project root is not a Git repository. Source hashes, snapshots, environment
specifications, and run identities provide the code record.

## Verification and execution

From this directory, using that environment's Python:

```bash
python -m unittest discover -s tests -v
python scripts/experiment.py prepare
python scripts/experiment.py smoke
python scripts/run_logged.py
```

Use tmux session `latent-map-init-diagnostics` for the persistent runner. It runs
the five conditions sequentially, then diagnoses and reports automatically.
Do not start a second runner. Locks prevent competing operations. Preparation
must freeze the final source; no source/config/environment/data/weight edits
are permitted after that point. Restarting the same runner preserves completed
runs and resumes incomplete ones at their last saved epoch boundary.

Tests compare original states/forwards against the parent's frozen source,
check exact pairwise tensor differences, initial map equality and parameter
counts, and exercise report completion and diagnostic coverage. Two-step
gradient checks explicitly allow zero head gradients on the first step and
require nonzero head gradients after map-input weights learn. GPU smoke verifies
synthetic/development forward equivalence, matching augmented batches, finite
updates, and full checkpoint restoration for all five conditions. Continued CUDA
execution can differ; retain measured drift with limits 0.01 dB / 0.0001 SSIM.

## Outputs and decisions

Outputs live under `outputs/map_init_diagnostics_v1/`. Check `job_status.json`,
`training.log`, `<backbone>/<condition>/seed_0/history.json`, and completion
markers. Best/last checkpoints include optimizer, scheduler, scaler, stopping,
RNG, identity, and histories. Do not change batch size/resolution on OOM; stop
and report the failure.

The report compares each zero variant to its matching random variant, and all
four map conditions to fresh RGB. It records paired means/medians/wins/worst
cases, complete learning curves, common observed epoch horizons, resources,
AMP skip counts, and differences from historical controls. Bounded variants
receive identical intervention definitions/donor permutations; all map variants
receive map statistics. Historical scores are context, not fresh controls.

An initialization benefit requires >=0.2 dB and nonnegative SSIM versus matching
random initialization. A candidate must also meet those gains over fresh RGB.
These are descriptive engineering thresholds, not significance tests. Single
seed, validation selection, uncertain scene independence, and the inherited
U-Net-derived recipe limit interpretation. No new seeds or experiments start
automatically. An improvement over random that remains below RGB is partial
recovery, not evidence that maps improve NAFNet.
