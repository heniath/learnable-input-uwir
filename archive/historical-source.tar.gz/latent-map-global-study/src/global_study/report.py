"""Within-seed validation contrasts and explicitly separate dimension screening."""

import csv
import json
import statistics

from conditioning.protocol import write_csv
from conditioning.report import paired_rows
from diagnostics.protocol import atomic_json, canonical, digest

from .protocol import config, h1_directory, output_root, verify_diagnostic, verify_run


def mean_sd(values):
    return {"mean": statistics.mean(values), "sample_sd": statistics.stdev(values) if len(values) > 1 else None,
            "n_seeds": len(values)}


def report(frozen):
    out = output_root()
    target = out / "reports"
    target.mkdir(exist_ok=True)
    h1, available, missing, contrasts = [], {}, [], []
    for seed in (0, 1, 2):
        for condition in ("A0_rgb", "A1_spatial", "A2_global", "A3_both"):
            directory = h1_directory(seed, condition)
            if not (directory / "complete.json").exists():
                missing.append({"phase": "H1", "condition": condition, "seed": seed})
                continue
            scope = "h1_seed0_config" if seed == 0 else "h1_seeds12_config"
            expected = {"seed": seed, "condition": condition, "frozen_identity": frozen["parent_identities"][scope]}
            saved, rows = verify_run(directory, expected)
            history = json.loads((directory / "history.json").read_text())
            available[(seed, condition)] = (saved, rows, history)
            h1.append({"seed": seed, "condition": condition, **saved["best"], "optimizer_steps": saved["optimizer_steps"],
                       "amp_skipped_updates": saved["amp_skipped_updates"], "checkpoint_sha256": saved["best_sha256"]})
        pairs = [(condition, "A0_rgb") for condition in ("A1_spatial", "A2_global", "A3_both")]
        pairs.append(("A3_both", "A2_global"))
        for condition, baseline in pairs:
            if (seed, condition) not in available or (seed, baseline) not in available:
                continue
            history = available[(seed, condition)][2]
            reference = available[(seed, baseline)][2]
            if len(history) != 30 or len(reference) != 30 or any(
                    a["batch_hashes"] != b["batch_hashes"] or a["lr"] != b["lr"] for a, b in zip(history, reference)):
                raise ValueError("H1 paired epoch/batch/augmentation/schedule mismatch")
            delta = paired_rows(available[(seed, condition)][1], available[(seed, baseline)][1])
            contrasts.append({"seed": seed, "condition": condition, "baseline": baseline,
                              "delta_psnr": statistics.mean(row["delta_psnr"] for row in delta),
                              "delta_ssim": statistics.mean(row["delta_ssim"] for row in delta),
                              "psnr_wins": sum(row["delta_psnr"] > 0 for row in delta), "n_images": 80})
    aggregates = []
    for condition, baseline in [("A1_spatial", "A0_rgb"), ("A2_global", "A0_rgb"),
                                ("A3_both", "A0_rgb"), ("A3_both", "A2_global")]:
        selected = [r for r in contrasts if r["condition"] == condition and r["baseline"] == baseline]
        if selected:
            p, s = (mean_sd([r[key] for r in selected]) for key in ("delta_psnr", "delta_ssim"))
            aggregates.append({"condition": condition, "baseline": baseline, "seeds": [r["seed"] for r in selected],
                               "delta_psnr_mean": p["mean"], "delta_psnr_sample_sd": p["sample_sd"],
                               "delta_ssim_mean": s["mean"], "delta_ssim_sample_sd": s["sample_sd"], "n_seeds": p["n_seeds"]})
    dimensions = []
    for seed in config()["dimension_seeds"]:
        for dimension in config()["dimensions"]:
            condition = f"d_{dimension}"
            directory = h1_directory(seed, "A2_global") if dimension == 3 else out / "runs" / f"seed_{seed}" / condition
            if not (directory / "complete.json").exists():
                missing.append({"phase": "dimension", "condition": condition, "seed": seed})
                continue
            identity = available[(seed, "A2_global")][0]["identity"] if dimension == 3 else {
                "condition": condition, "seed": seed, "frozen_identity": canonical(frozen)}
            saved, _ = verify_run(directory, identity)
            reference_history = available[(seed, "A2_global")][2]
            history = json.loads((directory / "history.json").read_text())
            if len(history) != 30 or any(a["batch_hashes"] != b["batch_hashes"] or a["lr"] != b["lr"]
                                         for a, b in zip(history, reference_history)):
                raise ValueError("Dimension and d=3 reference batch/schedule pairing differs")
            dimensions.append({"seed": seed, "dimension": dimension, **saved["best"],
                               "delta_psnr_vs_d3": saved["best"]["psnr"] - available[(seed, "A2_global")][0]["best"]["psnr"],
                               **saved["parameters"], "conv_linear_macs": saved["conv_linear_macs"],
                               "optimizer_steps": saved["optimizer_steps"], "amp_skipped_updates": saved["amp_skipped_updates"],
                               "reused": dimension == 3, "checkpoint_sha256": saved["best_sha256"]})
    diagnostics = []
    expected_diagnostics = [("H1", f"seed_{seed}", condition) for seed in (0, 1, 2) for condition in ("A2_global", "A3_both")]
    expected_diagnostics += [("dimension", f"seed_{seed}", f"d_{d}") for seed in config()["dimension_seeds"]
                             for d in config()["dimensions"] if d != 3]
    for phase, seed_name, condition in expected_diagnostics:
        directory = out / "diagnostics" / phase / seed_name / condition
        if not (directory / "complete.json").exists():
            missing.append({"phase": "diagnostic", "scope": phase, "condition": condition, "seed": seed_name})
            continue
        value = json.loads((directory / "results.json").read_text())
        verify_diagnostic(directory, value["identity"])
        if value["identity"]["frozen_identity"] != canonical(frozen):
            raise ValueError("Diagnostic belongs to another follow-up")
        diagnostics.append({"phase": phase, "seed": value["identity"]["seed"], "condition": condition,
                            "dimension": len(value["training_mean_g"]),
                            "training_sd": value["training_statistics"]["population_sd"],
                            "numerically_constant": value["training_statistics"]["numerically_constant_coordinates"],
                            "training_effective_rank": value["training_statistics"]["effective_rank"],
                            "normal_psnr": value["normal_validation"]["psnr"],
                            "training_mean_psnr": value["training_mean_validation"]["psnr"],
                            "delta_psnr_mean_minus_normal": value["delta_mean_minus_normal"]["psnr"],
                            "delta_ssim_mean_minus_normal": value["delta_mean_minus_normal"]["ssim"]})
    for name, rows in (("h1_validation.csv", h1), ("h1_seed_contrasts.csv", contrasts),
                       ("h1_contrast_summary.csv", aggregates), ("dimension_validation.csv", dimensions),
                       ("global_diagnostics.csv", diagnostics)):
        if rows:
            write_csv(target / name, rows)
    result = {"h1": h1, "h1_contrasts": contrasts, "h1_aggregates": aggregates, "dimensions": dimensions,
              "diagnostics": diagnostics, "missing": missing, "spatial_decision": "Deferred; no automatic branch removal",
              "test_policy": "Validation only; no new test inference or test-based tuning"}
    atomic_json(target / "results.json", result)
    lines = ["# Global branch follow-up — validation only", "", f"H1 completed: {len(h1)}/12. Dimension cells: {len(dimensions)}/4. "
             f"Diagnostics: {len(diagnostics)}/{len(expected_diagnostics)}. Missing entries: {len(missing)}.", "",
             "## H1 paired-seed confirmation", "", "| Seed | Condition | Selected epoch | PSNR | SSIM |",
             "|---|---|---:|---:|---:|"]
    lines += [f"| {r['seed']} | {r['condition']} | {r['epoch']} | {r['psnr']:.5f} | {r['ssim']:.6f} |" for r in h1]
    lines += ["", "| Seed | Condition | Baseline | Delta PSNR | Delta SSIM |", "|---|---|---|---:|---:|"]
    lines += [f"| {r['seed']} | {r['condition']} | {r['baseline']} | {r['delta_psnr']:+.5f} | {r['delta_ssim']:+.6f} |" for r in contrasts]
    lines += ["", "Means/sample SD across paired training-seed contrasts are saved in h1_contrast_summary.csv. "
              "Image and seed replicates are not pooled; no scene-independent confidence interval is claimed.", "",
              "## Global-only dimension screen", "", "| Seed | d | Selected epoch | PSNR | SSIM | Delta PSNR vs d=3 | Reused |",
              "|---|---:|---:|---:|---:|---:|---|"]
    lines += [f"| {r['seed']} | {r['dimension']} | {r['epoch']} | {r['psnr']:.5f} | {r['ssim']:.6f} | {r['delta_psnr_vs_d3']:+.5f} | {r['reused']} |" for r in dimensions]
    lines += ["", "The dimension screen uses seed 0 only; d=3 reuses H1 global-only. It does not establish cross-seed dimension effects. "
              "Input/head widths and parameter/MAC counts vary; see dimension_validation.csv.", "",
              "## Global-vector variation and training-mean intervention", "",
              "| Scope | Seed | Condition | Training G SD | Normal val PSNR | Training-mean G val PSNR | Mean minus normal |",
              "|---|---:|---|---|---:|---:|---:|"]
    lines += [f"| {r['phase']} | {r['seed']} | {r['condition']} | {', '.join(f'{v:.6f}' for v in r['training_sd'])} | "
              f"{r['normal_psnr']:.5f} | {r['training_mean_psnr']:.5f} | {r['delta_psnr_mean_minus_normal']:+.5f} |" for r in diagnostics]
    lines += ["", "Each mean is computed from that checkpoint's 720 training images only, without augmentation, in eval mode. "
              "Normal validation reproduces the saved selected checkpoint before interpretation. Spatial maps are held fixed. "
              "Negative mean-minus-normal PSNR indicates loss from this intervention. Continuous SD/ranges, saturation and "
              "covariance/SVD/effective rank are saved per diagnostic; near-constant thresholds are descriptive, not proof of collapse.", "",
              "## Decision boundary", "", "Spatial removal/modification/retention remains deferred pending review of seed-wise evidence. "
              "No test predictions, test-based selection, automatic promotion, environment changes or historical artifact replacement. "
              "Pilot horizon, historical test exposure and unresolved scene independence remain limitations."]
    (target / "FINDINGS.md").write_text("\n".join(lines) + "\n")
    if not missing:
        marker = out / "complete.json"
        complete = {"frozen_identity": canonical(frozen), "h1_cells": len(h1), "dimension_cells": len(dimensions),
                    "diagnostics": len(diagnostics), "report_hashes": {p.name: digest(p) for p in target.iterdir() if p.is_file()}}
        if marker.exists() and json.loads(marker.read_text()) != complete:
            raise ValueError("Completed follow-up report changed")
        atomic_json(marker, complete)
    print(f"Report: H1 {len(h1)}/12, dimensions {len(dimensions)}/4, diagnostics {len(diagnostics)}/{len(expected_diagnostics)}, missing {len(missing)}", flush=True)
