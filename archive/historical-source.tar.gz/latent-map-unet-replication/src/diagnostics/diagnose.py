"""Validation-only per-image metrics, map interventions and resource measurements."""

import csv
import gc
import hashlib
import json

import numpy as np
import torch
from uwir.metrics import compute_psnr, compute_ssim

from .engine import run_dir, utc
from .models import EnhancementModel, convolution_macs, parameter_count
from .protocol import (
    atomic_json,
    canonical,
    config,
    digest,
    freeze_json,
    loader,
    seed_original,
    verify_frozen,
)


def metric_rows(prediction, target, names):
    if not torch.isfinite(prediction).all():
        raise FloatingPointError("Non-finite diagnostic prediction")
    pred = prediction.float().cpu().permute(0, 2, 3, 1).numpy().clip(0, 1)
    gt = target.permute(0, 2, 3, 1).numpy().clip(0, 1)
    return [
        {"filename": name, "psnr": compute_psnr(a, b), "ssim": compute_ssim(a, b)}
        for a, b, name in zip(pred, gt, names)
    ]


def intervene(maps, name, filenames, donors=None, seed=0):
    spatial, background = maps
    if name == "spatial_mean":
        return spatial.mean((-2, -1), keepdim=True).expand_as(spatial), background
    if name == "spatial_permutation":
        result = []
        for tensor, filename in zip(spatial, filenames):
            key = f"map_permutation:{seed}:{filename}"
            generator = torch.Generator().manual_seed(
                int(hashlib.sha256(key.encode()).hexdigest()[:16], 16)
            )
            order = torch.randperm(
                tensor.shape[-2] * tensor.shape[-1], generator=generator
            ).to(tensor.device)
            result.append(tensor.flatten(1)[:, order].reshape_as(tensor))
        return torch.stack(result), background
    if name == "cross_image_swap":
        if donors is None:
            raise ValueError("Cross-image intervention requires donor maps")
        return tuple(
            torch.stack([donors[filename][i] for filename in filenames]).to(
                spatial.device
            )
            for i in (0, 1)
        )
    if name == "normal":
        return maps
    raise ValueError(name)


@torch.inference_mode()
def latency(model, example):
    c = config()["latency"]
    for _ in range(c["warmup"]):
        model(example)
    torch.cuda.synchronize()
    events = [
        (torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True))
        for _ in range(c["repetitions"])
    ]
    for start, end in events:
        start.record()
        model(example)
        end.record()
    torch.cuda.synchronize()
    values = [start.elapsed_time(end) for start, end in events]
    return {
        **c,
        "shape": list(example.shape),
        "median_ms": float(np.median(values)),
        "mean_ms": float(np.mean(values)),
        "p95_ms": float(np.percentile(values, 95)),
        "scope": "GPU forward only, CUDA events; excludes CPU preprocessing/transfers/metrics",
    }


@torch.inference_mode()
def diagnose_run(backbone, condition, seed, frozen):
    directory = run_dir(backbone, condition, seed)
    identity = json.loads((directory / "run.json").read_text())
    if identity["frozen_identity"] != canonical(frozen):
        raise ValueError("Run identity mismatch")
    marker = directory / "diagnostics.json"
    if marker.exists():
        result = json.loads(marker.read_text())
        if result["checkpoint_sha256"] != digest(directory / "best.pt"):
            raise ValueError("Diagnosed best checkpoint changed")
        for name, expected in result["artifact_hashes"].items():
            if digest(directory / name) != expected:
                raise ValueError("Completed diagnostic artifact changed")
        print(f"{backbone}/{condition}: diagnostics complete; preserved", flush=True)
        return
    seed_original(seed)
    state = torch.load(directory / "best.pt", map_location="cpu", weights_only=False)
    if state["identity"] != identity:
        raise ValueError("Best checkpoint identity mismatch")
    model = EnhancementModel(backbone, condition, seed).cuda().eval()
    model.load_state_dict(state["model"])
    selected = state["best"]
    del state
    torch.cuda.reset_peak_memory_stats()
    rows, cache, map_stats = [], {}, []
    for x, y, names, _ in loader("validation", seed=seed, filenames=True):
        pred, maps = model(x.cuda(), return_maps=True)
        rows.extend(metric_rows(pred, y, names))
        if maps is not None:
            for name, spatial, background in zip(names, *maps):
                cache[name] = (spatial.cpu(), background.cpu())
                map_stats.append(
                    {
                        "filename": name,
                        "spatial_min": float(spatial.min()),
                        "spatial_max": float(spatial.max()),
                        "spatial_std": float(spatial.std()),
                        "global_rgb": background[:, 0, 0].cpu().tolist(),
                    }
                )
    if len(rows) != 80:
        raise ValueError("Expected exactly 80 validation predictions")
    means = {
        key: float(np.mean([row[key] for row in rows])) for key in ("psnr", "ssim")
    }
    if (
        abs(means["psnr"] - selected["psnr"]) > 0.001
        or abs(means["ssim"] - selected["ssim"]) > 0.00001
    ):
        raise ValueError("Selected checkpoint metrics do not reproduce")
    all_rows = {"normal": rows}
    donor_names = {}
    if condition == "bounded":
        names = sorted(cache)
        donor_names = {
            name: names[(i + 1) % len(names)] for i, name in enumerate(names)
        }
        donors = {name: cache[donor_names[name]] for name in names}
        for intervention in config()["interventions"][1:]:
            values = []
            for x, y, batch_names, _ in loader("validation", seed=seed, filenames=True):
                maps = tuple(
                    torch.stack([cache[name][i] for name in batch_names]).cuda()
                    for i in (0, 1)
                )
                override = intervene(
                    maps, intervention, batch_names, donors=donors, seed=seed
                )
                values.extend(
                    metric_rows(model(x.cuda(), maps_override=override), y, batch_names)
                )
            all_rows[intervention] = values
    artifact_hashes = {}
    for name, values in all_rows.items():
        path = directory / f"per_image_validation_{name}.csv"
        with path.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(values[0]))
            writer.writeheader()
            writer.writerows(values)
        artifact_hashes[path.name] = digest(path)
    if map_stats:
        atomic_json(directory / "map_statistics.json", map_stats)
        artifact_hashes["map_statistics.json"] = digest(
            directory / "map_statistics.json"
        )
    example = next(iter(loader("validation", seed=seed)))[0][:1].cuda()
    resources = {
        "parameters": parameter_count(model),
        "convolution_macs": convolution_macs(model),
        "latency": latency(model, example),
        "inference_peak_allocated_bytes": torch.cuda.max_memory_allocated(),
    }
    results = {
        name: {
            key: float(np.mean([r[key] for r in values])) for key in ("psnr", "ssim")
        }
        for name, values in all_rows.items()
    }
    freeze_json(
        marker,
        {
            "count": 80,
            "split": "validation",
            "identity": identity,
            "checkpoint_epoch": selected["epoch"],
            "checkpoint_sha256": digest(directory / "best.pt"),
            "normal": means,
            "interventions": results,
            "swap_donors": donor_names,
            "resources": resources,
            "artifact_hashes": artifact_hashes,
            "utc": utc(),
        },
    )
    print(f"{backbone}/{condition}: validation {means}", flush=True)
    del model, cache, maps, pred, example
    if condition == "bounded":
        del donors, override
    gc.collect()
    torch.cuda.empty_cache()


def diagnose():
    frozen, _ = verify_frozen()
    runs = [
        (b, c, s)
        for b in config()["backbones"]
        for s in config()["model_seeds"]
        for c in config()["conditions"]
    ]
    if not all((run_dir(*run) / "run_complete.json").exists() for run in runs):
        raise ValueError("All configured runs must complete before diagnostics")
    for run in runs:
        diagnose_run(*run, frozen)
