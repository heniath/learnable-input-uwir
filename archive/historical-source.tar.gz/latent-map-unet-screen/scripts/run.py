#!/usr/bin/env python3
"""Bounded, validation-only screening of three small U-Net extensions."""

import argparse
import csv
import fcntl
import hashlib
import json
import os
import shutil
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT.parent / "latent-map-diagnostics"
REPLICATION = ROOT.parent / "latent-map-unet-replication"
sys.path[:0] = [str(ROOT / "src"), str(REPLICATION / "src"),
                str(REPLICATION / "third_party/upstream/src"),
                str(REPLICATION / "third_party/nafnet")]

import numpy as np
import torch

from diagnostics.diagnose import metric_rows
from diagnostics.protocol import (atomic_json, canonical, configure_weights, digest,
                                  loader, seed_original, verify_frozen)
from models import ScreenUNet
from uwir.cli.train import train_epoch
from uwir.losses import CompositeLoss
from uwir.training.checkpoint import save_checkpoint
from uwir.training.seed import capture_rng_state, restore_rng_state

CONFIG_PATH = ROOT / "configs/screen.json"
C = json.loads(CONFIG_PATH.read_text())
OUTPUT = ROOT / "outputs" / C["experiment_id"]


def utc():
    return datetime.now(timezone.utc).isoformat()


class Tee:
    def __init__(self, stream, path):
        self.stream = stream
        self.handle = path.open("a", buffering=1)

    def write(self, value):
        self.stream.write(value)
        self.handle.write(value)

    def flush(self):
        self.stream.flush()
        self.handle.flush()


def write_csv(path, rows):
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def status(**values):
    atomic_json(OUTPUT / "job_status.json", {"utc": utc(), **values})


def checkpoint_path(seed):
    archive = (PARENT / "outputs/map_diagnostics_v1" if seed == 0 else
               REPLICATION / "outputs/unet_map_replication_v1")
    return archive / "unet/bounded" / f"seed_{seed}" / "best.pt"


def preflight():
    print(f"{utc()} Verifying parent source, environment, manifests and checkpoints", flush=True)
    frozen, manifest = verify_frozen()
    sources = {str(p.relative_to(ROOT)): digest(p) for p in
               (CONFIG_PATH, ROOT / "src/models.py", Path(__file__).resolve(), ROOT / "README.md")}
    checkpoints = {}
    for seed in (C["screen_seed"], C["confirmation_seed"]):
        path = checkpoint_path(seed)
        diagnostic = json.loads((path.parent / "diagnostics.json").read_text())
        if digest(path) != diagnostic["checkpoint_sha256"]:
            raise ValueError(f"Parent checkpoint changed: {path}")
        checkpoints[str(seed)] = {"path": str(path), "sha256": diagnostic["checkpoint_sha256"],
                                  "selected_epoch": diagnostic["checkpoint_epoch"],
                                  "validation": diagnostic["normal"]}
    splits = manifest["indices"]
    if [len(splits[s]) for s in ("train", "validation", "test")] != [720, 80, 90]:
        raise ValueError("Unexpected split counts")
    if any(set(splits[a]) & set(splits[b]) for a, b in
           (("train", "validation"), ("train", "test"), ("validation", "test"))):
        raise ValueError("Overlapping partitions")
    identity = {"config": C, "sources": sources, "parent_frozen_identity": canonical(frozen),
                "manifest_sha256": canonical(manifest), "environment": frozen["environment"],
                "checkpoints": checkpoints, "git": "New project is not a Git repository; source hashes/snapshot identify code"}
    destination = OUTPUT / "frozen.json"
    if destination.exists():
        if json.loads(destination.read_text()) != identity:
            raise ValueError("Frozen screening inputs changed; create a new experiment")
    else:
        atomic_json(destination, identity)
        atomic_json(OUTPUT / "manifest.json", manifest)
        for relative in sources:
            target = OUTPUT / "source_snapshot" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / relative, target)
    return identity


def make_model(condition, seed):
    seed_original(seed)
    model = ScreenUNet(condition, seed, C["residual_scale"], C["skip_gate_scale"])
    state = torch.load(checkpoint_path(seed), map_location="cpu", weights_only=False)
    if state["identity"] != json.loads((checkpoint_path(seed).parent / "run.json").read_text()):
        raise ValueError("Parent checkpoint/run identity differs")
    model.base.load_state_dict(state["model"], strict=True)
    del state
    return model.cuda()


def make_objects(condition, seed):
    model = make_model(condition, seed)
    configure_weights()
    loss = CompositeLoss(lambda_l1=C["loss_weights"]["l1"],
                         lambda_perc=C["loss_weights"]["perceptual"],
                         lambda_ssim=C["loss_weights"]["ssim"], device="cuda")
    optimizer = torch.optim.AdamW(model.parameters(), lr=C["lr"], weight_decay=C["weight_decay"])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=C["epochs"], eta_min=C["eta_min"])
    scaler = torch.amp.GradScaler("cuda", init_scale=C["amp_initial_scale"])
    # Branch construction must not alter training randomness between conditions.
    seed_original(seed)
    return model, loss, optimizer, scheduler, scaler


@torch.inference_mode()
def evaluate(model, seed):
    model.eval()
    rows = []
    for x, y, names, _ in loader("validation", seed=seed, filenames=True):
        rows.extend(metric_rows(model(x.cuda()), y, names))
    if len(rows) != 80 or len({r["filename"] for r in rows}) != 80:
        raise ValueError("Validation coverage mismatch")
    metrics = {key: float(np.mean([r[key] for r in rows])) for key in ("psnr", "ssim")}
    if not all(np.isfinite(v) for v in metrics.values()):
        raise FloatingPointError("Non-finite validation metrics")
    return metrics, rows


def verify_anchor(rows, seed):
    path = checkpoint_path(seed).parent / "per_image_validation_normal.csv"
    with path.open() as handle:
        saved = {r["filename"]: r for r in csv.DictReader(handle)}
    if set(saved) != {r["filename"] for r in rows}:
        raise ValueError("Validation anchor identity mismatch")
    drift = {key: max(abs(r[key] - float(saved[r["filename"]][key])) for r in rows)
             for key in ("psnr", "ssim")}
    if drift["psnr"] > 0.001 or drift["ssim"] > 0.00001:
        raise ValueError(f"Pretrained function changed before training: {drift}")
    return drift


class TraceFirstBatch:
    def __init__(self, data_loader):
        self.data_loader = data_loader
        self.first_hash = None

    def __len__(self):
        return len(self.data_loader)

    def __iter__(self):
        for x, y in self.data_loader:
            if self.first_hash is None:
                self.first_hash = hashlib.sha256(x.numpy().tobytes() + y.numpy().tobytes()).hexdigest()
            yield x, y


def smoke(frozen):
    marker = OUTPUT / "smoke.json"
    if marker.exists():
        saved = json.loads(marker.read_text())
        if saved["passed"] and saved["frozen_identity"] == canonical(frozen):
            print("Completed smoke preserved", flush=True)
            return
        raise ValueError("Existing smoke failed; inspect before changing the experiment")
    result = {"passed": False, "frozen_identity": canonical(frozen), "conditions": {}}
    for condition in C["conditions"]:
        objects = make_objects(condition, C["screen_seed"])
        model, criterion, optimizer, scheduler, scaler = objects
        metrics, rows = evaluate(model, C["screen_seed"])
        drift = verify_anchor(rows, C["screen_seed"])
        traced = TraceFirstBatch(loader("train", seed=C["screen_seed"],
                                       epoch=C["augmentation_epoch_offset"] + 1, limit=8))
        loss, parts = train_epoch(model, traced, optimizer, criterion, torch.device("cuda"), scaler=scaler)
        if not optimizer.state or not np.isfinite(loss):
            raise ValueError("Smoke did not produce optimizer updates")
        if not all(p.grad is not None and torch.isfinite(p.grad).all()
                   for p in model.parameters() if p.requires_grad):
            raise FloatingPointError("Missing or non-finite smoke gradients")
        if model.projections and not any(p.grad.abs().max() > 0 for p in model.projections.parameters()):
            raise ValueError("New branch has no gradient")
        if condition == "control":
            boundary = OUTPUT / "smoke_checkpoint.pt"
            save_checkpoint(boundary, {"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                                       "scheduler": scheduler.state_dict(), "scaler": scaler.state_dict(),
                                       "rng": capture_rng_state()})
            restored = torch.load(boundary, map_location="cpu", weights_only=False)
            for key, tensor in model.state_dict().items():
                torch.testing.assert_close(tensor.cpu(), restored["model"][key], rtol=0, atol=0)
            model.load_state_dict(restored["model"], strict=True)
            optimizer.load_state_dict(restored["optimizer"])
            scheduler.load_state_dict(restored["scheduler"])
            scaler.load_state_dict(restored["scaler"])
            restore_rng_state(restored["rng"])
            del restored
        result["conditions"][condition] = {
            "anchor": metrics, "max_anchor_drift": drift, "two_batch_loss": loss,
            "parameters": sum(p.numel() for p in model.parameters()),
            "new_parameters": sum(p.numel() for p in model.projections.parameters()),
            "first_batch_sha256": traced.first_hash, "finite_gradients": True,
        }
        print(f"Smoke {condition}: anchor={metrics}, drift={drift}, new branch gradients OK", flush=True)
        del model, criterion, optimizer, scheduler, scaler, objects
        torch.cuda.empty_cache()
    if len({r["first_batch_sha256"] for r in result["conditions"].values()}) != 1:
        raise ValueError("Conditions saw different smoke samples")
    result["passed"] = True
    result["checkpoint_roundtrip"] = "model tensors exact; optimizer/scheduler/scaler/RNG restored"
    atomic_json(marker, result)


def save_best(path, model, identity, best, rows):
    save_checkpoint(path / "best.pt", {"model": model.state_dict(), "identity": identity, "best": best})
    write_csv(path / "per_image_best_validation.csv", rows)


def train(condition, seed, frozen):
    directory = OUTPUT / "runs" / f"seed_{seed}" / condition
    directory.mkdir(parents=True, exist_ok=True)
    identity = {"condition": condition, "seed": seed, "frozen_identity": canonical(frozen)}
    marker = directory / "complete.json"
    if marker.exists():
        completed = json.loads(marker.read_text())
        if completed["identity"] != identity or digest(directory / "best.pt") != completed["best_sha256"]:
            raise ValueError("Completed run identity/hash changed")
        print(f"Preserving completed seed={seed}/{condition}", flush=True)
        return
    objects = make_objects(condition, seed)
    model, criterion, optimizer, scheduler, scaler = objects
    history, start = [], 1
    last = directory / "last.pt"
    if last.exists():
        state = torch.load(last, map_location="cpu", weights_only=False)
        if state["identity"] != identity:
            raise ValueError("Resume identity mismatch")
        model.load_state_dict(state["model"], strict=True)
        optimizer.load_state_dict(state["optimizer"])
        scheduler.load_state_dict(state["scheduler"])
        scaler.load_state_dict(state["scaler"])
        restore_rng_state(state["rng"])
        history, best, start = state["history"], state["best"], state["epoch"] + 1
        del state
        print(f"Resuming seed={seed}/{condition} at epoch {start}", flush=True)
    else:
        metrics, rows = evaluate(model, seed)
        drift = verify_anchor(rows, seed)
        best = {"epoch": 0, **metrics}
        history.append({"epoch": 0, **metrics, "epoch_seconds": 0.0})
        atomic_json(directory / "identity.json", {**identity, "anchor_drift": drift,
                    "parent_checkpoint": str(checkpoint_path(seed)), "parent_sha256": digest(checkpoint_path(seed)),
                    "parameters": sum(p.numel() for p in model.parameters()),
                    "new_parameters": sum(p.numel() for p in model.projections.parameters())})
        save_best(directory, model, identity, best, rows)
        seed_original(seed)
    torch.cuda.reset_peak_memory_stats()
    for epoch in range(start, C["epochs"] + 1):
        status(state="running", phase="screen" if seed == C["screen_seed"] else "confirmation",
               seed=seed, condition=condition, epoch=epoch, epochs=C["epochs"])
        begun = time.perf_counter()
        learning_rate = optimizer.param_groups[0]["lr"]
        traced = TraceFirstBatch(loader("train", seed=seed, epoch=C["augmentation_epoch_offset"] + epoch))
        steps = [0]
        hook = optimizer.register_step_post_hook(lambda *args: steps.__setitem__(0, steps[0] + 1))
        train_loss, parts = train_epoch(model, traced, optimizer, criterion, torch.device("cuda"), scaler=scaler)
        hook.remove()
        torch.cuda.synchronize()
        metrics, rows = evaluate(model, seed)
        row = {"epoch": epoch, **metrics, "train_loss": train_loss, "parts": parts,
               "lr_used": learning_rate, "scaler": scaler.get_scale(),
               "optimizer_steps": steps[0], "amp_skips": len(traced) - steps[0],
               "first_batch_sha256": traced.first_hash, "epoch_seconds": time.perf_counter() - begun,
               "peak_allocated_bytes": torch.cuda.max_memory_allocated()}
        history.append(row)
        if (metrics["psnr"], metrics["ssim"]) > (best["psnr"], best["ssim"]):
            best = {"epoch": epoch, **metrics}
            save_best(directory, model, identity, best, rows)
        scheduler.step()
        save_checkpoint(last, {"identity": identity, "epoch": epoch, "model": model.state_dict(),
                              "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(),
                              "scaler": scaler.state_dict(), "rng": capture_rng_state(),
                              "history": history, "best": best})
        atomic_json(directory / "history.json", history)
        print(f"{utc()} seed={seed} {condition} {epoch}/{C['epochs']} "
              f"PSNR={metrics['psnr']:.4f} SSIM={metrics['ssim']:.5f} "
              f"loss={train_loss:.4f} steps={steps[0]}/{len(traced)} {row['epoch_seconds']:.1f}s", flush=True)
        report()
    result = {"identity": identity, "best": best, "final": history[-1],
              "last_three_psnr": float(np.mean([r["psnr"] for r in history[-3:]])),
              "training_seconds": sum(r["epoch_seconds"] for r in history),
              "best_sha256": digest(directory / "best.pt"),
              "last_sha256": digest(last), "completed_utc": utc()}
    atomic_json(marker, result)
    del model, criterion, optimizer, scheduler, scaler, objects
    torch.cuda.empty_cache()
    report()


def run_summary(seed, condition):
    path = OUTPUT / "runs" / f"seed_{seed}" / condition
    if not (path / "complete.json").exists():
        return None
    completed = json.loads((path / "complete.json").read_text())
    history = json.loads((path / "history.json").read_text())
    info = json.loads((path / "identity.json").read_text())
    return {"seed": seed, "condition": condition, "anchor_psnr": history[0]["psnr"],
            "best_epoch": completed["best"]["epoch"], "best_psnr": completed["best"]["psnr"],
            "best_ssim": completed["best"]["ssim"], "final_psnr": completed["final"]["psnr"],
            "final_ssim": completed["final"]["ssim"], "last_three_psnr": completed["last_three_psnr"],
            "parameters": info["parameters"], "new_parameters": info["new_parameters"],
            "amp_skips": sum(r.get("amp_skips", 0) for r in history),
            "training_seconds": completed["training_seconds"]}


def report():
    rows = [r for seed in (C["screen_seed"], C["confirmation_seed"])
            for condition in C["conditions"] if (r := run_summary(seed, condition)) is not None]
    lines = ["# Fast U-Net architecture screening", "", f"Updated: {utc()}", "",
             "Warm-start, six full-data epochs; fixed train720/validation80. No test evaluation.", "",
             "| Seed | Condition | Best epoch | Val PSNR | Val SSIM | Final PSNR | Last-three mean PSNR | Δbest vs continuation |",
             "|---|---|---:|---:|---:|---:|---:|---:|"]
    for row in rows:
        control = next((r for r in rows if r["seed"] == row["seed"] and r["condition"] == "control"), None)
        row["delta_best_psnr_vs_control"] = row["best_psnr"] - control["best_psnr"] if control else None
        row["delta_best_ssim_vs_control"] = row["best_ssim"] - control["best_ssim"] if control else None
        delta = "pending" if control is None else f"{row['delta_best_psnr_vs_control']:+.4f}"
        lines.append(f"| {row['seed']} | {row['condition']} | {row['best_epoch']} | {row['best_psnr']:.4f} | {row['best_ssim']:.5f} | {row['final_psnr']:.4f} | {row['last_three_psnr']:.4f} | {delta} |")
    if rows:
        write_csv(OUTPUT / "results.csv", rows)
    if (OUTPUT / "promotion.json").exists():
        promotion = json.loads((OUTPUT / "promotion.json").read_text())
        lines += ["", f"Seed-0 promotion decision: {promotion['candidate'] or 'none'}."]
    lines += ["", "Compare candidates to the continuation control, not just the parent checkpoint. Best scores include the common epoch-0 anchor. A six-epoch ranking is a screening signal, not a converged architecture comparison or SOTA result.",
              "", "Residual refinement adds a bounded correction after the existing sigmoid. Multi-scale projections are additive at encoder levels 2/3/4. Skip gates multiply skips by a map-conditioned factor in [0.5,1.5]. All extensions are zero-initialized and preserve the pretrained function before adaptation.",
              "", "Source, environment, split, checkpoint and initialization records are in frozen.json and source_snapshot/. Each run retains full optimizer/scheduler/scaler/RNG in last.pt, selected inference weights in best.pt, per-image best validation metrics and complete per-epoch histories. Sample/augmentation first-batch hashes are paired across conditions. Resume cannot guarantee bitwise CUDA trajectories.",
              "", "No architecture combinations, dataset changes, test predictions or full retraining are included. Historical test exposure and inherited scene-independence limits remain. Added parameter counts are reported; this screen does not rule out all capacity explanations."]
    (OUTPUT / "FINDINGS.md").write_text("\n".join(lines) + "\n")
    return rows


def promote():
    rows = [run_summary(C["screen_seed"], condition) for condition in C["conditions"]]
    if any(r is None for r in rows):
        raise ValueError("Screen stage is incomplete")
    control = rows[0]
    eligible, comparisons = [], []
    for row in rows[1:]:
        item = {"condition": row["condition"],
                "delta_best_psnr": row["best_psnr"] - control["best_psnr"],
                "delta_best_ssim": row["best_ssim"] - control["best_ssim"],
                "delta_last_three_psnr": row["last_three_psnr"] - control["last_three_psnr"]}
        rule = C["promotion"]
        item["passes"] = (item["delta_best_psnr"] >= rule["best_psnr_gain_db"]
                          and item["delta_best_ssim"] >= rule["best_ssim_gain_min"]
                          and item["delta_last_three_psnr"] > rule["last_three_mean_psnr_gain_db"])
        comparisons.append(item)
        if item["passes"]:
            eligible.append(row)
    eligible.sort(key=lambda r: (r["best_psnr"], r["best_ssim"]), reverse=True)
    result = {"candidate": eligible[0]["condition"] if eligible else None,
              "comparisons": comparisons, "rule": C["promotion"]}
    path = OUTPUT / "promotion.json"
    if path.exists() and json.loads(path.read_text()) != result:
        raise ValueError("Previously frozen promotion decision changed")
    atomic_json(path, result)
    return result


def verify_pairing():
    for seed in (C["screen_seed"], C["confirmation_seed"]):
        histories = list((OUTPUT / "runs" / f"seed_{seed}").glob("*/history.json"))
        by_epoch = {}
        for path in histories:
            for row in json.loads(path.read_text()):
                if row["epoch"]:
                    by_epoch.setdefault(row["epoch"], set()).add(row["first_batch_sha256"])
        if any(len(hashes) != 1 for hashes in by_epoch.values()):
            raise ValueError("Run sample/augmentation pairing failed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("smoke", "all", "report"))
    args = parser.parse_args()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    lock = (OUTPUT / ".runner.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    sys.stdout = Tee(sys.stdout, OUTPUT / "execution.log")
    try:
        if args.command == "report":
            report()
            return
        if (OUTPUT / "complete.json").exists():
            print("Screening complete; preserving all runs", flush=True)
            return
        frozen = preflight()
        smoke(frozen)
        if args.command == "smoke":
            status(state="smoke_passed", next_action="all")
            return
        begun = time.perf_counter()
        for condition in C["conditions"]:
            train(condition, C["screen_seed"], frozen)
        decision = promote()
        report()
        if decision["candidate"]:
            print(f"Promoting {decision['candidate']} for paired seed-1 confirmation", flush=True)
            for condition in ("control", decision["candidate"]):
                train(condition, C["confirmation_seed"], frozen)
        else:
            print("No candidate passes the predefined screen; ending without extra runs", flush=True)
        verify_pairing()
        for item in frozen["checkpoints"].values():
            if digest(item["path"]) != item["sha256"]:
                raise ValueError("Original checkpoint changed during screening")
        rows = report()
        atomic_json(OUTPUT / "complete.json", {
            "utc": utc(), "frozen_identity": canonical(frozen), "runs": len(rows),
            "epochs": sum(C["epochs"] for _ in rows), "promotion": decision,
            "paired_first_batches_equal": True, "parent_checkpoints_unchanged": True,
            "this_invocation_seconds": time.perf_counter() - begun,
            "report_sha256": digest(OUTPUT / "FINDINGS.md"),
            "results_sha256": digest(OUTPUT / "results.csv")})
        status(state="complete", runs=len(rows), candidate=decision["candidate"], report=str(OUTPUT / "FINDINGS.md"))
        print(f"Complete: {OUTPUT / 'FINDINGS.md'}", flush=True)
    except BaseException as error:
        atomic_json(OUTPUT / f"failure_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')}.json",
                    {"utc": utc(), "error": repr(error), "traceback": traceback.format_exc()})
        status(state="failed", error=repr(error))
        raise


if __name__ == "__main__":
    main()
