# H1/H2 pilot test interpretation — 2026-10-21

Evaluation: `outputs/conditioning_pilots_test90_v1/`. All eight existing
validation-selected checkpoints completed the fixed 90-image UIEB test
protocol. Training remains unchanged; checkpoint choices preceded inference.

## Observations

- H1 global-only: test PSNR 21.58350 dB, +1.63581 dB and +0.018866 SSIM
  versus the H1 RGB baseline. PSNR improves on 69/90 test images.
- H1 joint maps: 21.55819 dB, +1.61050 dB versus RGB. Adding spatial to
  global yields -0.02531 dB on this test partition.
- H1 spatial-only: 19.83176 dB, -0.11593 dB versus RGB. Its small positive
  validation gain is not retained on this test partition.
- H2 global bottleneck FiLM: 21.60412 dB, +0.09145 dB and +0.001613 SSIM
  versus the independently trained H2 input-only baseline; 49/90 PSNR wins.
- H2 spatial skip: 21.94703 dB, +0.43435 dB and +0.004943 SSIM versus
  H2 input-only; 52/90 PSNR wins.
- H2 combined: 21.42263 dB, -0.09004 dB and -0.002491 SSIM versus
  H2 input-only. Its validation gain of +0.08121 dB is not retained on test.

The H2 validation and test rankings differ: combined modulation had the highest
validation PSNR, whereas spatial skip has the highest observed test PSNR.
This is descriptive reporting, not a new selection or promotion decision.
H2 spatial skip retains both maps at input, so it is a different intervention
from H1 spatial-only. H1 joint maps and H2 input-only also remain separate
training realizations; their observations are not pooled as replicated seeds.

The one-seed pilot does not establish convergence, statistical significance,
physical map semantics or a general architectural advantage. Historical test
exposure, the 256-pixel center-crop evaluation and unresolved scene independence
remain limitations. No follow-up training or test-based tuning was launched.

## Verification performed

- Existing-environment syntax/import checks and filename/order/finite metric
  guards passed; malformed coverage, duplicates, reordering and NaN were rejected.
- Both original frozen source/config identities remained unchanged.
- Full evaluation exited successfully after frozen source/environment/data,
  manifest, completion-marker and checkpoint/validation-CSV checks.
- All eight full validation anchors reproduced PSNR/SSIM with zero per-image
  drift before the first test inference.
- Independent post-run verification passed for all 765 recorded artifact
  SHA-256 hashes, eight test summaries, six paired contrasts and all 720
  prediction PNGs (RGB, 256 x 256, readable). Per-image means reproduce the
  summaries and paired contrasts to less than 1e-10.
- H2 contact sheet was visually inspected for layout and valid outputs.
- Total evaluation wall time: 51.93 seconds. This includes verification,
  metrics and artifact writing; it is not a model latency measurement.

The successful evaluation command was:

```bash
/home/heniath/miniforge3/envs/uieb-latent-repro/bin/python -B /home/heniath/Experiments/latent-map-conditioning-test/scripts/evaluate.py
```

The existing Kornia AMP deprecation warning was visible. GPU execution required
the previously established outside-sandbox access. No packages or system
settings were changed. See the output's `complete.json`, `protocol.json`,
`execution.log`, `FINDINGS.md`, and per-condition validation/test CSVs.
