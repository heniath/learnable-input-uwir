"""Original UIEB latent-map reproduction adapters."""
