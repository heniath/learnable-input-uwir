"""Regression tests for seed isolation, incomplete reports, and artifact integrity."""

# Imports follow the path bootstrap; no editable installation is needed.
# ruff: noqa: E402

import csv
import json
import math
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [
    str(ROOT / "src"),
    str(ROOT / "third_party/upstream/src"),
    str(ROOT / "third_party/nafnet"),
]

from diagnostics import historical
from diagnostics import report as reporting
from diagnostics.protocol import canonical, config, digest


class ReportingTests(unittest.TestCase):
    def metrics(self):
        scores = {0: (18, 30, 19, 18), 1: (20, 21, 22, 20.2), 2: (25, 24, 26, 25.2)}
        return {
            ("unet", condition, seed): {"psnr": score, "ssim": 0.8}
            for seed, values in scores.items()
            for condition, score in zip(config()["conditions"], values)
        }

    def test_every_seed_and_both_controls_required(self):
        metrics = self.metrics()
        result = reporting.screening(metrics)
        self.assertEqual(result["eligible"], ["unbounded"])
        self.assertEqual(result["decision"], "investigate_bounds_next")
        self.assertEqual(len(result["checks"]["bounded"]), 4)
        metrics["unet", "unbounded", 1]["ssim"] = 0.79
        self.assertEqual(reporting.screening(metrics)["eligible"], [])

    def test_missing_seed_is_not_silently_accepted(self):
        metrics = self.metrics()
        del metrics["unet", "rgb", 1]
        with self.assertRaises(KeyError):
            reporting.screening(metrics)

    def test_bounded_remains_primary_when_both_pass(self):
        metrics = self.metrics()
        metrics["unet", "bounded", 2]["psnr"] = 27
        self.assertEqual(
            reporting.screening(metrics)["decision"], "advance_bounded_hypothesis"
        )
        metrics["unet", "bounded", 2]["psnr"] = 25.2
        self.assertNotIn("bounded", reporting.screening(metrics)["eligible"])

    def test_nonfinite_screening_rejected(self):
        metrics = self.metrics()
        metrics["unet", "bounded", 1]["psnr"] = float("nan")
        with self.assertRaises(ValueError):
            reporting.screening(metrics)

    def make_fixture(self, root, missing=None):
        out, parent = root / "outputs", root / "historical"
        out.mkdir()
        parent.mkdir()
        names = [f"image_{i:03d}.png" for i in range(80)]
        manifest = {
            "indices": {"validation": list(range(80))},
            "pairs": [{"filename": name} for name in names],
        }
        frozen = {
            "config": config(),
            "manifest_sha256": canonical(manifest),
            "historical_reference_sha256": "fixture",
        }
        (out / "frozen_protocol.json").write_text(json.dumps(frozen))
        (out / "manifest.json").write_text(json.dumps(manifest))
        reference = {"runs": []}
        for (backbone, condition, seed), metric in self.metrics().items():
            historical_run = seed == 0
            identity = {
                "backbone": backbone,
                "condition": condition,
                "seed": seed,
                "frozen_identity": "old-study" if historical_run else canonical(frozen),
            }
            relative = Path(backbone) / condition / f"seed_{seed}"
            directory = (parent if historical_run else out) / relative
            if historical_run:
                reference["runs"].append({**identity, "directory": str(relative)})
            if missing == (condition, seed):
                continue
            directory.mkdir(parents=True)
            (directory / "run.json").write_text(json.dumps(identity))
            history = [
                {
                    "epoch": epoch,
                    "train_loss": 0.5,
                    "val_loss": 0.6,
                    "validation": {
                        "psnr": metric["psnr"] - (2 - epoch),
                        "ssim": metric["ssim"],
                    },
                    "validation_count": 80,
                    "lr": 0.0002,
                    "scaler": 1024.0,
                }
                for epoch in (1, 2)
            ]
            (directory / "history.json").write_text(json.dumps(history))
            best = {"epoch": 2, **metric}
            (directory / "run_complete.json").write_text(
                json.dumps(
                    {
                        "identity": identity,
                        "epoch": 2,
                        "best": best,
                        "training_seconds": 2.0,
                        "peak_allocated_bytes": 100,
                    }
                )
            )
            (directory / "best.pt").write_bytes(f"fixture {condition} {seed}".encode())
            interventions = {}
            artifacts = {}
            for name in (
                config()["interventions"] if condition == "bounded" else ["normal"]
            ):
                path = directory / f"per_image_validation_{name}.csv"
                with path.open("w", newline="") as stream:
                    writer = csv.DictWriter(
                        stream, fieldnames=["filename", "psnr", "ssim"]
                    )
                    writer.writeheader()
                    for filename in names:
                        writer.writerow({"filename": filename, **metric})
                interventions[name] = metric
                artifacts[path.name] = digest(path)
            if condition in ("bounded", "unbounded"):
                (directory / "map_statistics.json").write_text("[]")
                artifacts["map_statistics.json"] = digest(
                    directory / "map_statistics.json"
                )
            d = {
                "identity": identity,
                "count": 80,
                "split": "validation",
                "checkpoint_epoch": 2,
                "checkpoint_sha256": digest(directory / "best.pt"),
                "normal": metric,
                "interventions": interventions,
                "artifact_hashes": artifacts,
                "resources": {
                    "parameters": 100,
                    "convolution_macs": 1000,
                    "latency": {"median_ms": 1.0},
                },
            }
            (directory / "diagnostics.json").write_text(json.dumps(d))
        return out, parent, reference

    def fixture_report(self, out, parent, reference):
        with (
            patch("diagnostics.report.output_root", return_value=out),
            patch("diagnostics.report.parent_root", return_value=parent),
            patch("diagnostics.report.verify_reference", return_value=reference),
            patch(
                "diagnostics.report.run_dir", lambda b, c, s: out / b / c / f"seed_{s}"
            ),
        ):
            reporting.report()

    def test_complete_report_retains_three_seeds_and_paired_summaries(self):
        with tempfile.TemporaryDirectory() as temporary:
            out, parent, reference = self.make_fixture(Path(temporary))
            self.fixture_report(out, parent, reference)
            value = json.loads((out / "reports/results.json").read_text())
            self.assertTrue(value["complete"])
            self.assertEqual(value["screening"]["eligible"], ["unbounded"])
            self.assertEqual(len(value["runs"]), 12)
            self.assertEqual(value["diagnosed_new_runs"], 8)
            rgb = [item for item in value["aggregates"] if item["condition"] == "rgb"]
            self.assertEqual(rgb[0]["seeds"], [1, 2])
            self.assertAlmostEqual(rgb[0]["psnr_mean"], 22.5)
            self.assertAlmostEqual(rgb[0]["psnr_sample_sd"], math.sqrt(12.5))
            self.assertAlmostEqual(rgb[1]["psnr_mean"], 21)
            with (out / "reports/paired_validation_differences.csv").open() as stream:
                pairs = list(csv.DictReader(stream))
            self.assertEqual(len(pairs), 3 * 5 * 80)
            self.assertEqual(len(value["per_image_summaries"]), 15)
            before = (out / "reports/report_complete.json").read_bytes()
            self.fixture_report(out, parent, reference)
            self.assertEqual(
                (out / "reports/report_complete.json").read_bytes(), before
            )
            self.assertFalse(value["test_evaluated"])
            self.assertIn(
                "not submission ready",
                (out / "reports/PAPER_FEASIBILITY.md").read_text(),
            )

    def test_incomplete_report_has_no_decision_or_completion_marker(self):
        with tempfile.TemporaryDirectory() as temporary:
            out, parent, reference = self.make_fixture(
                Path(temporary), missing=("rgb", 1)
            )
            self.fixture_report(out, parent, reference)
            value = json.loads((out / "reports/results.json").read_text())
            self.assertFalse(value["complete"])
            self.assertIsNone(value["screening"])
            self.assertEqual(value["diagnosed_new_runs"], 7)
            self.assertFalse((out / "reports/report_complete.json").exists())

    def test_incomplete_intervention_coverage_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            out, parent, reference = self.make_fixture(Path(temporary))
            path = out / "unet/bounded/seed_1/diagnostics.json"
            value = json.loads(path.read_text())
            del value["interventions"]["cross_image_swap"]
            path.write_text(json.dumps(value))
            with self.assertRaisesRegex(ValueError, "intervention coverage"):
                self.fixture_report(out, parent, reference)

    def test_changed_per_image_artifact_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            out, parent, reference = self.make_fixture(Path(temporary))
            path = out / "unet/rgb/seed_1/per_image_validation_normal.csv"
            path.write_text(path.read_text() + "corrupted\n")
            with self.assertRaisesRegex(ValueError, "artifact changed"):
                self.fixture_report(out, parent, reference)

    def test_changed_completed_report_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            out, parent, reference = self.make_fixture(Path(temporary))
            self.fixture_report(out, parent, reference)
            (out / "reports/results.csv").write_text("corrupted\n")
            with self.assertRaisesRegex(
                ValueError, "Completed report artifact changed"
            ):
                self.fixture_report(out, parent, reference)

    def test_historical_reference_rejects_corruption(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            path = root / "history.json"
            path.write_text("original")
            reference = {
                "parent_directory": config()["parent_directory"],
                "source_hashes": {},
                "artifact_hashes": {"history.json": digest(path)},
            }
            record = root / "historical_reference.json"
            record.write_text(json.dumps(reference))
            frozen = {"historical_reference_sha256": digest(record)}
            with (
                patch("diagnostics.historical.output_root", return_value=root),
                patch("diagnostics.historical.parent_root", return_value=root),
            ):
                historical.verify_reference(frozen)
                path.write_text("modified")
                with self.assertRaisesRegex(ValueError, "Historical input changed"):
                    historical.verify_reference(frozen)


if __name__ == "__main__":
    unittest.main()
