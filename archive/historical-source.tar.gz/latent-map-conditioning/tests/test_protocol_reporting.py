import json
import unittest
from pathlib import Path

import bootstrap  # noqa: F401

from conditioning.protocol import PARENT, ROOT, read_config, validate_manifest
from conditioning.report import factorial, mean_sd, paired_rows
from conditioning.experiment import optimizer_step_count
from diagnostics.protocol import PairedEpochDataset
import torch


class ProtocolTests(unittest.TestCase):
    def test_recipe_inherited_and_pilot_is_schedule_prefix(self):
        _, config = read_config(ROOT / "configs/h1_pilot_v2.json")
        self.assertEqual(config["training"], json.loads((PARENT / "configs/protocol.json").read_text()))
        self.assertEqual(config["budget"]["scheduler_epochs"], 100)
        self.assertEqual(config["budget"]["epochs"], 30)
        self.assertFalse(config["budget"]["early_stopping"])
        self.assertEqual(config, json.loads(json.dumps(config)))

    def test_no_test_loader(self):
        with self.assertRaisesRegex(ValueError, "Test image prediction"):
            PairedEpochDataset("test")

    def test_split_overlap_rejected(self):
        manifest = {"indices": {"train": list(range(720)), "validation": list(range(720, 800)), "test": list(range(800, 890))}}
        validate_manifest(manifest)
        manifest["indices"]["validation"][0] = 0
        with self.assertRaises(ValueError):
            validate_manifest(manifest)

    def test_factorial_and_missing_cells(self):
        scores = {"A0_rgb": 20, "A1_spatial": 21, "A2_global": 20.5, "A3_both": 22}
        self.assertEqual(factorial(scores)["interaction_db"], 0.5)
        del scores["A2_global"]
        with self.assertRaises(ValueError):
            factorial(scores)

    def test_paired_alignment_uses_filenames(self):
        candidate = [{"filename": "b", "psnr": 21, "ssim": 0.9}, {"filename": "a", "psnr": 23, "ssim": 0.95}]
        baseline = [{"filename": "a", "psnr": 22, "ssim": 0.94}, {"filename": "b", "psnr": 19, "ssim": 0.8}]
        rows = paired_rows(candidate, baseline)
        self.assertEqual([r["delta_psnr"] for r in rows], [1, 2])
        with self.assertRaises(ValueError):
            paired_rows(candidate, baseline[:1])
        with self.assertRaises(ValueError):
            paired_rows(candidate + candidate[:1], baseline)

    def test_seed_sd_is_not_image_or_population_sd(self):
        self.assertEqual(mean_sd([1, 2, 3]), {"mean": 2, "sample_sd": 1, "n_seeds": 3})
        self.assertIsNone(mean_sd([1])["sample_sd"])

    def test_optimizer_counts_updates_not_batches(self):
        parameter = torch.nn.Parameter(torch.ones(1))
        optimizer = torch.optim.AdamW([parameter], lr=0.01)
        self.assertEqual(optimizer_step_count(optimizer, parameter), 0)
        parameter.sum().backward()
        optimizer.step()
        self.assertEqual(optimizer_step_count(optimizer, parameter), 1)
        # A batch whose optimizer step is skipped must leave the count unchanged.
        optimizer.zero_grad(set_to_none=True)
        self.assertEqual(optimizer_step_count(optimizer, parameter), 1)


if __name__ == "__main__":
    unittest.main()
