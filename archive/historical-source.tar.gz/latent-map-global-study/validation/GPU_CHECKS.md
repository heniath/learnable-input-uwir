# GPU smoke, launch and initial diagnostics — 2026-10-21

The finite queue runs in tmux session `global-branch-followup-v1` using the
unchanged `uieb-latent-repro` environment. NVIDIA-SMI and PyTorch CUDA both
passed on the RTX 5060 Ti. The first launch stopped before preparation because
Warframe was active; no training began then. The revised preflight queued GPU
work safely, but Warframe had exited when preparation finished, so the wait
released with no other compute process and no shared-GPU override.

The new H1 seeds-1/2 study and follow-up source/config/environment/data identities
were prepared and frozen. The reuse audit records four rejected legacy RGB/joint
checkpoints (selected epochs 66/72/76/93 under a different training horizon),
reuse of all four seed-0 H1 checkpoints, and d=3 reuse of H1 global-only.

GPU smoke passed for all four H1 arms at seed 1 and d=1/3/6/12 at seed 0.
Dimension smoke measured exactly two actual AdamW updates per width, finite
gradients reaching every global output coordinate, matching batch/augmentation
hashes and exact restoration of model, optimizer, scheduler, scaler,
early-stopping and RNG state. These checks are not quality results and do not
establish deterministic CUDA continuation trajectories.

Both seed-0 diagnostics completed. Normal validation reproduced the selected
per-image metrics with zero PSNR/SSIM drift. Each mean used all 720 training
images with augmentation disabled and the model in eval mode. Independent
checks verified diagnostic artifact hashes, recomputed all three means from
the training CSV to within 1e-12, checked 80 validation filenames and confirmed
training/validation disjointness.

| Seed-0 checkpoint | Training SD of G coordinates | Numerical rank | Normal val PSNR | Training-mean G val PSNR | Delta |
|---|---|---:|---:|---:|---:|
| A2_global | 0.110135, 0.138845, 0.142783 | 3 | 21.89814 | 17.60449 | -4.29366 |
| A3_both | 0.145290, 0.108478, 0.128944 | 3 | 21.94947 | 17.84563 | -4.10384 |

This seed shows image-dependent, nonconstant global vectors and sensitivity to
this intervention. It does not establish physical meanings, independent causal
semantics or seed consistency. The spatial decision remains deferred.

The first research run, H1 RGB seed 1, reached epoch 2/30 with 360 actual
optimizer updates, zero AMP skips and a resumable `last.pt`. At that check,
all frozen follow-up source hashes and original seed-0 checkpoint/completion
hashes remained unchanged. See live `outputs/global_branch_followup_v1/job_status.json`,
`logs/`, `reports/FINDINGS.md`, the original H1 replication output and per-run
histories for subsequent progress. This document records initial checks only;
it does not claim the research queue is complete.
