# Provisional paper outline

Status: research outline, not submission ready. Eight new runs are planned;
their outcomes are not yet known. Writing choices: manuscript / research /
English / generic conference / full outline with provisional title.

Working title: **Learned Map Conditioning in Underwater Restoration:
Representation and Optimization Dependence**. This title identifies the study
topic; it does not claim a resolved mechanism or a novel architecture.

## Evidence first

Established local finding: under the pinned seed-0 UIEB diagnostic recipe, the
learned-map U-Net improves over RGB and a parameter-matched feature branch,
whereas the same heads/injection on NAFNet do not improve over RGB. A separate
NAFNet initialization intervention recovers a substantial part of that deficit.
The study boundaries are one seed, validation selection, unverified scene
independence, and a shared U-Net-derived recipe.

Research question: which aspects of learned spatial/global conditioning produce
the U-Net gain, and under what conditions does that gain persist?

Do not turn that question into a demonstrated causal argument until the
prospective controls supply evidence. The prior paper already contributes fixed
physics-prior input ablation; the new paper must explicitly add knowledge beyond
that work and established learned-guidance methods.

## Section outline

1. **Introduction:** explain the ambiguity between a useful input representation,
   extra capacity and optimization changes. Position the earlier fixed-prior
   study explicitly. Close with the research question, not a universal map claim.
2. **Related work:** compare fixed-prior guidance, predicted maps, learned
   degradation conditioning and latent control by mechanism/supervision/control
   evidence. Use NOVELTY.md and verify each reference against its primary source.
3. **Method and protocol:** define RGB, spatial/global latent heads, bounds and
   capacity control; specify the paired initialization and frozen diagnostic
   protocol. Distinguish this recipe from the published one.
4. **Experiments/results:** begin with the new seed-specific comparisons, then
   labeled seed-0-inclusive summaries. Present convergence, failures, bounds and
   resources. Add matched fixed/learned and local/global training ablations only
   after a separate frozen study; no placeholder numbers.
5. **Discussion:** interpret the actual repeatability result alongside the NAFNet
   contrast and the closest prior work. Explain what remains unresolved about
   mechanisms, physical semantics and generalization.
6. **Conclusion:** state only supported findings and their protocol boundaries.
   Derive the next experiment from the named uncertainty.
7. **Supplement/code:** retain manifests, environment, source identities,
   full per-image data, histories, resume evidence, and all negative outcomes.

## Claim-evidence map

| Possible claim | Evidence | Status |
|---|---|---|
| Maps benefit this U-Net beyond the tested capacity branch | Completed seed-0 controlled diagnostics | Supported for that single-seed protocol |
| The gain repeats across seeds | Eight-run replication, compared per seed | Evidence needed |
| Physical bounds are necessary | Bounded/unbounded comparison; current seed 0 retains gains without bounds | Not established |
| Global conditioning accounts for much of the gain | Spatial-mean inference retains a gain, but no separately trained global-only model | Inferred possibility; training controls needed |
| Initialization contributes to the NAFNet deficit | Five-condition initialization experiment | Supported for seed 0; broader replication needed for a general claim |
| Learned maps improve over published fixed priors | Comparable training/evaluation and matched dimensional/spatial controls | Evidence needed; existing scores incompatible |
| Maps estimate physical transmission/backscatter | Appropriate targets or independent physical validation | Unsupported |
| The method generalizes or is a competitive new method | Audited independent evaluation and faithful relevant baselines | Evidence needed |

## Figures/tables to prepare when evidence exists

- Architecture schematic distinguishing the published fixed spatial proxies from
  current learned spatial/global representations.
- Per-seed RGB/map/capacity comparisons with clearly labeled means/sample SDs.
- Learning curves and shared observed epoch-budget comparisons.
- Typical improvements and severe regressions, with paired metrics and filenames.
- Fixed/learned, local/global and resource comparisons after the required studies.

The negative NAFNet contrast and heterogeneous failures affect the conclusion
and belong in the main evidence, not only in supplementary material. Full hashes,
environment listings and detailed replay measurements belong in supplement/code.

## Missing inputs and evidence

- Publisher citation/DOI of the earlier paper and archived code/configuration
  corresponding to its described decoder/optimizer/augmentation.
- Completed replication findings; no abstract asserting repeatability is drafted.
- A distinct contribution validated against the closest prior work.
- New fixed-versus-learned and local/global studies that isolate their factors.
- Independently audited generalization evaluation and faithful modern baselines.
- Venue/deadline chosen from the resulting evidence; author-approved contribution
  wording and applicable submission requirements.

## Why this structure

- Leads with an observed contrast rather than a promised new module.
- Separates the prior contribution, completed diagnostics and prospective evidence.
- Makes failure cases and comparability constraints part of the argument.

To redirect this outline, identify the claim or section to change; preserve the
remaining evidence boundaries and terminology from TERMINOLOGY.md.
