import json
import unittest

import bootstrap
import numpy as np
import torch

from conditioning.models import ConditionedUNet
from conditioning.protocol import ROOT as TRAINING, local_sources, read_config
from diagnostics.protocol import PairedEpochDataset
from global_study.diagnostic import vector_statistics
from global_study.models import GlobalLatentUNet
from global_study.protocol import config
from global_study.report import mean_sd

torch.set_num_threads(2)


class StudyTests(unittest.TestCase):
    def test_d3_reuses_exact_model_state_and_function(self):
        baseline = ConditionedUNet("A2_global", 0).eval()
        candidate = GlobalLatentUNet(3, 0).eval()
        candidate.load_state_dict(baseline.state_dict(), strict=True)
        self.assertEqual(candidate.parameter_counts(), baseline.parameter_counts())
        x = torch.rand(1, 3, 256, 256)
        with torch.inference_mode():
            torch.testing.assert_close(candidate(x), baseline(x), rtol=0, atol=0)
            prediction, maps = candidate(x, return_maps=True)
            torch.testing.assert_close(prediction, candidate(x, maps_override=maps), rtol=0, atol=0)

    def test_shared_initialization_all_widths(self):
        reference = ConditionedUNet("A2_global", 2)
        original = reference.state_dict()
        replaced = {"base.backbone.enc1.net.0.weight", "base.background_extractor.net.7.weight",
                    "base.background_extractor.net.7.bias"}
        for dimension in (1, 6, 12):
            candidate = GlobalLatentUNet(dimension, 2)
            self.assertFalse(hasattr(candidate.base, "transmission_extractor"))
            self.assertEqual(candidate.base.backbone.enc1.net[0].in_channels, 6 + dimension)
            self.assertEqual(candidate.parameter_counts()["dormant_input_weights"], 3 * 64 * 3 * 3)
            for name, value in candidate.state_dict().items():
                if name not in replaced:
                    torch.testing.assert_close(value, original[name], rtol=0, atol=0)
            overlap = min(3, dimension)
            torch.testing.assert_close(candidate.base.background_extractor.net[-2].weight[:overlap],
                                       reference.base.background_extractor.net[-2].weight[:overlap], rtol=0, atol=0)
            torch.testing.assert_close(candidate.base.backbone.enc1.net[0].weight[:, :6 + overlap],
                                       reference.base.backbone.enc1.net[0].weight[:, :6 + overlap], rtol=0, atol=0)

    def test_dimension_override_shape_and_zero_spatial_guards(self):
        model = GlobalLatentUNet(6).eval()
        x = torch.rand(1, 3, 256, 256)
        with torch.inference_mode():
            with self.assertRaises(ValueError):
                model(x, maps_override=(torch.zeros_like(x), torch.ones(1, 3, 1, 1)))
            with self.assertRaises(ValueError):
                model(x, maps_override=(torch.ones_like(x), torch.ones(1, 6, 1, 1)))
            with self.assertRaises(FloatingPointError):
                model(x, maps_override=(torch.zeros_like(x), torch.full((1, 6, 1, 1), float("nan"))))

    def test_no_unrequested_dimension_or_test_loader(self):
        for dimension in (0, 2, 24, True):
            with self.assertRaises(ValueError):
                GlobalLatentUNet(dimension)
        with self.assertRaisesRegex(ValueError, "Test image prediction"):
            PairedEpochDataset("test")

    def test_covariance_rank_does_not_misclassify_roundoff(self):
        collapsed = vector_statistics(np.full((720, 3), 0.4))
        self.assertEqual(collapsed["numerical_rank"], 0)
        self.assertEqual(collapsed["effective_rank"], 0)
        self.assertTrue(all(collapsed["numerically_constant_coordinates"]))
        x = np.linspace(0, 1, 720)
        redundant = vector_statistics(np.stack((x, x, 1 - x), axis=1))
        self.assertEqual(redundant["numerical_rank"], 1)
        self.assertAlmostEqual(redundant["effective_rank"], 1)
        self.assertFalse(any(redundant["numerically_constant_coordinates"]))
        self.assertAlmostEqual(redundant["mean"][0], 0.5)
        with self.assertRaises(ValueError):
            vector_statistics([[float("nan")], [0.2]])

    def test_replication_recipe_and_parent_sources_unchanged(self):
        cfg = config()
        original_path, original = read_config(TRAINING / "configs" / cfg["h1_seed0_config"])
        _, repeat = read_config(TRAINING / "configs" / cfg["h1_seeds12_config"])
        for key in ("training", "budget", "selection", "model_specs"):
            self.assertEqual(original[key], repeat[key])
        self.assertEqual(repeat["seeds"], [1, 2])
        self.assertEqual(cfg["dimension_seeds"], [0])
        frozen = json.loads((TRAINING / "outputs/conditioning_h1_pilot_v2/frozen.json").read_text())
        self.assertEqual(local_sources(original_path), frozen["source_hashes"])

    def test_seed_sd_uses_paired_seed_contrasts(self):
        self.assertEqual(mean_sd([1, 2, 3]), {"mean": 2, "sample_sd": 1, "n_seeds": 3})
        self.assertIsNone(mean_sd([1])["sample_sd"])


if __name__ == "__main__":
    unittest.main()
