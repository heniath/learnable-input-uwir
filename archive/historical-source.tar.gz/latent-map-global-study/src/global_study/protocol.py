"""Freeze this follow-up without modifying either completed parent study."""

import csv
import json
import shutil
from pathlib import Path

import numpy as np

from conditioning import protocol as parent
from diagnostics.protocol import atomic_json, canonical, digest

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "configs/study.json"
TRAINING = parent.ROOT


def config():
    value = json.loads(CONFIG.read_text())
    if value["dimensions"] != [1, 3, 6, 12] or value["dimension_seeds"] != [0]:
        raise ValueError("Only the authorized initial dimension screen is enabled")
    return value


def output_root():
    return ROOT / "outputs" / config()["experiment_id"]


def sources():
    files = [ROOT / "README.md", CONFIG]
    for folder in ("src", "scripts", "tests"):
        files.extend((ROOT / folder).rglob("*.py"))
    return {str(p.relative_to(ROOT)): digest(p) for p in sorted(files)}


def parent_studies(check_data=True):
    cfg = config()
    studies = {}
    for scope in ("h1_seed0_config", "h1_seeds12_config"):
        path, resolved = parent.read_config(TRAINING / "configs" / cfg[scope])
        if resolved["budget"] != cfg["budget"]:
            raise ValueError("Follow-up and H1 pilot budgets differ")
        studies[scope] = parent.verify(path, resolved, check_data=check_data)
    if studies["h1_seed0_config"]["manifest_sha256"] != studies["h1_seeds12_config"]["manifest_sha256"]:
        raise ValueError("H1 reference and replication manifests differ")
    return studies


def h1_directory(seed, condition):
    key = "h1_seed0_config" if seed == 0 else "h1_seeds12_config"
    _, resolved = parent.read_config(TRAINING / "configs" / config()[key])
    return TRAINING / "outputs" / resolved["experiment_id"] / "runs" / f"seed_{seed}" / condition


def verify_run(directory, identity=None):
    saved = json.loads((directory / "complete.json").read_text())
    run = json.loads((directory / "run.json").read_text())
    if identity is not None and saved["identity"] != identity:
        raise ValueError("Completed run identity mismatch")
    if any(run.get(k) != v for k, v in saved["identity"].items()):
        raise ValueError("Run and completion identities differ")
    if saved["final_epoch"] != 30:
        raise ValueError("Expected the fixed 30-epoch endpoint")
    for name, key in (("best.pt", "best_sha256"), ("metrics_per_image.csv", "per_image_sha256")):
        if digest(directory / name) != saved[key]:
            raise ValueError(f"Completed artifact changed: {directory / name}")
    with (directory / "metrics_per_image.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    manifest = json.loads((parent.ARCHIVE / "manifest.json").read_text())
    names = [manifest["pairs"][i]["filename"] for i in manifest["indices"]["validation"]]
    if [r["filename"] for r in rows] != names:
        raise ValueError("Selected validation filename order differs")
    for key in ("psnr", "ssim"):
        values = [float(row[key]) for row in rows]
        if not np.isfinite(values).all() or abs(np.mean(values) - saved["best"][key]) > 1e-5:
            raise ValueError("Selected validation metrics differ")
    return saved, rows


def provenance(check_data=True):
    studies = parent_studies(check_data)
    reference_runs = {}
    identity = canonical(studies["h1_seed0_config"])
    for condition in ("A0_rgb", "A1_spatial", "A2_global", "A3_both"):
        directory = h1_directory(0, condition)
        saved, _ = verify_run(directory, {"seed": 0, "condition": condition, "frozen_identity": identity})
        reference_runs[condition] = {"directory": str(directory), "checkpoint_sha256": saved["best_sha256"],
                                     "complete_sha256": digest(directory / "complete.json")}
    return {"config": config(), "sources": sources(), "parent_identities": {key: canonical(value) for key, value in studies.items()},
            "manifest_sha256": studies["h1_seed0_config"]["manifest_sha256"],
            "environment": studies["h1_seed0_config"]["environment"], "reference_seed0": reference_runs}


def prepare():
    cfg = config()
    path, resolved = parent.read_config(TRAINING / "configs" / cfg["h1_seeds12_config"])
    parent.prepare(path, resolved)
    frozen = provenance()
    out = output_root()
    target = out / "frozen.json"
    if target.exists():
        if json.loads(target.read_text()) != frozen:
            raise ValueError("Study identity changed; use a new experiment ID")
        return frozen
    out.mkdir(parents=True, exist_ok=True)
    for relative in frozen["sources"]:
        destination = out / "source_snapshot" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / relative, destination)
    manifest = json.loads((parent.ARCHIVE / "manifest.json").read_text())
    atomic_json(out / "manifest.json", manifest)
    atomic_json(out / "frozen.json", frozen)
    candidates = []
    legacy = ROOT.parent / "latent-map-unet-replication/outputs/unet_map_replication_v1/unet"
    for seed in (1, 2):
        for condition in ("rgb", "bounded"):
            marker = legacy / condition / f"seed_{seed}/run_complete.json"
            if marker.exists():
                old = json.loads(marker.read_text())
                candidates.append({"completion": str(marker), "checkpoint": str(marker.parent / "best.pt"),
                                   "selected_epoch": old["best"]["epoch"], "final_epoch": old["epoch"],
                                   "eligible": False, "reason": "100-epoch/early-stopping protocol, selected epoch beyond 30; not the H1 30-epoch pilot. No legacy global-only arm."})
    eligible = []
    for seed in (1, 2):
        for condition in resolved["conditions"]:
            directory = h1_directory(seed, condition)
            if (directory / "complete.json").exists():
                verify_run(directory, {"seed": seed, "condition": condition,
                                       "frozen_identity": frozen["parent_identities"]["h1_seeds12_config"]})
                eligible.append(str(directory))
    atomic_json(out / "reuse_audit.json", {"reused_seed0": frozen["reference_seed0"], "legacy_candidates": candidates,
                                            "eligible_existing_seeds12": eligible,
                                            "dimension_d3": "Reuse H1 A2_global for each matching dimension-study seed; never retrain d=3"})
    return frozen


def verify(check_data=True):
    expected = json.loads((output_root() / "frozen.json").read_text())
    if provenance(check_data) != expected:
        raise ValueError("Frozen follow-up source/config/environment/reference changed")
    return expected


def verify_diagnostic(directory, identity):
    marker = directory / "complete.json"
    if not marker.exists():
        return False
    saved = json.loads(marker.read_text())
    if saved["identity"] != identity:
        raise ValueError("Completed diagnostic identity mismatch")
    for name, expected in saved["artifact_hashes"].items():
        if digest(directory / name) != expected:
            raise ValueError("Completed diagnostic artifact changed")
    return True
