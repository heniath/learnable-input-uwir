# Saved-checkpoint component ablation: interpretation

Experiment/run: `map_components_v1`, completed 2026-10-16. Hypothesis: separate
spatial-map and global-map dependence in trained NAFNet. This is an inference
intervention experiment; no training, fine-tuning or new checkpoint selection.

The three intact checkpoints reproduced every saved validation-image PSNR and
SSIM exactly. Evaluation covered the same 80 validation images, seed 0 and the
parent preprocessing/metrics. Runtime was 22.46 seconds; PyTorch peak allocated
GPU memory was 363,690,496 bytes. These are whole-ablation execution measurements,
not model inference benchmarks. The existing environment and datasets were used
without changes. Parent identities, checkpoint hashes, source snapshot and
per-image artifacts are recorded in `outputs/map_components_v1/`.

## Findings

The primary unbounded zero-initialized checkpoint scored 24.0982 dB, versus
24.1176 dB for separately trained RGB. Zeroing spatial maps reduced its PSNR by
1.2180 dB; zeroing global maps reduced it by 0.2056 dB. Replacing each spatial
channel with its own image mean reduced PSNR by 1.1089 dB. Spatial maps therefore
carry spatial structure used by this checkpoint, beyond channelwise averages.

Donor swaps preserve actual predicted map values while breaking the image/map
pairing. Spatial-only swaps cost 2.2893 dB (unbounded) and 1.3459 dB (bounded).
Global-only swaps cost 0.3334 and 0.3649 dB, respectively. Both checkpoints show
greater sensitivity to spatial-map swaps under this intervention definition.
These effect sizes are not an additive or uniquely identifiable contribution
of either branch; the components were trained jointly and can interact.

The bounded checkpoint was especially sensitive to zero spatial maps: a
5.4437 dB drop, versus 0.6335 dB for per-image spatial means and 1.3459 dB for
donor swaps. Zero lies outside the bounded spatial head's [0.1, 1] range. This
makes the zeroing result particularly vulnerable to a distribution-shift
explanation; its magnitude should not be interpreted as physical importance.
Donor swaps can also be out of distribution through incompatible image/map
combinations.

## Decision and limits

NAFNet uses both auxiliary branches in these checkpoints, with a larger measured
sensitivity to spatial interventions. The global branch's modest donor-swap
effect is compatible with the proposed SCA overlap but does not establish it.
The experiment did not manipulate SCA.

Dependence on maps does not establish benefit from training with them: neither
intact map checkpoint exceeded the separately trained RGB control. Removing
maps after joint training does not recover an independently trained RGB model.
The next training comparison should isolate spatial-only and global-only maps
against combined maps and RGB, retaining shared initialization and the frozen
protocol. Testing SCA redundancy requires its own factorial training comparison.
Neither follow-up is launched by this saved-checkpoint experiment.

Only one seed and validation-selected checkpoints were examined; no statistical
significance or physical map interpretation is claimed. Test images were not
predicted. The inherited study already had historical test exposure and does
not establish scene independence.
