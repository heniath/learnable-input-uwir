# Global latent dimension replication

Experiment `global_dimension_replication_v1` implements four user-authorized
new runs: d6/seed1, d12/seed1, d6/seed2, d12/seed2. Reuse d=3 at all three
seeds and d=6/12 seed 0 in place. The resulting validation table has nine cells.
Existing conditioning/global-study/test source, configs and artifacts are not
edited. Use the existing `uieb-latent-repro` environment; install nothing.

All runs inherit the frozen UIEB 720/80/90 manifest, train/validation-only
loaders, 256-pixel preprocessing, paired augmentation, batch4/workers2, original
L1+VGG loss, AdamW and 100-epoch cosine schedule. Train from scratch for exactly
30 epochs without early stopping. Select the maximum validation (PSNR, SSIM)
tuple, keeping the earliest exact tie. Reuse GlobalLatentUNet and the original
component builder so head/input initialization and training RNG reset match the
seed-0 screen. Parameters and MACs vary with dimension and are reported.

Run from this directory with the environment's Python:

```bash
python -B -m unittest discover -s tests -v
python -B scripts/run.py prepare
python -B scripts/run.py smoke
python -B scripts/run.py train --dimension 6 --seed 1
python -B scripts/run.py diagnose --dimension 6 --seed 1
python -B scripts/run.py report
python -B scripts/run_logged.py
```

Preparation checks the completed parent study, source/environment/data identity,
five reusable checkpoints and their histories/metrics, and reused diagnostic
artifact hashes. New source/config/manifest identities and snapshots are saved
separately. Each operation verifies that frozen identity. Run the finite logged
queue in tmux; the runner updates job status/reports after every completed stage.
It waits if another GPU compute process is active; the existing GNOME desktop
service and observed idle Warframe launcher (at most 32 MiB, GPU at most 10%,
at least 4 GiB free) are recorded preflight exceptions. It stops on failure and
never stops other processes or changes batch size to recover from OOM.

Completed runs are hash-checked and preserved. Interrupted training resumes
from last.pt with model/optimizer/scheduler/scaler/early-stopping/RNG state.
Best/last transaction disagreement or a partial diagnostic requires inspection.
CUDA trajectories need not replay bit for bit. Smoke is a functionality check,
not quality evidence; it checks two real optimizer updates, all global-coordinate
gradients and exact full-state restoration for each new dimension/seed pair.

Each new selected checkpoint gets training-only G diagnostics: all 720 training
images with augmentation disabled, normal validation reproduction on 80 images,
coordinate variation/effective rank and replacement by that checkpoint's
training mean. Reuse the five existing diagnostics; compute no training mean
from validation/test and perform no new test predictions.

Reports give nine validation cells, per-seed paired d6-d3/d12-d3/d12-d6 effects,
median image differences/win counts, seed means and sample SD, parameters/MACs,
update/AMP counts, runtime/VRAM and diagnostic summaries. Missing evidence stays
explicit. A dimension meets the prespecified descriptive repeatability rule
only when both new seeds improve PSNR without reducing SSIM versus same-seed
d=3. This is not a significance test or an automatic architecture decision.
Pilot convergence, inherited scene-independence limits and prior test exposure
remain limitations. No later study launches automatically.
