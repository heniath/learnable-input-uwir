# Preflight validation — 2026-10-21

Existing environment command:

```bash
/home/heniath/miniforge3/envs/uieb-latent-repro/bin/python -B -m unittest discover -s tests -v
```

Seven CPU tests passed in 3.738 seconds. They check exact d=3 compatibility
with H1 A2_global (state, output and no-op override), common parameter/input/head
initialization across d, dormant spatial columns, invalid dimensions/overrides,
test-loader rejection, constant/redundant-vector rank and finite values,
unchanged H1 recipe/source identity, and sample SD across paired seed contrasts.

The user selected a seed-0-only dimension screen before source preparation.
The frozen config reflects that choice. GPU smoke and research executions are
recorded separately under the experiment output; CPU tests are functionality
evidence, not experimental results.

The workspace and project roots are not Git repositories; `git status --short`
reported that fact. New source/config snapshots and hashes record these changes.
The only addition inside the existing conditioning project is the new H1
seeds-1/2 configuration; existing H1/H2 source and frozen configs are unchanged.
No package, dataset, checkpoint or system setting was changed. The existing
Kornia CUDA AMP deprecation warning remains visible.
