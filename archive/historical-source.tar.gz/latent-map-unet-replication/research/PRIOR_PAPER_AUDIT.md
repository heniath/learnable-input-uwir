# Relationship to the accepted/published paper

Source: supplied `2026_EIDT_UWIR.pdf`, *Assessing the Role of Physics-Informed
Priors in Underwater Image Restoration*, 12 pages. Authors: Khac Nhat Truong
Dinh, Thai Hung Nguyen, Tuan Hung Phan, Cong Phuc Truong, Thi-Thu-Hong Phan.
Accepted/published status comes from the author; no publisher citation/DOI was
supplied. PDF provenance/hash: `papers/SOURCE.json`. Original is linked in place;
extracted text is preserved for traceability. The published file is not edited.

## Existing contribution and new question

Pages 2–3 already propose controlled input ablations on a fixed U-Net. Pages 5–6
and Algorithm 1 describe offline, normalized **one-channel spatial** transmission
and backscatter proxies. Four configurations have 3/4/4/5 input channels. Pages
6–9 report UIEB/EUVP test comparisons over three seeds. Page 11 proposes joint
estimation as future work. These contributions belong to the prior paper.

The current diagnostic maps have **three dense channels plus three global
channels**, learned through the restoration objective with reconstruction and
smoothness weights zero. They have no map ground-truth supervision. Replacing
the paper's dense backscatter proxy with a learned global descriptor also changes
the representation's role and spatial structure. It is not merely an end-to-end
version of the same two maps.

The new hypothesis concerns the utility of learned local/global representations
beyond this particular added-capacity control, output bounds and optimization
dependence, including the observed cross-backbone contrast. Repeatability and
causal explanation remain open. A controlled input ablation alone is not a new
contribution relative to the earlier paper.

## Protocol and architecture differences to resolve

| Item | Supplied paper | Current diagnostic source | Consequence |
|---|---|---|---|
| Map generation | Algorithm 1 offline DCP/guided filter and derived spatial backscatter | Separate learned 3-channel spatial/global heads | Changes learning, channel count and spatial/global meaning together |
| Optimizer | Adam, p.7 | AdamW, weight decay 1e-5 | Different experimental condition |
| Augmentation | Horizontal flips and 90-degree rotations, p.7 | Horizontal/vertical flips, stateless per filename/seed/epoch | Do not call this an exact paper-protocol reproduction |
| Decoder | 1×1 channel projection before refinement, p.5 | Inspected Up block concatenates into DoubleConv directly | Manuscript/source correspondence needs an author/source audit |
| Initialization | Independent random runs, p.7 | Paired common RGB backbone within each seed | Improved comparison control, different protocol |
| Split | 720/80/90 UIEB described, p.6 | Exact inherited duplicate-grouped manifest | Equal counts do not establish identical samples |
| Evaluation | Published UIEB/EUVP test scores | Validation80, resized/center-cropped diagnostic evaluation | Scores cannot be directly combined |
| Efficiency | Described as lightweight | Diagnostic U-Net ~31.4M parameters/~56.7 conv GMACs | Measure resources; do not adopt lightweight wording without comparative evidence |

These are discrepancies between the supplied description and inspected code,
not proof that the published experiments used the current implementation.
Find the actual archived published source/configurations before making a faithful
reproduction claim. The eight-run replication intentionally retains the diagnostic
recipe and does not silently repair these differences.

## Matched comparison interpretation

Table 2's five-channel versus matched RGB PSNR differences are **+0.116 dB on
UIEB** (21.012 − 20.896) and **+0.186 dB on EUVP** (26.644 − 26.458). The +4.454
dB EUVP difference in Section 4.1 compares the five-channel result to a different
representative U-Net score in Table 1, not Table 2's matched RGB ablation.
That value must not be attributed to adding physics channels alone.

The current seed-0 +1.5713 dB is validation-only under a different protocol.
Do not present it as an improvement over the published test result. Published
comparators also require source/split/evaluator provenance before joining a
common-protocol leaderboard.

## Requirements for the next paper

- Cite the prior publication and state the added research question explicitly.
- Freeze a later fixed-versus-learned comparison that controls channel count and
  spatial/global structure, or labels these changes as separate factors.
- Retain RGB and appropriately matched capacity controls; do not equate parameter
  matching with full architectural/compute equivalence.
- Establish repeatability, examine per-image failures, and evaluate audited data
  outside model selection before claiming generalization.
- Support physical interpretation with appropriate supervision/validation if
  that becomes a claim; bounds and image-formation notation alone are insufficient.
- Verify venue policies and contribution requirements after selecting a target.
