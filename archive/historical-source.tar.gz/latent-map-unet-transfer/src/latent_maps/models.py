"""Fresh pilot heads on the pinned standard U-Net, with paired initialization."""

import torch
from torch import nn
from torch.nn import functional as F

from ._unet import UNet5ch

CONDITIONS = ("rgb", "zero_maps", "learned_maps", "capacity")


def reflect_pad(x, right, bottom):
    # Repeated reflection also handles images smaller than the training crop.
    while right or bottom:
        r = min(right, max(x.shape[-1] - 1, 1))
        b = min(bottom, max(x.shape[-2] - 1, 1))
        mode = "reflect" if x.shape[-1] > r and x.shape[-2] > b else "replicate"
        x = F.pad(x, (0, r, 0, b), mode=mode)
        right -= r
        bottom -= b
    return x


class MapPredictor(nn.Module):
    def __init__(self, width=16):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, width, 3, padding=1),
            nn.SiLU(),
            nn.Conv2d(width, width, 3, padding=1),
            nn.SiLU(),
        )
        self.spatial = nn.Conv2d(width, 3, 1)
        self.global_projection = nn.Linear(width, 3)
        # Both paths stay differentiable on the first update; input weights are nonzero.
        for layer in (self.spatial, self.global_projection):
            nn.init.normal_(layer.weight, std=0.001)
            nn.init.zeros_(layer.bias)

    def forward(self, rgb):
        f = self.features(rgb)
        spatial = self.spatial(f)
        global_map = self.global_projection(f.mean((-2, -1)))[..., None, None]
        return torch.cat((spatial, global_map.expand(-1, -1, *rgb.shape[-2:])), 1)


class CapacityBlock(nn.Module):
    def __init__(self, width, bottleneck=19):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(width, bottleneck, 1),
            nn.SiLU(),
            nn.Conv2d(bottleneck, bottleneck, 3, padding=1),
            nn.SiLU(),
            nn.Conv2d(bottleneck, width, 1),
        )
        nn.init.normal_(self.layers[-1].weight, std=0.001)
        nn.init.zeros_(self.layers[-1].bias)

    def forward(self, features):
        return features + self.layers(features)


class EnhancementModel(nn.Module):
    def __init__(
        self,
        condition,
        seed=0,
        width=64,
        map_width=16,
        capacity_width=20,
    ):
        super().__init__()
        if condition not in CONDITIONS:
            raise ValueError(f"Unknown condition: {condition}")
        self.condition = condition
        # Construct all common parameters before any condition-specific branch.
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed)
            self.backbone = UNet5ch(
                in_channels=3, features=tuple(width * 2**i for i in range(4))
            )
            torch.manual_seed(seed + 10000)
            if condition in ("zero_maps", "learned_maps"):
                old = self.backbone.enc1.net[0]
                expanded = nn.Conv2d(9, width, 3, padding=1, bias=False)
                with torch.no_grad():
                    expanded.weight[:, :3].copy_(old.weight)
                self.backbone.enc1.net[0] = expanded
            self.map_predictor = (
                MapPredictor(map_width) if condition == "learned_maps" else None
            )
            torch.manual_seed(seed + 20000)
            self.capacity = (
                CapacityBlock(width, capacity_width)
                if condition == "capacity"
                else nn.Identity()
            )

    def forward(self, rgb, return_maps=False):
        if rgb.ndim != 4 or rgb.shape[1] != 3:
            raise ValueError("Expected N×3×H×W RGB input")
        h, w = rgb.shape[-2:]
        rgb = reflect_pad(rgb, (-w) % 16, (-h) % 16)
        maps = None
        if self.condition == "learned_maps":
            maps = self.map_predictor(rgb)
        elif self.condition == "zero_maps":
            maps = rgb.new_zeros(rgb.shape[0], 6, *rgb.shape[-2:])
        inp = rgb if maps is None else torch.cat((rgb, maps), 1)
        b = self.backbone
        e1 = self.capacity(b.enc1(inp))
        e2 = b.enc2(e1)
        e3 = b.enc3(e2)
        e4 = b.enc4(e3)
        bn = b.bottleneck(e4)
        enhanced = b.head(b.dec1(b.dec2(b.dec3(b.dec4(bn, e4), e3), e2), e1))
        enhanced = enhanced[..., :h, :w]
        return (
            (enhanced, None if maps is None else maps[..., :h, :w])
            if return_maps
            else enhanced
        )


def parameter_count(model):
    return sum(p.numel() for p in model.parameters())


def convolution_macs(model, shape=(1, 3, 256, 256)):
    """Conv/linear multiply-accumulates only; excludes gates, pooling and normalization."""
    counts, handles = [], []

    def count(module, inputs, output):
        if isinstance(module, nn.Conv2d):
            counts.append(
                output.numel()
                * (module.in_channels // module.groups)
                * module.kernel_size[0]
                * module.kernel_size[1]
            )
        elif isinstance(module, nn.Linear):
            counts.append(output.numel() * module.in_features)

    for module in model.modules():
        if isinstance(module, (nn.Conv2d, nn.Linear)):
            handles.append(module.register_forward_hook(count))
    try:
        with torch.inference_mode():
            model(torch.zeros(shape, device=next(model.parameters()).device))
    finally:
        for handle in handles:
            handle.remove()
    return sum(counts)
