"""Dimension runs use the original loss, epoch engine and durable state format."""

import json

import numpy as np
import torch

from conditioning.experiment import TraceLoader, evaluate, finish, optimizer_step_count
from conditioning.protocol import write_csv
from diagnostics.engine import epoch_step, payload, restore
from diagnostics.models import convolution_macs
from diagnostics.protocol import atomic_json, canonical, configure_weights, loader, seed_original
from diagnostics.validation import compare_state
from uwir.cli.train import EarlyStopping, train_epoch
from uwir.losses import CompositeLoss
from uwir.training.checkpoint import save_checkpoint
from uwir.training.schedulers import CosineAnnealingRestartLR

from .models import GlobalLatentUNet
from .protocol import config, h1_directory, output_root, verify_run


def make_objects(dimension, seed, frozen):
    from diagnostics.protocol import config as training_config
    c = training_config()
    configure_weights()
    seed_original(seed)
    model = GlobalLatentUNet(dimension, seed).cuda()
    w = c["loss_weights"]
    loss = CompositeLoss(lambda_l1=w["l1"], lambda_perc=w["perceptual"], lambda_ssim=w["ssim"], device="cuda")
    optimizer = torch.optim.AdamW(model.parameters(), lr=c["lr"], weight_decay=c["weight_decay"])
    scheduler = CosineAnnealingRestartLR(optimizer, periods=[frozen["config"]["budget"]["scheduler_epochs"]],
                                       restart_weights=[1.0], eta_min=c["eta_min"])
    scaler = torch.amp.GradScaler("cuda", init_scale=c["amp_initial_scale"])
    early = EarlyStopping(patience=c["patience"], min_delta=c["min_delta"], mode="max")
    seed_original(seed)
    return model, loss, optimizer, scheduler, scaler, early


def smoke(frozen):
    out = output_root()
    marker = out / "smoke.json"
    if marker.exists():
        previous = json.loads(marker.read_text())
        if previous.get("passed") and previous["frozen_identity"] == canonical(frozen):
            print("Preserving completed dimension smoke", flush=True)
            return
        raise ValueError("Existing smoke identity is invalid")
    directory = out / "smoke"
    if directory.exists():
        raise ValueError("Partial smoke exists; inspect before rerun")
    directory.mkdir()
    seed = config()["dimension_seeds"][0]
    results = {}
    for dimension in config()["dimensions"]:
        objects = make_objects(dimension, seed, frozen)
        model = objects[0]
        traced = TraceLoader(loader("train", seed=seed, epoch=1, limit=8))
        loss, _ = train_epoch(model, traced, objects[2], objects[1], torch.device("cuda"), scaler=objects[4])
        if not np.isfinite(loss):
            raise FloatingPointError("Non-finite dimension smoke loss")
        if any(p.grad is None or not torch.isfinite(p.grad).all() for p in model.parameters()):
            raise ValueError("Missing/non-finite dimension smoke gradients")
        head_grad = model.base.background_extractor.net[-2].weight.grad.flatten(1).abs().sum(1)
        if not (head_grad > 0).all():
            raise ValueError("A global coordinate receives no smoke gradient")
        steps = optimizer_step_count(objects[2], model.base.backbone.enc1.net[0].weight)
        if steps != 2:
            raise ValueError("Expected two actual smoke optimizer updates")
        means, rows = evaluate(model, seed, limit=4)
        write_csv(directory / f"d_{dimension}_validation.csv", rows)
        state = payload(objects, epoch=1, history=[{"validation": means}], best=means,
                        identity={"smoke_dimension": dimension})
        checkpoint = directory / f"d_{dimension}_roundtrip.pt"
        save_checkpoint(checkpoint, state)
        del state
        saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
        restore(objects, saved)
        actual = payload(objects, epoch=1, history=saved["history"], best=saved["best"], identity=saved["identity"])
        stats = {"bitwise_equal": True, "max_absolute_tensor_difference": 0.0}
        for key in ("model", "optimizer", "scheduler", "scaler", "early_stopping", "rng_state"):
            compare_state(saved[key], actual[key], stats, key)
        if not stats["bitwise_equal"]:
            raise ValueError("Dimension smoke full-state restoration failed")
        results[str(dimension)] = {"train_loss": loss, "validation": means, "actual_updates": steps,
                                   "checkpoint_roundtrip_exact": True, "batch_hashes": traced.batch_hashes,
                                   "parameters": model.parameter_counts()}
        print(f"Smoke passed d={dimension}, updates={steps}, full state exact", flush=True)
        del model, objects, saved, actual
        torch.cuda.empty_cache()
    hashes = [row["batch_hashes"] for row in results.values()]
    if any(value != hashes[0] for value in hashes):
        raise ValueError("Dimension smoke batch/augmentation pairing differs")
    atomic_json(marker, {"passed": True, "frozen_identity": canonical(frozen), "results": results,
                         "scope": "Two real updates and four validation images per dimension; functionality only"})


def train(dimension, seed, frozen):
    c = config()
    if dimension not in c["dimensions"] or seed not in c["dimension_seeds"]:
        raise ValueError("Dimension/seed outside frozen screen")
    if dimension == 3:
        verify_run(h1_directory(seed, "A2_global"))
        print(f"Reusing H1 A2_global d=3 seed={seed}; no retraining", flush=True)
        return
    smoke_result = json.loads((output_root() / "smoke.json").read_text())
    if not smoke_result["passed"] or smoke_result["frozen_identity"] != canonical(frozen):
        raise ValueError("Pass dimension smoke before training")
    condition = f"d_{dimension}"
    directory = output_root() / "runs" / f"seed_{seed}" / condition
    directory.mkdir(parents=True, exist_ok=True)
    identity = {"condition": condition, "seed": seed, "frozen_identity": canonical(frozen)}
    if (directory / "complete.json").exists():
        verify_run(directory, identity)
        print(f"Preserving completed {condition}/seed_{seed}", flush=True)
        return
    objects = make_objects(dimension, seed, frozen)
    model = objects[0]
    model.eval()
    macs = convolution_macs(model)
    history, best, start, peak = [], None, 1, 0
    last = directory / "last.pt"
    if last.exists():
        saved = torch.load(last, map_location="cpu", weights_only=False)
        if saved["identity"] != identity:
            raise ValueError("Dimension resume identity mismatch")
        if saved["complete"]:
            finish(directory, saved)
            return
        selected = torch.load(directory / "best.pt", map_location="cpu", weights_only=False)
        if selected["identity"] != identity or selected["best"] != saved["best"]:
            raise ValueError("Interrupted best/last transaction; inspect before resume")
        del selected
        restore(objects, saved)
        history, best, start, peak = saved["history"], saved["best"], saved["epoch"] + 1, saved["peak_allocated_bytes"]
        del saved
    elif (directory / "best.pt").exists():
        raise ValueError("best.pt exists without resumable last.pt; inspect partial run")
    atomic_json(directory / "run.json", {**identity, "config": c, "dimension": dimension,
                                         "parameters": model.parameter_counts(), "conv_linear_macs": macs})
    torch.cuda.reset_peak_memory_stats()
    try:
        for epoch in range(start, c["budget"]["epochs"] + 1):
            traced = TraceLoader(loader("train", seed=seed, epoch=epoch))
            before = optimizer_step_count(objects[2], model.base.backbone.enc1.net[0].weight)
            row = {"epoch": epoch, **epoch_step(objects, traced, loader("validation", seed=seed))}
            row["batch_hashes"] = traced.batch_hashes
            row["optimizer_steps"] = optimizer_step_count(objects[2], model.base.backbone.enc1.net[0].weight)
            row["amp_skipped_updates_epoch"] = len(traced.batch_hashes) - (row["optimizer_steps"] - before)
            if not 0 <= row["amp_skipped_updates_epoch"] <= len(traced.batch_hashes):
                raise ValueError("Inconsistent AdamW update count")
            history.append(row)
            score = (row["validation"]["psnr"], row["validation"]["ssim"])
            if best is None or score > (best["psnr"], best["ssim"]):
                means, rows = evaluate(model, seed)
                if any(abs(means[key] - row["validation"][key]) > 1e-5 for key in means):
                    raise ValueError("Dimension validation per-image/aggregate mismatch")
                best = {"epoch": epoch, "psnr": score[0], "ssim": score[1]}
                save_checkpoint(directory / "best.pt", {"model": model.state_dict(), "identity": identity, "best": best,
                                                       "per_image": rows, "parameters": model.parameter_counts(), "conv_linear_macs": macs})
            complete = epoch == c["budget"]["epochs"]
            state = payload(objects, epoch=epoch, history=history, best=best, identity=identity, complete=complete)
            state["optimizer_steps"] = row["optimizer_steps"]
            peak = max(peak, state["peak_allocated_bytes"])
            state["peak_allocated_bytes"] = peak
            save_checkpoint(last, state)
            atomic_json(directory / "history.json", history)
            write_csv(directory / "train_log.csv", [{"epoch": r["epoch"], "psnr": r["validation"]["psnr"],
                                                     "ssim": r["validation"]["ssim"], "train_loss": r["train_loss"],
                                                     "val_loss": r["val_loss"], "lr": r["lr"], "epoch_seconds": r["epoch_seconds"],
                                                     "optimizer_steps": r["optimizer_steps"],
                                                     "amp_skipped_updates_epoch": r["amp_skipped_updates_epoch"]} for r in history])
            print(f"{condition}/seed_{seed} epoch={epoch} PSNR={score[0]:.5f} SSIM={score[1]:.6f}", flush=True)
            if complete:
                finish(directory, state)
                break
            del state
    except Exception as exc:
        import time
        atomic_json(directory / f"failure_{time.time_ns()}.json", {"error": repr(exc)})
        raise
