"""prepare, smoke, train, evaluate, report."""

import argparse
import fcntl

from .protocol import output_root


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ["prepare", "smoke", "evaluate", "report"]:
        commands.add_parser(name)
    train_parser = commands.add_parser("train")
    train_parser.add_argument("--condition", choices=["rgb", "latent"], required=True)
    args = parser.parse_args()
    output_root().mkdir(parents=True, exist_ok=True)
    # One process may mutate this experiment at a time. Reports can read atomic
    # history snapshots during training without holding the long-running lock.
    with (output_root() / ".operation.lock").open("a") as lock:
        if args.command != "report":
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.command == "prepare":
            from .audit import prepare

            prepare()
        elif args.command == "smoke":
            from .validation import smoke

            smoke()
        elif args.command == "train":
            from .engine import train

            train(args.condition)
        elif args.command == "evaluate":
            from .engine import evaluate

            evaluate()
        else:
            from .report import report

            report()
