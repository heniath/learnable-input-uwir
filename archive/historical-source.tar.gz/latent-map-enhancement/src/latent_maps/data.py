"""Audited pair manifests, grouping against leakage, and stateless paired crops."""

import hashlib
import json
import random
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset

from .models import reflect_pad
from .utils import canonical_hash, digest

EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
LAYOUTS = {
    "lolv2_real": [
        (
            "LOL/LOLv2/Real_captured/Train/Low",
            "LOL/LOLv2/Real_captured/Train/Normal",
            "development",
        ),
        (
            "LOL/LOLv2/Real_captured/Test/Low",
            "LOL/LOLv2/Real_captured/Test/Normal",
            "test",
        ),
    ],
    "uieb": [("UIEB/raw-890", "UIEB/reference-890", "development")],
    "lsui": [("LSUI/input", "LSUI/GT", "development")],
}


def _scan_pair(args):
    root, input_rel, reference_rel, partition = args
    metadata = {
        "id": input_rel,
        "input": input_rel,
        "reference": reference_rel,
        "partition": partition,
    }
    shapes = []
    thumbnail = None
    for role, rel in (("input", input_rel), ("reference", reference_rel)):
        path = root / rel
        with Image.open(path) as image:
            image.load()
            rgb = image.convert("RGB")
            shapes.append(rgb.size)
            if min(rgb.size) < 11:
                raise ValueError(f"Image too small for SSIM: {rel}")
            payload = f"RGB:{rgb.size}:".encode() + rgb.tobytes()
            stat = path.stat()
            metadata[role + "_identity"] = {
                "sha256": digest(path),
                "decoded_sha256": hashlib.sha256(payload).hexdigest(),
                "bytes": stat.st_size,
                "mtime_ns": stat.st_mtime_ns,
            }
            if role == "input":
                thumb = (
                    np.asarray(
                        rgb.resize((16, 16), Image.Resampling.BILINEAR),
                        dtype=np.float32,
                    )
                    / 255
                )
                thumbnail = thumb
                gray = np.asarray(
                    rgb.convert("L").resize((9, 8), Image.Resampling.BILINEAR)
                )
                bits = (gray[:, 1:] > gray[:, :-1]).flatten()
                dhash = sum(int(bit) << i for i, bit in enumerate(bits))
                metadata["dhash"] = f"{dhash:016x}"
    if shapes[0] != shapes[1]:
        raise ValueError(f"Pair dimensions differ: {input_rel} {shapes}")
    metadata["width"], metadata["height"] = shapes[0]
    return metadata, thumbnail


def scan_dataset(root, dataset):
    root = Path(root)
    tasks = []
    for input_dir, reference_dir, partition in LAYOUTS[dataset]:
        left = {
            p.name: p
            for p in (root / input_dir).iterdir()
            if p.suffix.lower() in EXTENSIONS
        }
        right = {
            p.name: p
            for p in (root / reference_dir).iterdir()
            if p.suffix.lower() in EXTENSIONS
        }
        if set(left) != set(right):
            raise ValueError(
                f"Unpaired files in {dataset}: inputs-only={sorted(set(left) - set(right))[:10]}, references-only={sorted(set(right) - set(left))[:10]}"
            )
        tasks.extend(
            (
                root,
                str(left[name].relative_to(root)),
                str(right[name].relative_to(root)),
                partition,
            )
            for name in sorted(left)
        )
    if not tasks:
        raise ValueError(f"No image pairs in {dataset}")
    with ThreadPoolExecutor(max_workers=4) as pool:
        scanned = list(pool.map(_scan_pair, tasks))
    return [row for row, _ in scanned], np.stack([thumb for _, thumb in scanned])


def leakage_groups(rows, thumbs):
    """Group exact RGB matches and conservative aligned near-duplicate candidates."""
    parents = list(range(len(rows)))

    def find(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i

    def union(a, b):
        parents[find(b)] = find(a)

    exact, near = [], []
    for role in ("input", "reference"):
        seen = {}
        for i, row in enumerate(rows):
            key = row[role + "_identity"]["decoded_sha256"]
            if key in seen:
                j = seen[key]
                union(i, j)
                exact.append({"a": rows[j]["id"], "b": row["id"], "role": role})
            else:
                seen[key] = i
    hashes = np.array([int(r["dhash"], 16) for r in rows], dtype=np.uint64)
    for i in range(len(rows) - 1):
        xor = hashes[i] ^ hashes[i + 1 :]
        if hasattr(np, "bitwise_count"):
            distances = np.bitwise_count(xor)
        else:
            distances = np.array([int(h).bit_count() for h in xor])
        for offset in np.flatnonzero(distances <= 3):
            j = i + 1 + int(offset)
            error = float(np.mean((thumbs[i] - thumbs[j]) ** 2))
            if error <= 0.000625:
                union(i, j)
                near.append(
                    {
                        "a": rows[i]["id"],
                        "b": rows[j]["id"],
                        "dhash_distance": int(distances[offset]),
                        "thumbnail_mse": error,
                    }
                )
    groups = {}
    for i in range(len(rows)):
        groups.setdefault(find(i), []).append(i)
    return list(groups.values()), {
        "exact_duplicates": exact,
        "near_duplicate_candidates": near,
        "near_duplicate_rule": "dHash distance <=3 AND aligned RGB 16x16 thumbnail MSE <=0.000625; candidates conservatively grouped, not proof of scene independence",
        "multi_image_groups": [g for g in groups.values() if len(g) > 1],
    }


def _take_groups(groups, target):
    # Exact subset sum retains counts without breaking duplicate groups.
    reached = {0: []}
    for index, group in enumerate(groups):
        for total, indices in list(reached.items()):
            new = total + len(group)
            if new <= target and new not in reached:
                reached[new] = indices + [index]
        if target in reached:
            selected = set(reached[target])
            return [g for i, g in enumerate(groups) if i in selected], [
                g for i, g in enumerate(groups) if i not in selected
            ]
    raise ValueError(
        f"Cannot preserve group boundaries with requested split size {target}"
    )


def assign_splits(rows, groups, counts, seed):
    if sum(counts) != len(rows):
        raise ValueError(f"Expected {sum(counts)} pairs, found {len(rows)}")
    official_test = {i for i, r in enumerate(rows) if r["partition"] == "test"}
    for group in groups:
        if official_test.intersection(group) and not set(group).issubset(official_test):
            raise ValueError(
                "Duplicate or near-duplicate group crosses official LOL train/test boundary; review data before training"
            )
    development = [g for g in groups if not set(g).issubset(official_test)]
    random.Random(seed).shuffle(development)
    if all(len(g) == 1 for g in development):
        indices = [g[0] for g in development]
        train = indices[: counts[0]]
        val = indices[counts[0] : counts[0] + counts[1]]
        test = (
            sorted(official_test) if official_test else indices[counts[0] + counts[1] :]
        )
    else:
        if official_test:
            test = sorted(official_test)
        else:
            test_groups, development = _take_groups(development, counts[2])
            test = [i for g in test_groups for i in g]
        val_groups, train_groups = _take_groups(development, counts[1])
        train, val = (
            [i for g in train_groups for i in g],
            [i for g in val_groups for i in g],
        )
    for split, indices, expected in zip(
        ("train", "validation", "test"), (train, val, test), counts
    ):
        if len(indices) != expected:
            raise ValueError(f"{split}: expected {expected}, found {len(indices)}")
        for i in indices:
            rows[i]["split"] = split
    for group in groups:
        if len({rows[i]["split"] for i in group}) != 1:
            raise AssertionError("Leakage group crosses partitions")
    return rows


def prepare_manifest(root, dataset, counts, seed, destination):
    destination = Path(destination)
    rows, thumbs = scan_dataset(root, dataset)
    groups, audit = leakage_groups(rows, thumbs)
    rows = assign_splits(rows, groups, counts, seed)
    manifest = {
        "schema_version": 1,
        "dataset": dataset,
        "split_seed": seed,
        "split_counts": dict(zip(("train", "validation", "test"), counts)),
        "split_rule": "Shuffle filename-ordered groups; preserve official LOL test. Singleton datasets use contiguous shuffled slices; duplicate groups use exact subset-sum allocation.",
        "audit": audit,
        "pairs": rows,
    }
    manifest["content_sha256"] = canonical_hash(manifest)
    if destination.exists():
        old = json.loads(destination.read_text())
        if old != manifest:
            raise ValueError(
                f"Frozen manifest differs from current data/protocol: {destination}; create a new experiment rather than overwrite it"
            )
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("x") as f:
            json.dump(manifest, f, indent=2)
            f.write("\n")
    return manifest


def load_manifest(path, root, verify_files=True):
    value = json.loads(Path(path).read_text())
    content = dict(value)
    expected = content.pop("content_sha256")
    if canonical_hash(content) != expected:
        raise ValueError("Manifest content hash does not match")
    if verify_files:
        for row in value["pairs"]:
            for role in ("input", "reference"):
                path = Path(root) / row[role]
                identity = row[role + "_identity"]
                stat = path.stat()
                if stat.st_size != identity["bytes"]:
                    raise ValueError(f"Dataset file changed: {path}")
                if (
                    stat.st_mtime_ns != identity["mtime_ns"]
                    and digest(path) != identity["sha256"]
                ):
                    raise ValueError(f"Dataset content changed: {path}")
    return value


def _tensor(path):
    with Image.open(path) as image:
        array = np.array(image.convert("RGB"), copy=True)
    return torch.from_numpy(array).permute(2, 0, 1).float().div_(255)


class PairedImages(Dataset):
    def __init__(self, manifest, root, split, seed=0, crop_size=256):
        self.rows = [r for r in manifest["pairs"] if r["split"] == split]
        self.root, self.split, self.seed, self.crop_size = (
            Path(root),
            split,
            seed,
            crop_size,
        )
        self.epoch = 0

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        x, y = _tensor(self.root / row["input"]), _tensor(self.root / row["reference"])
        if x.shape != y.shape or tuple(x.shape[-2:]) != (row["height"], row["width"]):
            raise ValueError(f"Pair dimensions changed: {row['id']}")
        if self.split == "train":
            size = self.crop_size
            h, w = x.shape[-2:]
            x, y = [reflect_pad(t, max(0, size - w), max(0, size - h)) for t in (x, y)]
            key = f"{self.seed}:{self.epoch}:{row['id']}"
            rng = random.Random(int(hashlib.sha256(key.encode()).hexdigest()[:16], 16))
            h, w = x.shape[-2:]
            top, left = rng.randrange(h - size + 1), rng.randrange(w - size + 1)
            x, y = (
                x[:, top : top + size, left : left + size],
                y[:, top : top + size, left : left + size],
            )
            for axis in (-1, -2):
                if rng.random() < 0.5:
                    x, y = x.flip(axis), y.flip(axis)
        return x, y, row["id"]
