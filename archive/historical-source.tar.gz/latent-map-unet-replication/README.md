# U-Net learned-map replication

Eight new runs test the seed-0 U-Net gain: `rgb`, `bounded`, `unbounded`, and
`capacity` at seeds 1 and 2. Experiment ID: `unet_map_replication_v1`.
Bounded is primary; unbounded tests output constraints. Both are learned latent
representations without physical-map targets or reconstruction supervision.

## Frozen comparison

Inherit `../latent-map-diagnostics` exactly: duplicate-grouped 720/80/90 manifest,
split seed 0, 256-pixel preprocessing/crops, batch 4, workers 2, stateless paired
augmentation and sample order, shared RGB backbone initialization, original
random extra-channel initialization, AdamW 2e-4/weight decay 1e-5, L1/VGG weights
1/1, AMP initial scale 1024, clipping 1, 100-epoch cosine to 1e-6, PSNR stopping
patience 20/min_delta 0.0001, and maximum validation (PSNR, SSIM) selection.
Exact settings: `configs/protocol.json`. No test image prediction is exposed.

Use the existing `uieb-latent-repro` Conda environment without installing or
upgrading packages. The pinned upstream checkout and VGG file are referenced in
place; datasets/checkpoints are not copied. Vendor code retains licenses and Git
provenance. The project root is not a Git repository; source snapshots, hashes,
environment records, and an implementation diff retain the code state.

Preparation checks all parent source hashes, unchanged model/engine/smoke source,
exact protocol inheritance, live environment, image hashes, grouping, and parent
manifest identity. It records historical seed-0 artifact/checkpoint hashes.
Each operation verifies that reference before using it. Historical runs remain
under their original experiment identity and are read only.

## Execution

From this directory with the environment's Python:

```bash
python -m unittest discover -s tests -v
python scripts/experiment.py prepare
python scripts/experiment.py smoke
python scripts/experiment.py report
python scripts/run_logged.py
```

Launch the runner in tmux session `latent-map-unet-replication`. Inspect existing
processes/session/GPU first and do not start a duplicate. Global runner and CLI
operation locks protect training/diagnostics; reporting has a separate lock.
Restarting the same runner preserves completed runs and resumes incomplete runs
from saved epoch boundaries with optimizer/scheduler/scaler/stopping/RNG state.
Mixed-precision CUDA continuation is not guaranteed bitwise identical; smoke
retains measured differences with inherited limits 0.01 dB/0.0001 SSIM.

Do not edit source/config/environment/data/weights after preparation. Protocol
changes require a new experiment. On OOM, stop and report without changing batch
size or resolution. There are exactly eight training runs; no later study launches
automatically.

## Reports and interpretation

Output root: `outputs/unet_map_replication_v1/`. Logs/status: `training.log` and
`job_status.json`. Run history/checkpoints: `unet/<condition>/seed_<1|2>/`.
The runner refreshes partial reports after completed stages and generates the
final report after all runs and diagnostics complete.

- `reports/FINDINGS.md`, `results.json`, `results.csv`: status, scores, resources,
  screening, seed-specific interventions, and per-image summary/failure cases.
- `paired_validation_differences.csv`: paired image effects for each seed.
- `seed_summary.csv`, `paired_seed_summary.csv`: new-only and explicitly labeled
  historical-inclusive means/sample SDs. Available seeds are listed even in a
  partial report; no inference is drawn from incomplete evidence.
- `convergence.csv`, `common_horizon_scores.csv`: loss/metric/scale trajectories
  and best-so-far scores through shared observed epoch horizons.
- `report_complete.json`: generated only after eight new diagnosed runs; hashes
  protect the completed report. Historical seed 0 cannot count as a new run.

A condition passes the descriptive repeatability screen only if PSNR improves
over both RGB and capacity with nonnegative SSIM differences in **each** new
seed. Advance bounded if it passes; if only unbounded passes, investigate bounds;
otherwise investigate variation before adding modules. No significance,
equivalence, generalization, or novelty claim follows from this screen alone.

Scores are validation-selected. Scene independence is unverified and historical
test results were previously inspected. Parameter matching does not match compute.
Published test scores are a different protocol and remain separate. GPU forward
latency excludes preprocessing, transfers and metrics.

Paper preparation: `research/PAPER_OUTLINE.md`, `PRIOR_PAPER_AUDIT.md`,
`NOVELTY.md`, and `TERMINOLOGY.md`. These are provisional research documents,
not a submission-ready manuscript or a promised conference outcome.
