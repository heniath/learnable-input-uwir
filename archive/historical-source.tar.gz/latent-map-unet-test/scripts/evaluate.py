#!/usr/bin/env python3
"""Evaluate fixed validation-selected U-Net checkpoints on historical UIEB test90."""

import argparse
import csv
import json
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
REPLICATION = ROOT.parent / "latent-map-unet-replication"
PARENT = ROOT.parent / "latent-map-diagnostics"
sys.path[:0] = [str(REPLICATION / "src"),
                str(REPLICATION / "third_party/upstream/src"),
                str(REPLICATION / "third_party/nafnet")]

import numpy as np
import torch
from PIL import Image, ImageDraw

from diagnostics.diagnose import metric_rows
from diagnostics.models import EnhancementModel
from diagnostics.protocol import (atomic_json, base_dataset, canonical, config,
                                  digest, seed_original, verify_frozen)

CONDITIONS = ("rgb", "bounded", "unbounded", "capacity")
SEEDS = (0, 1, 2)


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_csv(path, rows):
    with path.open("x", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def batches_for(dataset, manifest, split):
    indices = manifest["indices"][split]
    loader = torch.utils.data.DataLoader(
        torch.utils.data.Subset(dataset, indices),
        batch_size=config()["batch_size"], shuffle=False,
        num_workers=config()["workers"], pin_memory=True, drop_last=False,
    )
    batches = [(x, y, list(names)) for x, y, names, _ in loader]
    expected = [manifest["pairs"][i]["filename"] for i in indices]
    if [name for _, _, names in batches for name in names] != expected:
        raise ValueError(f"Sample order mismatch: {split}")
    if len(expected) != (80 if split == "validation" else 90):
        raise ValueError(f"Unexpected sample count: {split}")
    if any(manifest["pairs"][i]["split"] != split for i in indices):
        raise ValueError(f"Manifest membership mismatch: {split}")
    return batches


def tensor_image(tensor):
    array = tensor.detach().float().cpu().permute(1, 2, 0).numpy()
    return Image.fromarray(np.rint(array.clip(0, 1) * 255).astype(np.uint8))


@torch.inference_mode()
def evaluate(seed, condition, checkpoint, validation, test, output, log):
    diagnostic = json.loads((checkpoint.parent / "diagnostics.json").read_text())
    identity = json.loads((checkpoint.parent / "run.json").read_text())
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if state["identity"] != identity or diagnostic["identity"] != identity:
        raise ValueError("Checkpoint identity mismatch")
    seed_original(seed)
    model = EnhancementModel("unet", condition, seed).cuda().eval()
    model.load_state_dict(state["model"], strict=True)
    del state
    anchor = []
    for x, y, names in validation:
        anchor.extend(metric_rows(model(x.cuda()), y, names))
    with (checkpoint.parent / "per_image_validation_normal.csv").open() as handle:
        saved = {row["filename"]: row for row in csv.DictReader(handle)}
    if set(saved) != {row["filename"] for row in anchor}:
        raise ValueError("Validation identity mismatch")
    drift = {key: max(abs(row[key] - float(saved[row["filename"]][key]))
                      for row in anchor) for key in ("psnr", "ssim")}
    if drift["psnr"] > 0.001 or drift["ssim"] > 0.00001:
        raise ValueError(f"Validation anchor failed: {drift}")
    log(f"seed={seed} {condition}: validation reproduced, max drift={drift}")
    directory = output / f"seed_{seed}" / condition
    directory.mkdir(parents=True)
    rows, examples = [], {}
    for x, y, names in test:
        prediction = model(x.cuda())
        rows.extend(metric_rows(prediction, y, names))
        for name, image in zip(names, prediction):
            if len(examples) < 6:
                examples[name] = tensor_image(image)
                examples[name].save(directory / f"{Path(name).stem}.png")
    if len(rows) != 90 or len({row["filename"] for row in rows}) != 90:
        raise ValueError("Expected 90 unique test predictions")
    if not all(np.isfinite(row[key]) for row in rows for key in ("psnr", "ssim")):
        raise FloatingPointError("Non-finite test metric")
    write_csv(directory / "per_image_test.csv", rows)
    result = {"seed": seed, "origin": "historical" if seed == 0 else "replication",
              "condition": condition, "n": len(rows),
              "psnr": float(np.mean([row["psnr"] for row in rows])),
              "ssim": float(np.mean([row["ssim"] for row in rows])),
              "selected_epoch": diagnostic["checkpoint_epoch"],
              "checkpoint_sha256": diagnostic["checkpoint_sha256"],
              "validation_max_psnr_drift": drift["psnr"],
              "validation_max_ssim_drift": drift["ssim"]}
    atomic_json(directory / "result.json", result)
    log(f"seed={seed} {condition}: test PSNR={result['psnr']:.4f}, SSIM={result['ssim']:.5f}")
    del model
    torch.cuda.empty_cache()
    return result, rows, examples


def summarize(results, per_image, output):
    summaries, paired = [], []
    for scope, seeds in (("new_seeds_1_2", (1, 2)),
                         ("historical_0_plus_new_1_2", SEEDS)):
        for condition in CONDITIONS:
            selected = [r for r in results if r["seed"] in seeds and r["condition"] == condition]
            row = {"scope": scope, "condition": condition, "seeds": list(seeds)}
            for key in ("psnr", "ssim"):
                values = [r[key] for r in selected]
                row[f"{key}_mean"] = float(np.mean(values))
                row[f"{key}_sample_sd"] = float(np.std(values, ddof=1))
            summaries.append(row)
    for seed in SEEDS:
        for condition in CONDITIONS:
            for control in ("rgb", "capacity"):
                if condition == control:
                    continue
                baseline = {r["filename"]: r for r in per_image[(seed, control)]}
                rows = per_image[(seed, condition)]
                delta = [r["psnr"] - baseline[r["filename"]]["psnr"] for r in rows]
                paired.append({"seed": seed, "condition": condition, "control": control,
                               "n": 90, "delta_psnr": float(np.mean(delta)),
                               "delta_ssim": float(np.mean([r["ssim"] - baseline[r["filename"]]["ssim"] for r in rows])),
                               "median_delta_psnr": float(np.median(delta)),
                               "psnr_wins": sum(d > 0 for d in delta)})
    write_csv(output / "results.csv", results)
    write_csv(output / "seed_summary.csv", summaries)
    write_csv(output / "paired_seed_differences.csv", paired)
    lines = ["# U-Net UIEB test90 inference", "",
             "Fixed validation-selected checkpoints; no training, tuning, TTA or ensembling.",
             "Seeds 1/2 are replication runs; seed 0 is historical and is reported separately.",
             "", "## Per-seed test scores", "",
             "| Seed | Condition | PSNR | SSIM | Selected epoch |", "|---|---|---:|---:|---:|"]
    for r in results:
        lines.append(f"| {r['seed']} | {r['condition']} | {r['psnr']:.4f} | {r['ssim']:.5f} | {r['selected_epoch']} |")
    for scope in ("new_seeds_1_2", "historical_0_plus_new_1_2"):
        lines += ["", f"## {scope}", "", "Mean ± sample SD across training seeds, not confidence intervals.", "",
                  "| Condition | PSNR | SSIM |", "|---|---:|---:|"]
        for r in summaries:
            if r["scope"] == scope:
                lines.append(f"| {r['condition']} | {r['psnr_mean']:.4f} ± {r['psnr_sample_sd']:.4f} | {r['ssim_mean']:.5f} ± {r['ssim_sample_sd']:.5f} |")
    lines += ["", "## Paired test differences", "",
              "| Seed | Condition | Control | ΔPSNR | ΔSSIM | PSNR wins / 90 |",
              "|---|---|---|---:|---:|---:|"]
    for r in paired:
        lines.append(f"| {r['seed']} | {r['condition']} | {r['control']} | {r['delta_psnr']:+.4f} | {r['delta_ssim']:+.5f} | {r['psnr_wins']} |")
    lines += ["", "## Evaluation boundaries", "",
              "Historical frozen UIEB test90, sorted indices 800:890; resize shorter edge to 256 then aligned center crop 256. RGB [0,1], float32 inference; clip predictions to [0,1] for the inherited per-image PSNR/SSIM implementations, then arithmetic mean across images.",
              "Validation reproduction is verified separately before every test run (maximum per-image drift: PSNR ≤0.001 dB, SSIM ≤0.00001).",
              "Historical test exposure already existed. These are not previously unseen, native-resolution benchmark scores. No checkpoint selection uses these test results. Scene independence beyond the inherited duplicate audit is unverified.",
              "PNG examples are the first six fixed test filenames for each checkpoint, chosen before inference. Metrics use float predictions before PNG quantization. Contact sheets use the same six samples and all four conditions; they are illustrative, not a separate evaluation.",
              "Original source/configuration/checkpoints/reports remain unchanged. See protocol.json for identities and provenance, execution.log for progress, and complete.json for output hashes and execution resources."]
    (output / "FINDINGS.md").write_text("\n".join(lines) + "\n")


def contact_sheet(seed, batches, examples, output):
    rows = [(name, tensor_image(x[i]), tensor_image(y[i]))
            for x, y, names in batches for i, name in enumerate(names)][:6]
    width, cell_height = 256, 286
    sheet = Image.new("RGB", (6 * width, len(rows) * cell_height), "white")
    draw = ImageDraw.Draw(sheet)
    for row_index, (name, raw, target) in enumerate(rows):
        images = [("Input", raw), ("Reference", target)]
        images += [(condition, examples[condition][name]) for condition in CONDITIONS]
        for col, (label, image) in enumerate(images):
            left, top = col * width, row_index * cell_height
            draw.text((left + 4, top + 3), f"{label}: {name}"[:40], fill="black")
            sheet.paste(image, (left, top + 28))
    sheet.save(output / f"comparison_seed_{seed}.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", default="unet_uieb_test90_v1")
    args = parser.parse_args()
    if Path(args.run_id).name != args.run_id or args.run_id in (".", ".."):
        parser.error("run-id must be a single directory name")
    output = ROOT / "outputs" / args.run_id
    output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()

    def log(message):
        line = f"{utc()} {message}"
        print(line, flush=True)
        with (output / "execution.log").open("a") as handle:
            handle.write(line + "\n")

    try:
        log("Verifying frozen sources, environment, data and historical references")
        frozen, manifest = verify_frozen()
        seed_original(0)
        split_sets = {key: set(value) for key, value in manifest["indices"].items()}
        if (any(split_sets[a] & split_sets[b] for a, b in
                (("train", "validation"), ("train", "test"), ("validation", "test")))
                or split_sets["test"] != set(range(800, 890))):
            raise ValueError("Frozen partitions overlap or test90 identity changed")
        parent_frozen = json.loads((PARENT / "outputs/map_diagnostics_v1/frozen_protocol.json").read_text())
        parent_manifest = json.loads((PARENT / "outputs/map_diagnostics_v1/manifest.json").read_text())
        if canonical(parent_manifest) != canonical(manifest):
            raise ValueError("Historical/replication manifests differ")
        checkpoints, provenance = {}, []
        for seed in SEEDS:
            archive = (PARENT / "outputs/map_diagnostics_v1" if seed == 0 else
                       REPLICATION / "outputs/unet_map_replication_v1")
            for condition in CONDITIONS:
                checkpoint = archive / "unet" / condition / f"seed_{seed}" / "best.pt"
                diagnostic = json.loads((checkpoint.parent / "diagnostics.json").read_text())
                identity = json.loads((checkpoint.parent / "run.json").read_text())
                expected = {"backbone": "unet", "condition": condition, "seed": seed,
                            "frozen_identity": canonical(parent_frozen if seed == 0 else frozen)}
                if identity != expected or diagnostic["identity"] != expected:
                    raise ValueError(f"Run identity mismatch: {checkpoint}")
                if digest(checkpoint) != diagnostic["checkpoint_sha256"]:
                    raise ValueError(f"Checkpoint changed: {checkpoint}")
                for name, expected_hash in diagnostic["artifact_hashes"].items():
                    if digest(checkpoint.parent / name) != expected_hash:
                        raise ValueError(f"Diagnostic artifact changed: {checkpoint.parent / name}")
                checkpoints[(seed, condition)] = checkpoint
                provenance.append({"seed": seed, "condition": condition,
                                   "checkpoint": str(checkpoint), "sha256": diagnostic["checkpoint_sha256"],
                                   "selected_epoch": diagnostic["checkpoint_epoch"]})
        atomic_json(output / "protocol.json", {
            "run_id": args.run_id, "utc": utc(), "dataset": "UIEB", "split": "test90",
            "seeds": SEEDS, "conditions": CONDITIONS, "manifest_sha256": canonical(manifest),
            "replication_frozen_identity": canonical(frozen), "historical_frozen_identity": canonical(parent_frozen),
            "environment": frozen["environment"], "precision": "float32", "batch_size": config()["batch_size"],
            "preprocessing": "Inherited shorter-edge resize 256, aligned center crop 256, RGB [0,1]",
            "metrics": "Inherited uwir compute_psnr/compute_ssim; clipped float predictions; per-image mean",
            "selection": "Unmodified best.pt selected by validation PSNR/SSIM; no new selection",
            "checkpoints": provenance, "script_sha256": digest(__file__),
            "git": "Study directories are not Git repositories; source snapshots/hashes retain provenance",
            "authorization": "User requested U-Net test inference; separate evaluation extends completed validation-only studies",
            "test_policy": "Historical test exposure; no test-based tuning, selection or retraining",
            "examples": "First six frozen test filenames, all conditions for seeds 0/1/2",
        })
        shutil.copyfile(__file__, output / "evaluate.py")
        dataset = base_dataset(augment=False)
        validation, test = (batches_for(dataset, manifest, split) for split in ("validation", "test"))
        log("Preflight complete; evaluating 12 fixed checkpoints with validation anchors")
        torch.cuda.reset_peak_memory_stats()
        results, per_image = [], {}
        for seed in SEEDS:
            examples = {}
            for condition in CONDITIONS:
                result, rows, examples[condition] = evaluate(
                    seed, condition, checkpoints[(seed, condition)], validation, test, output, log)
                results.append(result)
                per_image[(seed, condition)] = rows
            contact_sheet(seed, test, examples, output)
        summarize(results, per_image, output)
        for item in provenance:
            if digest(item["checkpoint"]) != item["sha256"]:
                raise ValueError("Checkpoint changed during inference")
        log("All 12 checkpoints complete; original checkpoints unchanged")
        atomic_json(output / "complete.json", {
            "utc": utc(), "elapsed_seconds": time.perf_counter() - started,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "checkpoints_evaluated": len(results), "test_predictions": len(results) * 90,
            "artifact_hashes": {str(p.relative_to(output)): digest(p) for p in output.rglob("*") if p.is_file()},
        })
    except BaseException as error:
        atomic_json(output / "failure.json", {"utc": utc(), "error": repr(error)})
        raise


if __name__ == "__main__":
    main()
