# Implementation validation — 2026-10-22

Command with the unchanged existing environment:

```bash
/home/heniath/miniforge3/envs/uieb-latent-repro/bin/python -B -m unittest discover -s tests -v
```

Final outcome: seven tests passed in 1.054 seconds. They cover the exact four-run
queue/budget, unchanged frozen dependency hashes, reuse paths for five existing
cells/diagnostics, identity of the original component builder, common parameter
initialization at both new seeds, test-loader/new-run guards, paired filename
alignment and sample SD, pending/nonpositive-PSNR/negative-SSIM repeatability
cases, paired input/schedule rejection, and partial report generation from all
five actual references without a false completion/confirmation.

The initial six-test suite passed. After adding the partial-report integration
test, that new test failed with a NameError caused by a misplaced assertion
block referring to another test's local variable. The block was moved back to
its intended history-guard test, and the complete seven-test suite then passed.
This was a new test-file issue, not a parent-code or scientific-protocol failure.
All new Python files also passed AST parsing. No research run had started during
these CPU checks.

The workspace/project are not Git repositories; `git status --short` reported
that fact. Source/config snapshots and hashes provide local provenance. Current
parent source hashes match the completed global-study snapshot. There were no
dependency, dataset, checkpoint or system-setting changes. The existing Kornia
AMP deprecation warning remained visible.

GPU smoke, source/environment/data verification and research progress are
recorded separately under `outputs/global_dimension_replication_v1/`. The CPU
suite is functionality evidence, not evidence of improved model quality.
