"""Frozen runs, epoch-boundary replay, native evaluation, and resource smoke checks."""

import json
import math
import shutil
import time
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader

from .data import PairedImages, load_manifest
from .metrics import rgb_metrics
from .models import EnhancementModel, convolution_macs, parameter_count
from .utils import (
    atomic_checkpoint,
    atomic_json,
    canonical_hash,
    digest,
    environment,
    restore_rng,
    rng_state,
    seed_everything,
    snapshot_source,
    source_state,
)


def loader(dataset, config, device, train=False, epoch=0, workers=None):
    generator = torch.Generator().manual_seed(dataset.seed + 30000 + epoch)
    nworkers = config["training"]["workers"] if workers is None else workers
    kwargs = {"multiprocessing_context": "spawn"} if nworkers else {}
    return DataLoader(
        dataset,
        batch_size=config["training"]["batch_size"] if train else 1,
        shuffle=train,
        drop_last=False,
        num_workers=nworkers,
        pin_memory=device.type == "cuda",
        generator=generator,
        **kwargs,
    )


def validate_config(config):
    t, e = config["training"], config["evaluation"]
    required = {
        "precision": "float32",
        "loss": "l1",
        "optimizer": "adamw",
        "scheduler": "cosine",
        "checkpoint_selection": "validation_rgb_psnr",
    }
    for key, value in required.items():
        if t[key] != value:
            raise ValueError(f"Unsupported protocol setting {key}={t[key]!r}")
    if (
        not e["native_resolution"]
        or e["batch_size"] != 1
        or e["clip_prediction"] != [0.0, 1.0]
    ):
        raise ValueError(
            "Only native, batch-one, [0,1]-clipped evaluation is implemented"
        )
    if (e["ssim_window"], e["ssim_sigma"], e["ssim_covariance"], e["ssim_border"]) != (
        11,
        1.5,
        "population",
        "valid",
    ):
        raise ValueError("Unsupported SSIM definition")
    if (
        e["psnr_aggregation"] != "mean_per_image_rgb"
        or e["padding"] != "reflection_to_multiple_of_16"
    ):
        raise ValueError("Unsupported evaluation aggregation/padding")
    if len(config["model"]["encoder_blocks"]) != 4:
        raise ValueError(
            "The frozen evaluation protocol requires four downsampling levels"
        )
    if t["epochs"] < 1 or t["batch_size"] < 1 or t["crop_size"] < 16:
        raise ValueError("Invalid training dimensions or duration")


def synchronize(device):
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def _finite_mean(values):
    if any(not math.isfinite(v) for v in values):
        raise FloatingPointError(
            "Nonfinite benchmark metric; inspect perfect predictions or invalid outputs"
        )
    return sum(values) / len(values)


@torch.inference_mode()
def evaluate_loader(model, batches, device):
    model.eval()
    rows = []
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    for index, (x, y, names) in enumerate(batches):
        x, y = x.to(device), y.to(device)
        if index == 0:
            model(x)  # Untimed shape-specific warmup.
        synchronize(device)
        started = time.perf_counter()
        prediction = model(x)
        synchronize(device)
        elapsed = time.perf_counter() - started
        metrics = rgb_metrics(prediction, y)
        rows.append(
            {
                "id": names[0],
                **metrics,
                "inference_ms": elapsed * 1000,
                "width": x.shape[-1],
                "height": x.shape[-2],
            }
        )
    if not rows:
        raise ValueError("Empty evaluation split")
    summary = {
        metric: _finite_mean([r[metric] for r in rows])
        for metric in ("psnr", "ssim", "inference_ms")
    }
    summary["images"] = len(rows)
    summary["peak_allocated_mib"] = (
        torch.cuda.max_memory_allocated(device) / 1024**2
        if device.type == "cuda"
        else None
    )
    return summary, rows


def run_signature(config, manifest, seed, condition):
    return {
        "config_sha256": canonical_hash(config),
        "manifest_sha256": manifest["content_sha256"],
        "source_sha256": source_state()["sha256"],
        "environment_sha256": canonical_hash(environment()),
        "seed": seed,
        "condition": condition,
        "dataset": manifest["dataset"],
    }


def freeze_experiment(config, output_root, manifest_dir):
    validate_config(config)
    root = Path(output_root)
    root.mkdir(parents=True, exist_ok=True)
    manifests = {
        name: load_manifest(Path(manifest_dir) / f"{name}.json", config["data_root"])
        for names in config["stages"].values()
        for name in names
    }
    protocol = {
        "resolved_config": config,
        "source": source_state(),
        "environment": environment(),
        "manifest_hashes": {k: v["content_sha256"] for k, v in manifests.items()},
    }
    path = root / "frozen_protocol.json"
    if path.exists():
        if json.loads(path.read_text()) != protocol:
            raise ValueError(
                "Frozen experiment differs from current source, environment, config or manifests; create a new experiment ID"
            )
    else:
        snapshot_source(root / "source_snapshot")
        atomic_json(path, protocol)
        shutil.copytree(manifest_dir, root / "manifests", dirs_exist_ok=True)
    return manifests


def train(config, manifest, condition, seed, run_dir, device, stop_after_epoch=None):
    validate_config(config)
    t = config["training"]
    torch.set_num_threads(t["cpu_threads"])
    seed_everything(seed, t["deterministic_algorithms"])
    run_dir = Path(run_dir)
    signature = run_signature(config, manifest, seed, condition)
    metadata_path = run_dir / "run.json"
    if metadata_path.exists():
        if json.loads(metadata_path.read_text())["signature"] != signature:
            raise ValueError(f"Run identity changed: {run_dir}")
        if (run_dir / "train_complete.json").exists():
            print(f"Already trained: {run_dir.name}", flush=True)
            return
        if not (run_dir / "last.pt").exists():
            # A failure before the first checkpoint can be retried with the same identity.
            print(f"Retrying uncheckpointed run: {run_dir.name}", flush=True)
    elif run_dir.exists() and any(run_dir.iterdir()):
        raise ValueError(f"Refusing unidentified existing artifacts: {run_dir}")
    run_dir.mkdir(parents=True, exist_ok=True)
    model = EnhancementModel(condition, seed=seed, **config["model"]).to(device)
    metadata = {
        "signature": signature,
        "config": config,
        "environment": environment(),
        "parameters": parameter_count(model),
        "status": "training",
    }
    atomic_json(metadata_path, metadata)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=t["learning_rate"],
        weight_decay=t["weight_decay"],
        foreach=False,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=t["epochs"])
    train_set = PairedImages(
        manifest, config["data_root"], "train", seed, t["crop_size"]
    )
    val_set = PairedImages(
        manifest, config["data_root"], "validation", seed, t["crop_size"]
    )
    start_epoch, best_psnr, history, elapsed_total = 0, -math.inf, [], 0.0
    if (run_dir / "last.pt").exists():
        checkpoint = torch.load(
            run_dir / "last.pt", map_location="cpu", weights_only=False
        )
        if checkpoint["signature"] != signature:
            raise ValueError("Checkpoint identity mismatch")
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        restore_rng(checkpoint["rng"])
        start_epoch, best_psnr = checkpoint["epoch"], checkpoint["best_validation_psnr"]
        history, elapsed_total = checkpoint["history"], checkpoint["elapsed_seconds"]
        print(f"Resuming {run_dir.name} after epoch {start_epoch}", flush=True)
    loss_fn = nn.L1Loss()
    try:
        for epoch in range(start_epoch, t["epochs"]):
            model.train()
            train_set.epoch = epoch
            started = time.perf_counter()
            if device.type == "cuda":
                torch.cuda.reset_peak_memory_stats(device)
            weighted_loss, samples = 0.0, 0
            used_lr = optimizer.param_groups[0]["lr"]
            for x, y, _ in loader(train_set, config, device, train=True, epoch=epoch):
                x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                prediction = model(x)
                loss = loss_fn(prediction, y)
                if not torch.isfinite(loss):
                    raise FloatingPointError("Nonfinite training loss")
                loss.backward()
                torch.nn.utils.clip_grad_norm_(
                    model.parameters(), math.inf, error_if_nonfinite=True
                )
                optimizer.step()
                weighted_loss += loss.item() * x.shape[0]
                samples += x.shape[0]
            synchronize(device)
            training_seconds = time.perf_counter() - started
            train_peak = (
                torch.cuda.max_memory_allocated(device) / 1024**2
                if device.type == "cuda"
                else None
            )
            validation, _ = evaluate_loader(
                model, loader(val_set, config, device), device
            )
            scheduler.step()
            elapsed_total += time.perf_counter() - started
            entry = {
                "epoch": epoch + 1,
                "train_l1": weighted_loss / samples,
                "learning_rate": used_lr,
                "validation": validation,
                "train_seconds": training_seconds,
                "train_peak_allocated_mib": train_peak,
            }
            history.append(entry)
            if validation["psnr"] > best_psnr:
                best_psnr = validation["psnr"]
                atomic_checkpoint(
                    run_dir / "best.pt",
                    {
                        "model": model.state_dict(),
                        "signature": signature,
                        "epoch": epoch + 1,
                        "validation": validation,
                    },
                )
            atomic_checkpoint(
                run_dir / "last.pt",
                {
                    "model": model.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "scheduler": scheduler.state_dict(),
                    "rng": rng_state(),
                    "signature": signature,
                    "epoch": epoch + 1,
                    "best_validation_psnr": best_psnr,
                    "history": history,
                    "elapsed_seconds": elapsed_total,
                },
            )
            atomic_json(run_dir / "history.json", history)
            print(
                f"{manifest['dataset']} {condition} seed={seed} epoch={epoch + 1}/{t['epochs']} "
                f"L1={entry['train_l1']:.5f} val_PSNR={validation['psnr']:.3f} "
                f"train_s={training_seconds:.1f} peak_MiB={train_peak}",
                flush=True,
            )
            if (
                stop_after_epoch is not None
                and epoch + 1 >= stop_after_epoch
                and epoch + 1 < t["epochs"]
            ):
                metadata["status"] = "checkpointed"
                atomic_json(metadata_path, metadata)
                return
        metadata["status"] = "trained"
        atomic_json(metadata_path, metadata)
        atomic_json(
            run_dir / "train_complete.json",
            {
                "epochs": t["epochs"],
                "best_validation_psnr": best_psnr,
                "elapsed_seconds": elapsed_total,
                "signature": signature,
            },
        )
    except BaseException as exc:
        atomic_json(
            run_dir / "failure.json",
            {
                "type": type(exc).__name__,
                "message": str(exc),
                "last_completed_epoch": history[-1]["epoch"] if history else 0,
                "resume": "Rerun the same command; replay starts after the last saved epoch.",
            },
        )
        metadata["status"] = (
            "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed"
        )
        atomic_json(metadata_path, metadata)
        raise


def evaluate_run(config, manifest, run_dir, device):
    run_dir = Path(run_dir)
    metadata = json.loads((run_dir / "run.json").read_text())
    signature = metadata["signature"]
    if signature != run_signature(
        config, manifest, signature["seed"], signature["condition"]
    ):
        raise ValueError("Evaluation source/config/data identity changed")
    if not (run_dir / "train_complete.json").exists():
        raise ValueError("Held-out evaluation requires a completed training run")
    if (run_dir / "test_results.json").exists():
        saved = json.loads((run_dir / "test_results.json").read_text())
        if saved["checkpoint_sha256"] != digest(run_dir / "best.pt"):
            raise ValueError("Completed evaluation's checkpoint changed")
        return saved
    torch.set_num_threads(config["training"]["cpu_threads"])
    seed_everything(signature["seed"], config["training"]["deterministic_algorithms"])
    checkpoint = torch.load(run_dir / "best.pt", map_location="cpu", weights_only=False)
    if checkpoint["signature"] != signature:
        raise ValueError("Best checkpoint identity mismatch")
    model = EnhancementModel(
        signature["condition"], seed=signature["seed"], **config["model"]
    ).to(device)
    model.load_state_dict(checkpoint["model"])
    samples = PairedImages(manifest, config["data_root"], "test", signature["seed"])
    summary, rows = evaluate_loader(model, loader(samples, config, device), device)
    from .report import write_csv

    write_csv(run_dir / "per_image_test.csv", rows)
    result = {
        "signature": signature,
        "checkpoint_sha256": digest(run_dir / "best.pt"),
        "checkpoint_epoch": checkpoint["epoch"],
        "validation": checkpoint["validation"],
        "test": summary,
        "parameters": parameter_count(model),
    }
    atomic_json(run_dir / "test_results.json", result)
    print(
        f"TEST {signature['dataset']} {signature['condition']} seed={signature['seed']} PSNR={summary['psnr']:.3f} SSIM={summary['ssim']:.4f}",
        flush=True,
    )
    return result


def smoke(config, manifests, device, destination):
    validate_config(config)
    torch.set_num_threads(config["training"]["cpu_threads"])
    seed_everything(0, config["training"]["deterministic_algorithms"])
    report = {
        "kind": "functionality/resource check; not benchmark evidence",
        "environment": environment(),
        "config_sha256": canonical_hash(config),
        "conditions": {},
        "datasets": {},
    }
    for condition in config["conditions"]:
        model = EnhancementModel(condition, seed=0, **config["model"]).to(device)
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=config["training"]["learning_rate"],
            weight_decay=0,
            foreach=False,
        )
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
        times = []
        for step in range(3):
            x = torch.rand(
                config["training"]["batch_size"],
                3,
                config["training"]["crop_size"],
                config["training"]["crop_size"],
                device=device,
            )
            y = torch.rand_like(x)
            synchronize(device)
            started = time.perf_counter()
            optimizer.zero_grad(set_to_none=True)
            loss = (model(x) - y).abs().mean()
            if not torch.isfinite(loss):
                raise FloatingPointError("Smoke loss is nonfinite")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), math.inf, error_if_nonfinite=True
            )
            if model.map_predictor is not None:
                for name, parameter in model.map_predictor.named_parameters():
                    if parameter.grad is None or parameter.grad.abs().sum().item() == 0:
                        raise AssertionError(
                            f"No gradient reaches map predictor {name}"
                        )
            optimizer.step()
            synchronize(device)
            times.append(time.perf_counter() - started)
        peak = (
            torch.cuda.max_memory_allocated(device) / 1024**2
            if device.type == "cuda"
            else None
        )
        report["conditions"][condition] = {
            "parameters": parameter_count(model),
            "conv_linear_macs_256": convolution_macs(model),
            "train_step_seconds": sum(times[1:]) / 2,
            "train_peak_allocated_mib": peak,
        }
        del x, y, loss, model, optimizer
        if device.type == "cuda":
            torch.cuda.empty_cache()
    learned = report["conditions"]["learned_maps"]["parameters"]
    capacity = report["conditions"]["capacity"]["parameters"]
    report["capacity_relative_difference"] = abs(learned - capacity) / learned
    baseline = report["conditions"]["rgb"]["parameters"]
    report["added_capacity_relative_difference"] = abs(learned - capacity) / (
        learned - baseline
    )
    if report["added_capacity_relative_difference"] > 0.02:
        raise AssertionError(
            "Capacity control differs by more than 2% of the added parameter budget"
        )
    for name, manifest in manifests.items():
        pair_data = PairedImages(
            manifest, config["data_root"], "train", 0, config["training"]["crop_size"]
        )
        loader_results = {}
        for workers in (0, config["training"]["workers"]):
            times = []
            iterator = iter(
                loader(pair_data, config, device, train=True, workers=workers)
            )
            for _ in range(3):
                started = time.perf_counter()
                x, y, _ = next(iterator)
                if x.shape != y.shape or not torch.isfinite(x).all():
                    raise AssertionError("Invalid paired batch")
                times.append(time.perf_counter() - started)
            loader_results[str(workers)] = {
                "startup_batch_seconds": times[0],
                "steady_batch_seconds": sum(times[1:]) / 2,
            }
            del iterator
        largest = max(manifest["pairs"], key=lambda r: r["width"] * r["height"])
        largest_data = {"pairs": [{**largest, "split": "validation"}]}
        x, _, _ = PairedImages(largest_data, config["data_root"], "validation")[0]
        model = (
            EnhancementModel("learned_maps", seed=0, **config["model"])
            .to(device)
            .eval()
        )
        x = x.unsqueeze(0).to(device)
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
        synchronize(device)
        started = time.perf_counter()
        with torch.inference_mode():
            output = model(x)
        synchronize(device)
        if output.shape != x.shape or not torch.isfinite(output).all():
            raise AssertionError("Native-size inference failed")
        report["datasets"][name] = {
            "loader": loader_results,
            "largest_image": largest["id"],
            "native_shape": list(x.shape),
            "native_forward_seconds": time.perf_counter() - started,
            "native_peak_allocated_mib": torch.cuda.max_memory_allocated(device)
            / 1024**2
            if device.type == "cuda"
            else None,
        }
        print(f"Smoke passed: {name} native_shape={list(x.shape)}", flush=True)
        del x, y, model, output
        if device.type == "cuda":
            torch.cuda.empty_cache()
    atomic_json(destination, report)
    return report
