"""Explicit prepare/smoke/train/report commands; never launch a sweep implicitly."""

import argparse
import fcntl
import gc
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch

from diagnostics.diagnose import latency, metric_rows
from diagnostics.engine import epoch_step, payload, restore, utc
from diagnostics.models import convolution_macs
from diagnostics.protocol import atomic_json, canonical, configure_weights, digest, loader, seed_original
from diagnostics.validation import compare_state
from uwir.cli.train import EarlyStopping, train_epoch
from uwir.losses import CompositeLoss
from uwir.training.checkpoint import save_checkpoint
from uwir.training.schedulers import CosineAnnealingRestartLR

from .models import ConditionedUNet
from .protocol import ROOT, output_root, prepare, read_config, validation_loader, verify, write_csv


class TraceLoader:
    def __init__(self, underlying):
        self.underlying = underlying
        self.batch_hashes = []

    def __len__(self):
        return len(self.underlying)

    def __iter__(self):
        for x, y in self.underlying:
            self.batch_hashes.append(hashlib.sha256(x.numpy().tobytes() + y.numpy().tobytes()).hexdigest())
            yield x, y


def optimizer_step_count(optimizer, reference_parameter):
    """AdamW's per-parameter step counts actual updates, including AMP skips."""
    step = optimizer.state.get(reference_parameter, {}).get("step", 0)
    return int(step.item() if isinstance(step, torch.Tensor) else step)


def make_objects(config, condition, seed):
    c = config["training"]
    configure_weights()
    seed_original(seed)
    model = ConditionedUNet(condition, seed).cuda()
    w = c["loss_weights"]
    loss = CompositeLoss(lambda_l1=w["l1"], lambda_perc=w["perceptual"], lambda_ssim=w["ssim"], device="cuda")
    optimizer = torch.optim.AdamW(model.parameters(), lr=c["lr"], weight_decay=c["weight_decay"])
    scheduler = CosineAnnealingRestartLR(optimizer, periods=[config["budget"]["scheduler_epochs"]], restart_weights=[1.0], eta_min=c["eta_min"])
    scaler = torch.amp.GradScaler("cuda", init_scale=c["amp_initial_scale"])
    early = EarlyStopping(patience=c["patience"], min_delta=c["min_delta"], mode="max")
    # Model/head/VGG construction must not advance training RNG differently by condition.
    seed_original(seed)
    return model, loss, optimizer, scheduler, scaler, early


@torch.inference_mode()
def evaluate(model, seed, limit=None):
    model.eval()
    rows = []
    for x, y, names, _ in validation_loader(seed, limit):
        rows.extend(metric_rows(model(x.cuda()).float(), y, names))
    expected = 80 if limit is None else limit
    if len(rows) != expected or len({r["filename"] for r in rows}) != expected:
        raise ValueError("Validation coverage mismatch")
    means = {key: float(np.mean([r[key] for r in rows])) for key in ("psnr", "ssim")}
    if not all(np.isfinite(v) for v in means.values()):
        raise FloatingPointError("Non-finite per-image validation metric")
    return means, rows


def smoke(config, frozen):
    out = output_root(config)
    marker = out / "smoke.json"
    if marker.exists():
        previous = json.loads(marker.read_text())
        if previous.get("passed") and previous["frozen_identity"] == canonical(frozen):
            print("Preserving completed smoke", flush=True)
            return
        raise ValueError("Existing smoke is invalid; inspect it before proceeding")
    result = {"passed": False, "frozen_identity": canonical(frozen), "scope": "Two real training batches and four validation images per condition; not quality evidence", "conditions": {}}
    directory = out / "smoke"
    directory.mkdir(exist_ok=True)
    for condition in config["conditions"]:
        objects = make_objects(config, condition, config["seeds"][0])
        model, criterion, optimizer, _, _, _ = objects
        torch.cuda.reset_peak_memory_stats()
        traced = TraceLoader(loader("train", seed=config["seeds"][0], epoch=1, limit=8))
        loss, _ = train_epoch(model, traced, optimizer, criterion, torch.device("cuda"), scaler=objects[4])
        if not optimizer.state or not np.isfinite(loss):
            raise ValueError("Smoke produced no finite optimizer updates")
        for name, parameter in model.named_parameters():
            if parameter.grad is None or not torch.isfinite(parameter.grad).all():
                raise ValueError(f"Missing/nonfinite gradient: {condition}/{name}")
        for head_name in ("transmission_extractor", "background_extractor"):
            if hasattr(model.base, head_name) and not any(p.grad.abs().max() > 0 for p in getattr(model.base, head_name).parameters()):
                raise ValueError(f"No gradient reaches {head_name}")
        for group in (model.spatial_modulation, model.global_modulation):
            if len(group) and not any(p.grad.abs().max() > 0 for p in group.parameters()):
                raise ValueError("No gradient reaches an adapter")
        means, rows = evaluate(model, config["seeds"][0], limit=4)
        state = payload(objects, epoch=1, history=[{"validation": means}], best=means, identity={"smoke": condition})
        checkpoint = directory / f"{condition}_roundtrip.pt"
        save_checkpoint(checkpoint, state)
        del state
        restored = torch.load(checkpoint, map_location="cpu", weights_only=False)
        restore(objects, restored)
        actual = payload(objects, epoch=1, history=restored["history"], best=restored["best"], identity=restored["identity"])
        stats = {"bitwise_equal": True, "max_absolute_tensor_difference": 0.0}
        for key in ("model", "optimizer", "scheduler", "scaler", "early_stopping", "rng_state"):
            compare_state(restored[key], actual[key], stats, key)
        if not stats["bitwise_equal"]:
            raise ValueError("Checkpoint state restoration was not exact")
        write_csv(directory / f"{condition}_per_image.csv", rows)
        result["conditions"][condition] = {"train_loss": loss, "validation": means, "batch_hashes": traced.batch_hashes,
                                           "parameters": model.parameter_counts(), "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                                           "optimizer_steps": optimizer_step_count(optimizer, model.base.backbone.enc1.net[0].weight),
                                           "checkpoint_roundtrip_exact": True}
        print(f"Smoke passed: {condition}; loss={loss:.5f}; parameters={model.parameter_counts()}", flush=True)
        del model, criterion, optimizer, objects, restored, actual
        gc.collect()
        torch.cuda.empty_cache()
    hashes = [v["batch_hashes"] for v in result["conditions"].values()]
    if any(h != hashes[0] for h in hashes):
        raise ValueError("Conditions saw different training batches/augmentations")
    result["passed"] = True
    atomic_json(marker, result)


def finish(directory, state):
    best_path = directory / "best.pt"
    best = torch.load(best_path, map_location="cpu", weights_only=False)
    if best["identity"] != state["identity"] or best["best"] != state["best"]:
        raise ValueError("Best and last checkpoint identities/selections differ")
    write_csv(directory / "metrics_per_image.csv", best["per_image"])
    atomic_json(directory / "history.json", state["history"])
    atomic_json(directory / "complete.json", {"identity": state["identity"], "best": state["best"], "final_epoch": state["epoch"],
                "optimizer_steps": state["optimizer_steps"],
                "training_batches": sum(len(r["batch_hashes"]) for r in state["history"]),
                "amp_skipped_updates": sum(r["amp_skipped_updates_epoch"] for r in state["history"]), "best_sha256": digest(best_path),
                "per_image_sha256": digest(directory / "metrics_per_image.csv"), "completed_utc": utc(),
                "parameters": best["parameters"], "conv_linear_macs": best["conv_linear_macs"],
                "peak_allocated_bytes": state["peak_allocated_bytes"],
                "training_epoch_seconds": sum(r["epoch_seconds"] for r in state["history"])})


def train(config, condition, seed, frozen):
    out = output_root(config)
    smoke_result = json.loads((out / "smoke.json").read_text())
    if not smoke_result.get("passed") or smoke_result["frozen_identity"] != canonical(frozen):
        raise ValueError("Pass smoke for this frozen study before training")
    if condition not in config["conditions"] or seed not in config["seeds"]:
        raise ValueError("Condition/seed is not in the frozen study")
    directory = out / "runs" / f"seed_{seed}" / condition
    directory.mkdir(parents=True, exist_ok=True)
    identity = {"condition": condition, "seed": seed, "frozen_identity": canonical(frozen)}
    marker = directory / "complete.json"
    if marker.exists():
        saved = json.loads(marker.read_text())
        if saved["identity"] != identity or saved["best_sha256"] != digest(directory / "best.pt") or saved["per_image_sha256"] != digest(directory / "metrics_per_image.csv"):
            raise ValueError("Completed run artifacts changed")
        print(f"Preserving completed {condition}/seed_{seed}", flush=True)
        return
    objects = make_objects(config, condition, seed)
    model = objects[0]
    model.eval()
    macs = convolution_macs(model)
    history, best, start, peak = [], None, 1, 0
    last = directory / "last.pt"
    if last.exists():
        state = torch.load(last, map_location="cpu", weights_only=False)
        if state["identity"] != identity:
            raise ValueError("Resume checkpoint identity mismatch")
        if state["complete"]:
            finish(directory, state)
            return
        saved_best = torch.load(directory / "best.pt", map_location="cpu", weights_only=False)
        if saved_best["identity"] != identity or saved_best["best"] != state["best"]:
            raise ValueError("Interrupted checkpoint transaction: best/last disagree; preserve artifacts and inspect before resume")
        del saved_best
        restore(objects, state)
        history, best, start = state["history"], state["best"], state["epoch"] + 1
        peak = state["peak_allocated_bytes"]
        del state
    elif (directory / "best.pt").exists():
        raise ValueError("Found best.pt without resumable last.pt; preserve and inspect this partial run")
    atomic_json(directory / "run.json", {**identity, "config": config, "parameters": model.parameter_counts(), "conv_linear_macs": macs})
    torch.cuda.reset_peak_memory_stats()
    try:
        for epoch in range(start, config["budget"]["epochs"] + 1):
            traced = TraceLoader(loader("train", seed=seed, epoch=epoch))
            steps_before = optimizer_step_count(objects[2], model.base.backbone.enc1.net[0].weight)
            row = {"epoch": epoch, **epoch_step(objects, traced, loader("validation", seed=seed))}
            row["batch_hashes"] = traced.batch_hashes
            row["optimizer_steps"] = optimizer_step_count(objects[2], model.base.backbone.enc1.net[0].weight)
            row["amp_skipped_updates_epoch"] = len(traced.batch_hashes) - (row["optimizer_steps"] - steps_before)
            if not 0 <= row["amp_skipped_updates_epoch"] <= len(traced.batch_hashes):
                raise ValueError("AdamW update count is inconsistent with training batches")
            history.append(row)
            score = (row["validation"]["psnr"], row["validation"]["ssim"])
            improved = best is None or score > (best["psnr"], best["ssim"])
            if improved:
                means, rows = evaluate(model, seed)
                for key, value in means.items():
                    if abs(value - row["validation"][key]) > 1e-5:
                        raise ValueError(f"Per-image and aggregate metrics differ: {key}")
                best = {"epoch": epoch, "psnr": score[0], "ssim": score[1]}
                save_checkpoint(directory / "best.pt", {"model": model.state_dict(), "identity": identity, "best": best,
                                "per_image": rows, "parameters": model.parameter_counts(), "conv_linear_macs": macs})
            complete = epoch == config["budget"]["epochs"] or (config["budget"]["early_stopping"] and row["early_stopped"])
            state = payload(objects, epoch=epoch, history=history, best=best, identity=identity, complete=complete)
            state["optimizer_steps"] = row["optimizer_steps"]
            peak = max(peak, state["peak_allocated_bytes"])
            state["peak_allocated_bytes"] = peak
            save_checkpoint(last, state)
            atomic_json(directory / "history.json", history)
            write_csv(directory / "train_log.csv", [{"epoch": r["epoch"], "train_loss": r["train_loss"], "val_loss": r["val_loss"],
                      "psnr": r["validation"]["psnr"], "ssim": r["validation"]["ssim"], "lr": r["lr"], "epoch_seconds": r["epoch_seconds"],
                      "optimizer_steps": r["optimizer_steps"], "amp_skipped_updates_epoch": r["amp_skipped_updates_epoch"]} for r in history])
            print(f"{condition}/seed_{seed} epoch={epoch} PSNR={score[0]:.4f} SSIM={score[1]:.5f}" + (" BEST" if improved else ""), flush=True)
            if complete:
                finish(directory, state)
                break
            del state
    except Exception as exc:
        atomic_json(directory / f"failure_{time.time_ns()}.json", {"utc": utc(), "type": type(exc).__name__, "message": str(exc)})
        raise


def profile(config, condition, seed, frozen):
    if condition not in config["conditions"] or seed not in config["seeds"]:
        raise ValueError("Condition/seed is not in the frozen study")
    directory = output_root(config) / "runs" / f"seed_{seed}" / condition
    completed = json.loads((directory / "complete.json").read_text())
    identity = {"condition": condition, "seed": seed, "frozen_identity": canonical(frozen)}
    if completed["identity"] != identity or digest(directory / "best.pt") != completed["best_sha256"]:
        raise ValueError("Profile checkpoint identity mismatch")
    target = directory / "profile.json"
    if target.exists():
        saved = json.loads(target.read_text())
        if saved["identity"] != identity or saved["checkpoint_sha256"] != completed["best_sha256"]:
            raise ValueError("Existing profile belongs to different weights")
        print("Preserving completed inference profile", flush=True)
        return
    seed_original(seed)
    model = ConditionedUNet(condition, seed).cuda().eval()
    state = torch.load(directory / "best.pt", map_location="cpu", weights_only=False)
    model.load_state_dict(state["model"], strict=True)
    del state
    x, _ = next(iter(loader("validation", seed=seed, limit=1)))
    torch.cuda.reset_peak_memory_stats()
    measurement = latency(model, x.cuda())
    atomic_json(target, {"identity": identity, "checkpoint_sha256": completed["best_sha256"], "latency": measurement,
                        "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "parameters": model.parameter_counts(),
                        "conv_linear_macs": convolution_macs(model), "utc": utc()})
    print(f"Inference profile written: {target}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/h1_pilot_v2.json")
    sub = parser.add_subparsers(dest="command", required=True)
    for command in ("prepare", "smoke", "report"):
        sub.add_parser(command)
    for command in ("train", "profile"):
        training = sub.add_parser(command)
        training.add_argument("--condition", required=True)
        training.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    config_path, config = read_config(args.config)
    with (ROOT / ".execution.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("Another conditioning command is running") from exc
        if args.command == "prepare":
            prepare(config_path, config)
            print(f"Prepared {output_root(config)}", flush=True)
        elif args.command == "report":
            from .report import report

            report(config_path, config)
        else:
            frozen = verify(config_path, config)
            if args.command == "smoke":
                smoke(config, frozen)
            elif args.command == "train":
                train(config, args.condition, args.seed, frozen)
            else:
                profile(config, args.condition, args.seed, frozen)


if __name__ == "__main__":
    main()
