"""Run the frozen comparison inside tmux, retaining logs and final exit status."""
# ruff: noqa: E402

import fcntl
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from latent_maps.utils import atomic_json, load_config


def main():
    config = load_config()
    output = ROOT / "outputs" / config["experiment_id"]
    output.mkdir(parents=True, exist_ok=True)
    with (output / ".job.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError(
                "This experiment already has an active logged runner"
            ) from exc
        command = [
            sys.executable,
            "-u",
            str(ROOT / "scripts/experiment.py"),
            "--device",
            "cuda",
            "run-stage",
            "--stage",
            "all",
        ]
        started = datetime.now(timezone.utc).isoformat()
        status = {
            "status": "running",
            "runner_pid": os.getpid(),
            "started_utc": started,
            "command": command,
            "log": str(output / "training.log"),
        }
        with (output / "training.log").open("a", buffering=1) as log:
            log.write(f"\nStarted {started}\n")
            process = subprocess.Popen(
                command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT
            )
            status["training_pid"] = process.pid
            atomic_json(output / "job_status.json", status)
            try:
                code = process.wait()
            except KeyboardInterrupt:
                process.send_signal(2)
                code = process.wait()
            status.update(
                status="complete" if code == 0 else "failed",
                exit_code=code,
                ended_utc=datetime.now(timezone.utc).isoformat(),
            )
            atomic_json(output / "job_status.json", status)
            log.write(f"Ended {status['ended_utc']} exit_code={code}\n")
        sys.exit(code)


if __name__ == "__main__":
    main()
