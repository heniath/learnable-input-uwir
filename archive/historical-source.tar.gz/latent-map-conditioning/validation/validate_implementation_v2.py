"""Bounded implementation validation, never the 30/100-epoch research runs."""

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path('/home/heniath/Experiments/latent-map-conditioning')
run = root / 'scripts/run.py'
tasks = [
    ('h1_pilot_v2.json', ['prepare']),
    ('h1_pilot_v2.json', ['smoke']),
    ('h2_pilot_v2.json', ['prepare']),
    ('h2_pilot_v2.json', ['smoke']),
    ('functional_check_v2.json', ['prepare']),
    ('functional_check_v2.json', ['smoke']),
    ('functional_check_v2.json', ['train', '--condition', 'A3_both', '--seed', '0']),
    ('functional_check_v2.json', ['train', '--condition', 'A3_both', '--seed', '0']),
    ('functional_check_v2.json', ['report']),
    ('functional_check_v2.json', ['profile', '--condition', 'A3_both', '--seed', '0']),
]
record = root / 'validation' / 'v2'
record.mkdir(exist_ok=True)
result = {'started_utc': datetime.now(timezone.utc).isoformat(), 'passed': False, 'commands': []}
with (record / 'implementation_checks.log').open('a', buffering=1) as log:
    for config, args in tasks:
        command = [sys.executable, '-B', str(run), '--config', str(root / 'configs' / config), *args]
        print('Checking:', config, ' '.join(args), flush=True)
        log.write('Command: ' + json.dumps(command) + '\n')
        process = subprocess.Popen(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            print(line, end='', flush=True)
            log.write(line)
        code = process.wait()
        result['commands'].append({'command': command, 'exit_code': code})
        (record / 'implementation_checks.json').write_text(json.dumps(result, indent=2) + '\n')
        if code:
            raise SystemExit(code)
result['passed'] = True
result['finished_utc'] = datetime.now(timezone.utc).isoformat()
(record / 'implementation_checks.json').write_text(json.dumps(result, indent=2) + '\n')
