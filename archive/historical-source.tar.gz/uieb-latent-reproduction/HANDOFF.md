# Background run handoff

The user requested leaving training running and checking results on return, so live polling was stopped. The training process was not interrupted.

- Project: `/home/heniath/Experiments/uieb-latent-reproduction`
- Environment: `/home/heniath/miniforge3/envs/uieb-latent-repro`
- tmux session: `uieb-latent-repro`
- Active output: `outputs/original_uieb_seed0_v2/`
- Runner: `scripts/run_logged.py`, RGB then latent, then evaluation and report
- Status: `job_status.json`; persistent progress/errors: `training.log`
- Final report: `reports/FINDINGS.md`, `reports/results.csv`, `reports/results.json`

Verification before launch: seven targeted tests passed; isolated Ruff E4/E7/E9/F/I checks passed; core package constraints unchanged; upstream checkout clean and pinned to d9d28626cf32308fd6d57fd0c2f9ab39623cea60. Both batch-size-4 GPU smoke checks passed, with exact model/optimizer/scheduler/scaler/early-stopping/RNG restoration, matching continuation input hashes and RNG/scheduler/scaler state. Peak smoke PyTorch allocation: RGB 1.593 GiB, latent 1.718 GiB. GPU continuation is not bitwise reproducible under the original AMP protocol; measured PSNR drift was below 0.00003 dB. Failed strict v1 preflight and diagnostic artifacts are preserved separately. No scientific protocol factor changed in v2.

The original 720/80/90 partition is frozen. Two exact input-duplicate pairs cross train/validation: 550_img_.png–558_img_.png and 684_img_.png–815_img_.png. They are also the cross-split near candidates; no audited pair crosses the test boundary. These checks cannot establish subject/scene independence.

Inherited ml-base pip-check conflicts in unrelated mambavision are documented in the generated report. Kornia 0.7.3 emits an AMP deprecation warning; it was not suppressed.

On return, read job_status.json and the training log first. If complete, inspect the final report and both selected checkpoint/evaluation markers and 90-row per-image CSVs. Do not rerun completed evaluation. If failed, inspect the failure before changing anything; an incomplete run can resume at the last saved epoch by relaunching the existing runner in tmux. Preserve source/configuration/data/environment/weights identities, completed runs and all earlier work. Do not launch additional seeds, datasets, NAFNet or reconstruction variants.
