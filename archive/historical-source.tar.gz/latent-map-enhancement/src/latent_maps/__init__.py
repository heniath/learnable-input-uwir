"""Controlled auxiliary-map image enhancement experiments."""
